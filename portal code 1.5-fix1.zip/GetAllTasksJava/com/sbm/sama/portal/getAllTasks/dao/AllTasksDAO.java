package com.sbm.sama.portal.getAllTasks.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.tanfeeth.jaxb.getAllTasks.GetAllTasksInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.getAllTasks.GetAllTasksOutputType;



public interface AllTasksDAO {
	
	public List<GetAllTasksOutputType> getAllTasks(GetAllTasksInputType _input, Connection _conn) throws SQLException, DatatypeConfigurationException;
	public int getAllTasksTotalCount(GetAllTasksInputType _input, Connection _conn) throws SQLException;

}
