package com.sbm.sama.portal.tanfeeth.jaxb.getAllTasks;

import java.util.List;

/**
 * 
 * @author Mahmoud Fahmy
 * 
 */
public class JAXBAllTasksHandler {
	public static void setAllTasksOutputList(GetAllTasksRsType getAllTasksRs,
			List<GetAllTasksOutputType> getAllTasksOutput) {
		getAllTasksRs.getAllTasksOutput = getAllTasksOutput;
	}

}
