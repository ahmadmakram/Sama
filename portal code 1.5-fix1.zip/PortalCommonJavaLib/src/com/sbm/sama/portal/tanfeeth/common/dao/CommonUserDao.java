package com.sbm.sama.portal.tanfeeth.common.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.jaxb.common.TPrdUsrsLis;
import com.sbm.sama.portal.tanfeeth.jaxb.common.UserInfoResponseType;



/**
 * 
 * @author Mahmoud Fahmi
 *
 */
public interface CommonUserDao {
	public void deleteUser(int taskId,Connection _conn) throws SQLException;
	public List<UserInfoResponseType>  selectUser(Connection _conn, int taskId) throws SQLException ;
	public TPrdUsrsLis selectUserCallBack(Connection _conn, int _task_id) throws SQLException;
	public void addUser(TPrdUsrsLis userInfoResponseTypeList,
			Connection conn, int taskId, int responseID, String prodcutType) throws SQLException;

}
