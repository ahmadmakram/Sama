package com.sbm.sama.portal.tanfeeth.common.enums;

public enum MainServiceCode {
	_001("INQ"), _002("EXE");

	private String serviceName = null;

	MainServiceCode(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getServiceName() {
		return this.serviceName;
	}
}
