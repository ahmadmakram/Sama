package com.sbm.sama.portal.getTask.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.getTask.dao.TaskDao;
import com.sbm.sama.portal.tanfeeth.common.constant.ServiceCode;
import com.sbm.sama.portal.tanfeeth.common.util.FieldsProcessing;
import com.sbm.sama.portal.tanfeeth.common.util.ServiceProcessor;
import com.sbm.sama.portal.tanfeeth.jaxb.common.AccountInfoType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.BlockType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.DepositeInfoType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.DlngDcsnInfoType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GarnishType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetTaskInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetTaskOutputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.InvolvedEntityType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.JAXBProtectedHandler;
import com.sbm.sama.portal.tanfeeth.jaxb.common.LiabilityInfoType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.LiftRestrictionInfoType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.RequestMetadataType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.SafeInfoType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TAccId;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TAmt;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TBenf;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TBlockDcsnInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TBlockFundXfer;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TBlockLiftCndtn;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TLiftDcsnInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TPreTanfeeth;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TSrvcRefInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TTanfeeth;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TaskType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.WorkflowStatusHistoryType;

public class TaskDaoImpl implements TaskDao {

	@Override
	public GetTaskOutputType GetTask(GetTaskInputType _input, Connection _conn)
			throws SQLException, DatatypeConfigurationException {
		int _filter_index = 0;

		String _sql_tsk = "SELECT * FROM FIPORTAL.TANFEETH_TASK_DETAILS_VIEW WHERE TASK_ID=?";
		String _sql_acct_info_req = "SELECT ACC_INFO_REQST_ID,AGCY_SRVC_REQST_ID,ACC_NO,IBAN from tanfeeth.ACC_INFO_REQST WHERE AGCY_SRVC_REQST_ID=?";
		String _sql_bala_info_req = "SELECT ACC_BAL_INFO_REQST_ID,AGCY_SRVC_REQST_ID,ACC_NO,iban from tanfeeth.ACC_BAL_INFO_REQST where AGCY_SRVC_REQST_ID = ?";
		String _sql_depo_info_req = "SELECT DEPOSIT_INFO_REQST_ID,AGCY_SRVC_REQST_ID,DEPOSIIT_NO from tanfeeth.DEPOSIT_INFO_REQST where AGCY_SRVC_REQST_ID = ?";
		String _sql_liab_info_req = "SELECT LIAB_INFO_REQST_ID,AGCY_SRVC_REQST_ID from tanfeeth.LIAB_INFO_REQST where AGCY_SRVC_REQST_ID = ?";
		String _sql_safe_info_req = "SELECT SAFE_INFO_REQST_ID,AGCY_SRVC_REQST_ID,BOX_NO from tanfeeth.SAFE_INFO_REQST where AGCY_SRVC_REQST_ID = ?";
		String sqlBanInfoReq = "SELECT DECISION_ISSUE_DATE,DECISION_NUMBER from tanfeeth.BAN_EXEC_REQST where AGCY_SRVC_REQST_ID = ?";
		String sqlDenyInfoReq = "SELECT DECISION_ISSUE_DATE,DECISION_NUMBER from tanfeeth.DENY_EXEC_REQST where AGCY_SRVC_REQST_ID = ?";
		String sqlLiftReq = "SELECT DCSN_NUM,DCSN_DATE,LETTER_RN,SAMANET_RN,RRN,PREV_SRN,AMT,BENF_NAME,BENF_BIC,BENF_IBAN FROM tanfeeth.LIFT_EXEC_REQST where AGCY_SRVC_REQST_ID = ?";
		String sqlBlockReq = "SELECT BAI_NUM,BAI_IBAN,BAI_BIC,DCSN_NUM,DCSN_DATE,DBT_TYPE,AMT_VAL,AMT_CUR FROM tanfeeth.BLOCK_EXEC_REQST where AGCY_SRVC_REQST_ID = ?";
		String _sql_task_status_events = "SELECT ID, TASK_ID, STATUS_ID, SUB_STATUS_ID, EVENT_DATE_TIME, EXECUTED_BY, EXECUTED_BY_ROLE, NOTES FROM FIPORTAL.WORKFLOW_STATUS_EVENT_HISTORY WHERE TASK_ID=? AND NOTES IS NOT NULL ORDER BY ID DESC";
		String request_metadataID = "";
		if (_input.getFiId() != null)
			_sql_tsk += " AND FI_ID=?";

		GetTaskOutputType _output = new GetTaskOutputType();
		TaskType _task = new TaskType();
		RequestMetadataType _request_metadata = new RequestMetadataType();

		PreparedStatement _ps = _conn.prepareStatement(_sql_tsk);
		_ps.setString(++_filter_index, _input.getTaskId());
		if (_input.getFiId() != null)
			_ps.setString(++_filter_index, _input.getFiId());

		ResultSet _rs = _ps.executeQuery();
		List<InvolvedEntityType> _itemlist = new ArrayList<InvolvedEntityType>();

		while (_rs.next()) {
			_task.setTaskId(_rs.getInt("TASK_ID"));
			_task.setFiId(_rs.getString("FI_ID"));
			_task.setCreatedDateTime(FieldsProcessing.getXMLGregCal(_rs
					.getTimestamp("TASK_CREATED_DATE_TIME")));
			_task.setDueDateTime(FieldsProcessing.getXMLGregCal(_rs
					.getTimestamp("DUE_DATE_TIME")));

			_task.setIsBulkProcessed((_rs.getString("IS_BULK_PROCESSED")
					.equalsIgnoreCase("YES") ? true : false));

			request_metadataID = _rs.getString("REQUEST_METADATA_ID");

			_request_metadata.setMainServiceCode(_rs
					.getString("MAIN_SERVICE_TYPE_CODE"));

			_request_metadata.setSubServiceCode(_rs
					.getString("SUB_SERVICE_TYPE_CODE"));
			_request_metadata.setGovId(_rs.getInt("ENTITY_GOV_ID"));

			_request_metadata.setReceiveDateTime(FieldsProcessing
					.getXMLGregCal(_rs
							.getTimestamp("REQUEST_CREATED_DATE_TIME")));
			_request_metadata.setRequesterGeoLocation(_rs
					.getString("REQUESTER_GEO_LOC"));
			String _geo_loc_desc = _rs.getString("REQUESTER_GEO_LOC_DESC");
			if (_geo_loc_desc != null) {
				String[] _geo_loc_values = _geo_loc_desc.split("-");

				if (_geo_loc_values.length > 0) {
					_request_metadata.setRequesterRegion(_geo_loc_values[0]);
				}
				if (_geo_loc_values.length > 1) {
						_request_metadata.setRequesterCity(_geo_loc_values[1]);
				}
				if (_geo_loc_values.length > 2) {
					_request_metadata.setRequesterDepartment(_geo_loc_values[2]);
				}
				if (_geo_loc_values.length > 3) {
					_request_metadata.setRequesterDepartmentType(_geo_loc_values[3]);
				}
			}

			InvolvedEntityType involvedEntityTypeItem = new InvolvedEntityType();
			involvedEntityTypeItem.setName(_rs.getString("NAME"));
			involvedEntityTypeItem.setIdType(_rs.getString("ID_TYPE_TITLE"));
			involvedEntityTypeItem.setIdNo(_rs.getString("ID_NO"));
			involvedEntityTypeItem.setEntityType(_rs.getString("TYPE_CODE"));
			involvedEntityTypeItem.setNationality(_rs
					.getString("NATIONALITY_TITLE"));
			if (involvedEntityTypeItem.getName() != null)
				_itemlist.add(involvedEntityTypeItem);

			// _request_metadata.setRequesterGeoArea(_rs.getString(""));
			// _request_metadata.setRequesterDepartment(_rs.getString("REQUESTER_DEPARTMENT"));
			_request_metadata.setRequesterPosition(_rs
					.getString("REQUESTER_POSITION"));
			_request_metadata.setRequesterName(_rs.getString("REQUESTER_NAME"));
			_request_metadata.setConfidentLevelId(_rs
					.getString("CONFIDENT_LEVEL_ID"));
			_request_metadata.setRequestClassification(_rs
					.getString("REQUEST_CLASSIFICATION"));
			_request_metadata.setSRN(_rs.getString("SRN"));// _rs.getString("SRN")
			_request_metadata.setRRN(_rs.getString("RRN"));// _rs.getString("SRN")

			if (_itemlist.size() > 0) {
				// _request_metadata.involvedEntityList = _itemlist;
				JAXBProtectedHandler.setRMInvolvedEntityType(_request_metadata,
						_itemlist);
			} else {
				// _request_metadata.involvedEntityList = null;
				JAXBProtectedHandler.setRMInvolvedEntityType(_request_metadata,
						null);
			}

			PreparedStatement _psts = _conn
					.prepareStatement(_sql_task_status_events);
			_psts.setInt(1, Integer.valueOf(_input.getTaskId()));
			ResultSet _rsts = _psts.executeQuery();
			List<WorkflowStatusHistoryType> _hitemlist = new ArrayList<WorkflowStatusHistoryType>();
			while (_rsts.next()) {
				WorkflowStatusHistoryType _item = new WorkflowStatusHistoryType();
				_item.setTaskId(_rsts.getInt("TASK_ID"));
				_item.setTaskStatusId(_rsts.getInt("STATUS_ID"));
				_item.setTaskSubStatusId(_rsts.getInt("SUB_STATUS_ID"));
				_item.setEventDateTime(FieldsProcessing.getXMLGregCal(_rsts
						.getTimestamp("EVENT_DATE_TIME")));
				_item.setExecutedBy(_rsts.getString("EXECUTED_BY"));
				_item.setExecutedByRole(_rsts.getString("EXECUTED_BY_ROLE"));
				_item.setNotes(_rsts.getString("NOTES"));
				_hitemlist.add(_item);
			}
//			_task.workflowStatusHistory = _hitemlist;
			JAXBProtectedHandler.setWorkFlowStatusHistory(_task,_hitemlist);
			_rsts.close();
			_psts.close();

			String subServiceCode = _rs.getString("SUB_SERVICE_TYPE_CODE");
			String mainServiceCode = _rs.getString("MAIN_SERVICE_TYPE_CODE");

			if (mainServiceCode != null) {
				_request_metadata.setMainServiceCode(ServiceProcessor
						.getMainServiceName(mainServiceCode));
			}

			if (subServiceCode != null) {
				_request_metadata.setSubServiceCode(ServiceProcessor
						.getSubServiceName(subServiceCode));
			}
			
			if (subServiceCode.equals(ServiceCode.ACC)) {
				PreparedStatement _psr = _conn
						.prepareStatement(_sql_acct_info_req);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
				AccountInfoType _item = new AccountInfoType();
				// _item.setId(_rsr.getInt("ACC_INFO_REQST_ID"));
				while (_rsr.next()) {
					_item.setAccountNo(_rsr.getString("ACC_NO"));
					_item.setIban(_rsr.getBoolean("IBAN"));
				}
//				JAXBPublicHandler.setRMAccountInfoRequestList(
//						_request_metadata, _item);
				// _request_metadata.accountInfoRequestList = _items;
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.BAL)) {
				PreparedStatement _psr = _conn.prepareStatement(_sql_bala_info_req);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
				AccountInfoType _item = new AccountInfoType();
				// _item.setId(_rsr.getInt("ACC_BAL_INFO_REQST_ID"));

				while (_rsr.next()) {

					_item.setAccountNo(_rsr.getString("ACC_NO"));
					_item.setIban(_rsr.getBoolean("IBAN"));

				}
				// _request_metadata.setMainServiceCode("INQ");
				// _request_metadata.accountInfoRequestList = _items;
//				JAXBProtectedHandler.setRMAccountInfoRequestList(
//						_request_metadata, _item);
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.DEP)) {
				PreparedStatement _psr = _conn
						.prepareStatement(_sql_depo_info_req);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
				DepositeInfoType _item = new DepositeInfoType();
				// _item.setId(_rsr.getInt("DEPOSIT_INFO_REQST_ID"));
				while (_rsr.next()) {
					_item.setDepositeNo(_rsr.getString("DEPOSIIT_NO"));
				}
				// _request_metadata.setMainServiceCode("INQ");
//				JAXBPublicHandler.setDepositeInfoTypeRequestList(
//						_request_metadata, _item);
				// _request_metadata.depositeInfoRequestList = _items;
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.LIAB)) {
				PreparedStatement _psr = _conn
						.prepareStatement(_sql_liab_info_req);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
				List<LiabilityInfoType> _items = new ArrayList<LiabilityInfoType>();
				while (_rsr.next()) {
					LiabilityInfoType _item = new LiabilityInfoType();
					_item.setId(_rsr.getInt("LIAB_INFO_REQST_ID"));
					_items.add(_item);
				}
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.SAF)) {
				PreparedStatement _psr = _conn
						.prepareStatement(_sql_safe_info_req);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
				SafeInfoType _item = new SafeInfoType();
				// _item.setId(_rsr.getInt("SAFE_INFO_REQST_ID"));
				// _item.setSafeBranch(_rsr.getString("SAFE_BRANCH"));
				
				while (_rsr.next()) {

					_item.setBoxNo(_rsr.getString("BOX_NO"));
				}
//				JAXBPublicHandler.setSafeInfoTypeRequestList(_request_metadata,
//						_item);
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.DENY)) {
				PreparedStatement _psr = _conn.prepareStatement(sqlDenyInfoReq);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
				DlngDcsnInfoType _item = new DlngDcsnInfoType();
				while (_rsr.next()) {
					_item.setNum(_rsr.getString("DECISION_NUMBER"));
					_item.setDt(_rsr.getString("DECISION_ISSUE_DATE"));

				}
//				JAXBPublicHandler.setDenyDlngDcsnInfoType(_request_metadata,
//						_item);
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.BAN)) {
				PreparedStatement _psr = _conn.prepareStatement(sqlBanInfoReq);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
				DlngDcsnInfoType _item = new DlngDcsnInfoType();
				while (_rsr.next()) {
					_item.setNum(_rsr.getString("DECISION_NUMBER"));
					_item.setDt(_rsr.getString("DECISION_ISSUE_DATE"));
				}
//				JAXBPublicHandler.setBanDlngDcsnInfoType(_request_metadata,
//						_item);
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.LIFT)) {// LiftBanExe
				PreparedStatement psr = _conn.prepareStatement(sqlLiftReq);
				psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = psr.executeQuery();

				LiftRestrictionInfoType _item = new LiftRestrictionInfoType();
				TLiftDcsnInfo tLiftDcsnInfo = new TLiftDcsnInfo();
				TSrvcRefInfo tSrvcRefInfo = new TSrvcRefInfo();
				TPreTanfeeth tPreTanfeeth = new TPreTanfeeth();
				TBlockLiftCndtn tBlockLiftCndtn = new TBlockLiftCndtn();
				TTanfeeth tTanfeeth = new TTanfeeth(); // TODO Builder pattern
														// should be used for
														// this obj
				TBlockFundXfer fundXfer = new TBlockFundXfer();
				TBenf tBenf = new TBenf();

				while (_rsr.next()) {
					tLiftDcsnInfo.setDt(_rsr.getString("DCSN_DATE"));
					tLiftDcsnInfo.setNum(_rsr.getString("DCSN_NUM"));
					tPreTanfeeth.setLtrRN(_rsr.getString("LETTER_RN"));
					tPreTanfeeth.setSnetRN(_rsr.getString("SAMANET_RN"));
					tTanfeeth.setRRN(_rsr.getString("RRN"));
					tTanfeeth.setSRN(_rsr.getString("PREV_SRN"));
					tBenf.setBIC(_rsr.getString("BENF_BIC"));
					tBenf.setIBAN(_rsr.getString("BENF_IBAN"));
					tBenf.setName(_rsr.getString("BENF_NAME"));
					fundXfer.setAmt(_rsr.getBigDecimal("AMT"));
					fundXfer.setBenf(tBenf);
				}

				tSrvcRefInfo.setPreTanfeeth(tPreTanfeeth);
				tSrvcRefInfo.setTanfeeth(tTanfeeth);
				tBlockLiftCndtn.setFundXfer(fundXfer);
				tBlockLiftCndtn.setLiftRmngAmt("false");// TODO : this value
														// should be calculated
														// and changed

				_item.setDcsnInfo(tLiftDcsnInfo);
				_item.setSrvcRefInfo(tSrvcRefInfo);
				_item.setBlockLiftCndtn(tBlockLiftCndtn);

				JAXBProtectedHandler.setLiftRestrictionInfoType(_request_metadata,
						_item);
				_rsr.close();
				psr.close();
			} else if (subServiceCode.equals(ServiceCode.BLOCK)) {

				PreparedStatement _psr = _conn.prepareStatement(sqlBlockReq);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
				BlockType _item = new BlockType();
				TAccId tAccId = new TAccId();
				TAmt tAmt = new TAmt();
				TBlockDcsnInfo tBlockDcsnInfo = new TBlockDcsnInfo();
				while (_rsr.next()) {
					tAccId.setBIC(_rsr.getString("BAI_NUM"));
					tAccId.setIBAN(_rsr.getString("BAI_IBAN"));
					tAccId.setNum(_rsr.getString("BAI_BIC"));

					tAmt.setCur(_rsr.getString("AMT_CUR"));
					tAmt.setVal(_rsr.getBigDecimal("AMT_VAL"));

					tBlockDcsnInfo.setAccId(tAccId);
					tBlockDcsnInfo.setAmt(tAmt);
					tBlockDcsnInfo.setDbtType(_rsr.getString("DBT_TYPE"));
					tBlockDcsnInfo.setDt(_rsr.getString("DCSN_DATE"));
					tBlockDcsnInfo.setNum(_rsr.getString("DCSN_NUM"));

					_item.setDcsnInfo(tBlockDcsnInfo);
					_item.setPndngAmt(_rsr.getBigDecimal("AMT_VAL"));// TODO :
																		// this
																		// value
																		// should
																		// be
																		// calculated
																		// and
																		// changed

				}

				JAXBProtectedHandler.setBlockType(_request_metadata, _item);
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.GAR)) {
				PreparedStatement _psr = _conn.prepareStatement(sqlBanInfoReq);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
				GarnishType _item = new GarnishType();
				TAccId tAccId = new TAccId();
				while (_rsr.next()) {
					// TODO : fill values
					tAccId.setBIC(_rsr.getString(""));
					tAccId.setIBAN(_rsr.getString(""));
					tAccId.setNum(_rsr.getString(""));
					_item.setAccId(null);
					_item.setDcsnInfo(null);
					_item.setPndngAmt(null);
				}

				// TODO : Toggle comment
				// JAXBPublicHandler.setBanDlngDcsnInfoType(_request_metadata,_item);
				_rsr.close();
				_psr.close();
			}
			_task.setRequestMetadata(_request_metadata);
			_output.setTask(_task);

		}
		_rs.close();
		_ps.close();
		return _output;
	}

}
