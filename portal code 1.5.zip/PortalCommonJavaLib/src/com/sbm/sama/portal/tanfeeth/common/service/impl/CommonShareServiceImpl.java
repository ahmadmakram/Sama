package com.sbm.sama.portal.tanfeeth.common.service.impl;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.jaxb.common.ShareInfoResponseType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TShrsList;
import com.sbm.sama.portal.tanfeeth.common.dao.impl.*;
import com.sbm.sama.portal.tanfeeth.common.dao.*;
import com.sbm.sama.portal.tanfeeth.common.service.CommonShareService;

/**
 * 
 * @author Mahmoud Fahmi
 *
 */
public class CommonShareServiceImpl implements CommonShareService{

	private CommonShareInfoDao commonShareInfoDao = new CommonShareInfoDaoImpl();
	@Override
	public void addShareService(Connection conn,
			TShrsList _shareInfo_list,int taskId, String prodcutType) throws SQLException {
		commonShareInfoDao.addShare(conn, _shareInfo_list , taskId, prodcutType);		
	}

	@Override
	public void deleteShareService(int taskId, Connection _conn)
			throws SQLException {
		commonShareInfoDao.deleteShare(taskId, _conn);		
	}

	@Override
	public List<ShareInfoResponseType> selectShareService(int taskId,
			Connection _conn) throws SQLException {
		return commonShareInfoDao.selectShare(taskId, _conn)	;	

	}

	@Override
	public TShrsList selectShareServiceCallBack(int taskId, Connection _conn)
			throws SQLException {
		return commonShareInfoDao.selectShareCallBack(taskId, _conn)	;	

	}

}
