package com.sbm.sama.portal.tanfeeth.common.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.jaxb.common.ShareInfoResponseType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TShrsList;

/**
 * 
 * @author Mahmoud Fahmi
 *
 */
public interface CommonShareService {
	public void addShareService(Connection conn,TShrsList _shareInfo_list,int taskId, String prodcutType) throws SQLException;
	public void deleteShareService(int taskId,Connection _conn) throws SQLException;
	public List<ShareInfoResponseType> selectShareService(int taskId,Connection _conn) throws SQLException;
	public TShrsList selectShareServiceCallBack(int taskId,Connection _conn) throws SQLException;

}
