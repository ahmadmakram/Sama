package com.sbm.sama.portal.tanfeeth.common.enums;

public enum UpdateBulkBusinessRule {
	OFFICER_MANAGER_Q ("1412"),
	MANAGER_SUBMIT ("2604"),
	MANAGER_OFFICER_INBOX ("2234");
	
	String updateBulkBusinessRule = null;
	
	UpdateBulkBusinessRule (String updateBulkBusinessRule){
		this.updateBulkBusinessRule = updateBulkBusinessRule;
	}
	
	public String getValue(){
		return this.updateBulkBusinessRule;
	}
}
