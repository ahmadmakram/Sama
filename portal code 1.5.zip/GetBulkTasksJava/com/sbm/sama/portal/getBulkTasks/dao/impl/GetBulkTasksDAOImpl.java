package com.sbm.sama.portal.getBulkTasks.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.getBulkTasks.dao.GetBulkTasksDAO;
import com.sbm.sama.portal.tanfeeth.common.util.FieldsProcessing;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetBulkTasksInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetBulkTasksOutputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.InvolvedEntityType;

public class GetBulkTasksDAOImpl implements GetBulkTasksDAO {

	@Override
	public List<GetBulkTasksOutputType> GetBulkTasks(
			GetBulkTasksInputType _input, Connection _conn)
			throws SQLException, DatatypeConfigurationException {
		int _filter_index = 0;
		String _sort_dir = " ASC";
		if (_input.isSortDesc() != null) {
			if (_input.isSortDesc())
				_sort_dir = " DESC";
		}

		String _sql = "select * from TASK_BULK_VIEW ";
		_sql += BuildSQLFilter(_input) + getOrderby(_input) + _sort_dir;

		List<GetBulkTasksOutputType> _output = new ArrayList<GetBulkTasksOutputType>();
		PreparedStatement _ps = _conn.prepareStatement(_sql);
		// _ps.setString(++_filter_index, _input.getSubServiceCode());
		if (_input.getGovEntityId() != null)
			_ps.setInt(++_filter_index,
					Integer.valueOf(_input.getGovEntityId()));
		if (_input.getFiCode() != null)
			_ps.setString(++_filter_index, _input.getFiCode().toString());
		if (_input.getRequestReceiveDateTime() != null)
			_ps.setTimestamp(++_filter_index, FieldsProcessing
					.getTimestamp(_input.getRequestReceiveDateTime()));
		if (_input.getFiStartDate() != null)
			_ps.setTimestamp(++_filter_index,
					FieldsProcessing.getTimestamp(_input.getFiStartDate()));
		if (_input.getFiEndDate() != null)
			_ps.setTimestamp(++_filter_index,
					FieldsProcessing.getTimestamp(_input.getFiEndDate()));
		if (_input.getRequestId() != null)
			_ps.setString(++_filter_index, _input.getRequestId());
		if (_input.getInvolvedEntityIdNo() != null)
			_ps.setString(++_filter_index, _input.getInvolvedEntityIdNo());
		if (_input.getTaskStatusId() != null)
			_ps.setInt(++_filter_index, _input.getTaskStatusId());
		if (_input.getTaskSubStatusId() != null)
			_ps.setInt(++_filter_index, _input.getTaskSubStatusId());
		 if (_input.getTaskHistoryStatusId() != null)
		 _ps.setInt(++_filter_index, _input.getTaskHistoryStatusId());
		 if (_input.getTaskHistorySubStatusId() != null)
		 _ps.setInt(++_filter_index, _input.getTaskHistorySubStatusId());

		 if (_input.getAssignedTo() != null)
				_ps.setString(++_filter_index, _input.getAssignedTo());
			if (_input.getAssignedBy() != null)
				_ps.setString(++_filter_index, _input.getAssignedBy());
			
			
		if (FieldsProcessing.validateFilterString(_input.getExecutedBy()))
			_ps.setString(++_filter_index, _input.getExecutedBy());
		 if (_input.getDueDateTime() != null)
		 _ps.setTimestamp(++_filter_index, FieldsProcessing.getTimestamp(_input.getDueDateTime()));
		if (_input.isIsBulkProcessed() != null)
			_ps.setString(++_filter_index, (_input.isIsBulkProcessed() ? "YES"
					: "NO"));
		if (_input.isRequireMakerChecker() != null)
			_ps.setString(++_filter_index,
					(_input.isRequireMakerChecker() ? "YES" : "NO"));
		if (FieldsProcessing.validateFilterString(_input.getSRN()))
			_ps.setString(++_filter_index, _input.getSRN());
		if (FieldsProcessing.validateFilterString(_input
				.getInvolvedEntityIdType()))
			_ps.setString(++_filter_index, _input.getInvolvedEntityIdType());

		ResultSet _rs = _ps.executeQuery();

		while (_rs.next()) {
			GetBulkTasksOutputType _item = new GetBulkTasksOutputType();
			_item.setTaskId(_rs.getInt("TASK_ID"));
			_item.setSRN(_rs.getString("SRN"));
			_item.setSubServiceCode(_rs.getString("SUB_SERVICE_TYPE_NAME"));
			
			InvolvedEntityType _involved = new InvolvedEntityType();
			_involved.setName(_rs.getString("INVOLVED_ENTITY_NAME"));
			_involved.setIdNo(_rs.getString("INVOLVED_ENTITY_ID_NO"));
			_involved.setIdType(_rs.getString("INVOLVED_ENTITY_ID_TYPE"));

			_item.setInvolvedEntityList(_involved);
			_item.setGovEntityName(_rs.getString("ENTITY_GOV_NAME"));

			_output.add(_item);

		}
		_rs.close();
		_ps.close();

		return _output;
	}

	// private int getSLARemainingMinutes(Timestamp _due_ts) {
	// int _min = 0;
	// if (_due_ts != null) {
	// Date _now = new Date();
	// _min = (int) (_due_ts.getTime() - _now.getTime());
	// _min = _min / 1000 / 60;
	// }
	//
	// return _min;
	// }

	private String BuildSQLFilter(GetBulkTasksInputType _input) {
		String _output = " WHERE SUB_SERVICE_TYPE_CODE IN (";

		String[] _service_codes = _input.getSubServiceCode().split(",");
		for (int i = 0; i < _service_codes.length; i++) {
			_output += (i == 0 ? "'" : ",'") + _service_codes[i] + "'";
		}
		_output += ")";

		if (_input.getGovEntityId() != null)
			_output += " AND ENTITY_GOV_ID=?";
		if (_input.getFiCode() != null)
			_output += " AND FI_ID=?";
		if (_input.getRequestReceiveDateTime() != null)
			_output += " AND REQUEST_CREATED_DATE_TIME=?";
		if (_input.getFiStartDate() != null)
			_output += " AND REQUEST_CREATED_DATE_TIME>=?";
		if (_input.getFiEndDate() != null)
			_output += " AND REQUEST_CREATED_DATE_TIME<=?";
		if (_input.getRequestId() != null)
			_output += " AND REQUEST_CREATED_DATE_TIME=?";
		if (_input.getInvolvedEntityIdNo() != null)
			_output += " AND ID_NO=?";
		if (_input.getTaskStatusId() != null)
			_output += " AND STATUS_ID=?";
		if (_input.getTaskSubStatusId() != null)
			_output += " AND SUB_STATUS_ID=?";
		 if (_input.getTaskHistoryStatusId() != null)
		 _output +=
		 " AND TASK_ID IN (SELECT TASK_ID FROM FIPORTAL.WORKFLOW_STATUS_EVENT_HISTORY WHERE STATUS_ID=?)";
		 if (_input.getTaskHistorySubStatusId() != null)
		 _output +=
		 " AND TASK_ID IN (SELECT TASK_ID FROM FIPORTAL.WORKFLOW_STATUS_EVENT_HISTORY WHERE SUB_STATUS_ID=?)";

		
		 if (_input.getAssignedTo() != null)
				_output += " AND ASSIGNED_TO=?";
		 
		 if (FieldsProcessing.validateFilterString(_input.getExecutedBy()))
			_output += " AND TASK_ID IN (SELECT TASK_ID FROM FIPORTAL.WORKFLOW_STATUS_EVENT_HISTORY WHERE EXECUTED_BY=?)";
		 if (_input.getDueDateTime() != null)
		 _output += " AND DUE_DATE_TIME=?";
		if (_input.isIsBulkProcessed() != null)
			_output += " AND IS_BULK_PROCESSED=?";
		if (_input.isRequireMakerChecker() != null)
			_output += " AND REQUIRE_CHECKER=?";
		if (_input.getSRN() != null)
			_output += " AND SRN=?";
		if (_input.getInvolvedEntityIdType() != null)
			_output += " AND ID_TYPE=?";

		return _output;
	}

	private String getOrderby(GetBulkTasksInputType _input) {
		String _out = "ORDER BY REQUEST_CREATED_DATE_TIME";
		if (_input.getOrderBy() != null) {
			if (_input.getOrderBy().equalsIgnoreCase("request_id"))
				_out = " ORDER BY TASK_REQUEST_METADATA_ID";
			else if (_input.getOrderBy().equalsIgnoreCase("task_id"))
				_out = " ORDER BY TASK_ID";
			else if (_input.getOrderBy().equalsIgnoreCase("status_id"))
				_out = " ORDER BY STATUS_ID";
			else if (_input.getOrderBy().equalsIgnoreCase("main_service_code"))
				_out = " ORDER BY MAIN_SERVICE_TYPE_CODE";
			else if (_input.getOrderBy().equalsIgnoreCase("sub_service_code"))
				_out = " ORDER BY SUB_SERVICE_TYPE_CODE";
			else if (_input.getOrderBy().equalsIgnoreCase(
					"main_service_type_name"))
				_out = " ORDER BY MAIN_SERVICE_TYPE_NAME";
			else if (_input.getOrderBy().equalsIgnoreCase(
					"sub_service_type_name"))
				_out = " ORDER BY SUB_SERVICE_TYPE_NAME";
			else if (_input.getOrderBy().equalsIgnoreCase("assigned_to"))
				_out = " ORDER BY ASSIGNED_TO";
			else if (_input.getOrderBy().equalsIgnoreCase("assigned_by"))
				_out = " ORDER BY ASSIGNED_BY";
			else if (_input.getOrderBy().equalsIgnoreCase("is_bulk_processed"))
				_out = " ORDER BY IS_BULK_PROCESSED";
			else if (_input.getOrderBy().equalsIgnoreCase(
					"request_receive_date_time"))
				_out = " ORDER BY CREATED_DATE_TIME";
			else if (_input.getOrderBy().equalsIgnoreCase(
					"last_executed_by_Status3"))
				_out = " ORDER BY EXECUTED_BY_3";
			else if (_input.getOrderBy().equalsIgnoreCase(
					"last_executed_by_Status6"))
				_out = " ORDER BY EXECUTED_BY_6";
		}
		return _out;
	}

}
