package com.sbm.sama.fiportal.services.dispatchresponses.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.common.service.CommonUserService;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonUserServiceImpl;
import com.sbm.sama.portal.tanfeeth.jaxb.common.JAXBProtectedHandler;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFIGetLiabsInfoCallBackRq;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TLiabInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TLiabsList;


public class LiabilityInfoResponsesDAO {

	public TFIGetLiabsInfoCallBackRq GetLiabilitiesInfoMessageBody(int _task_id, Connection _conn) throws SQLException {
		SimpleDateFormat _sdf = new SimpleDateFormat("YYYY-MM-dd");
		String _sql_liab_info_res = "SELECT ID, TASK_ID, FI_ID, ACCOUNT_NO, IBAN, LIABILITY_TYPE, CURRENCY, NUMBER_OF_INSTALLEMENTS, INSTALLEMENT_REP_INTERVAL, INSTALLMENT_AMOUNT, LAST_PAYMENT_DATE, LIABILITY_DUE_DATE, TOTAL_LIABILITY_AMOUNT, REMAINING_LIABILITY, CREATED_DATE_TIME FROM FIPORTAL.LIABILITY_INFO_RESPONSE WHERE TASK_ID =?";
		//mabdelrahman
		
		TFIGetLiabsInfoCallBackRq _output = new TFIGetLiabsInfoCallBackRq();
		CommonUserService cudi = new CommonUserServiceImpl();

		PreparedStatement _psr = _conn.prepareStatement(_sql_liab_info_res);
		
		_psr.setInt(1, _task_id);
		ResultSet _rsr = _psr.executeQuery();
		List<TLiabInfo> _items = new ArrayList<TLiabInfo>();
		while (_rsr.next()) {
			TLiabInfo _item = new TLiabInfo();
			_item.setAccNum(_rsr.getString("ACCOUNT_NO"));
			_item.setIBAN(_rsr.getString("IBAN"));
			_item.setLiabType(_rsr.getString("LIABILITY_TYPE"));
			_item.setLiabCur(_rsr.getString("CURRENCY"));
			_item.setLiabInstsNum(_rsr.getString("NUMBER_OF_INSTALLEMENTS"));
			_item.setInstRept(_rsr.getString("INSTALLEMENT_REP_INTERVAL"));
			_item.setInstAmt(_rsr.getBigDecimal("INSTALLMENT_AMOUNT"));
			// mabdelrahman LAST_PAYMENT_DATE is optional 

			if (_rsr.getTimestamp("LAST_PAYMENT_DATE") != null) {
				_item.setLstPymtDt(_sdf.format(_rsr.getTimestamp("LAST_PAYMENT_DATE")));
			}
			_item.setLiabDueDt(_sdf.format(_rsr.getTimestamp("LIABILITY_DUE_DATE")));
			_item.setTotLiabAmt(_rsr.getBigDecimal("TOTAL_LIABILITY_AMOUNT"));
			_item.setRmngLiabAmt(_rsr.getBigDecimal("REMAINING_LIABILITY"));

			//mabdelrahman

			int _resp_id = _rsr.getInt("ID");
			_item.setPrdUsrsList(cudi.selectUserCallBack(_conn, _resp_id));

			_items.add(_item);
		}
		TLiabsList _liabsList = new TLiabsList();
		JAXBProtectedHandler.setLiabInfo(_liabsList, _items);
//		_liabsList.liabInfo = _items;
		_output.setLiabsList(_liabsList);
		//mabdelrahman
		if(_psr != null) _psr.close();
		
		return _output;
	}

}
