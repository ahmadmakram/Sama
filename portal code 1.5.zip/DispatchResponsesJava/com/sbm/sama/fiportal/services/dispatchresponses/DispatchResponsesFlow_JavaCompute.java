package com.sbm.sama.fiportal.services.dispatchresponses;

import java.io.IOException;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.bind.JAXBException;
import javax.xml.datatype.DatatypeConfigurationException;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.sbm.sama.fiportal.services.util.LoggingHelper;
import com.sbm.sama.portal.tanfeeth.common.util.MainLogger;

public class DispatchResponsesFlow_JavaCompute extends MbJavaComputeNode {

	private int _counter = 0;
	private static Logger logger = LoggingHelper.getLogger();
	private static String httpInd= "";
	private static String URLPrefix= "";
	
	public void onInitialize() throws MbException {
		LoggingHelper.ConfigureLogger(DispatchResponsesFlow_JavaCompute.class.getPackage().getName(), Level.ALL);
		//mabdelrahman
		//LoggingHelper.ConfigureLogger(DispatchResponses, Level.ALL);
		httpInd = getUserDefinedAttribute("IsHTTPS").toString();
		URLPrefix = getUserDefinedAttribute("CallBackURL").toString();
	}
	
	public synchronized void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
	
		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		Connection _conn = null;
		try {
			
			_conn = getJDBCType4Connection("XE", JDBC_TransactionType.MB_TRANSACTION_AUTO);
			if (_conn != null) {
				logger.log(Level.INFO, "Connection IS NOT NULL");
				
			} else {
				logger.log(Level.INFO, "Connection IS NULL ************");
			}
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below
			String _xml = new String(inMessage.getBuffer());
			logger.log(Level.INFO, "######### inMessage messages is ====>>> " + _xml);
			DispatchCallBackJobs _dispatcher = new DispatchCallBackJobs();

			if (_dispatcher.runQueuedCallbackJobs(_conn,httpInd,URLPrefix)) {
				logger.log(Level.INFO, "Successfully Running Dispatch messages !!!!!!!!!!!");
			} else {
				logger.log(Level.INFO, "Some problem occured during execution of Dispatch Messages Jobs !!!!!!!!!!!");
			}

			_counter++;
			logger.log(Level.INFO, "Counter ==>> " + _counter);
		//	if(_conn != null)_conn.close();  //let IIB handle it 

			// End of user code
			// ----------------------------------------------------------
		} catch (MbException | RuntimeException  | JAXBException | IOException | DatatypeConfigurationException e) {
			
			MainLogger.logData("DispatchResponsesFlow", e.getMessage());
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be
			// handled in the flow
			logger.log(Level.SEVERE, "=== Evaluate Method Exception ...............");
			logger.log(Level.SEVERE, e.getMessage(), e);
			e.printStackTrace();
			throw new MbUserException(this, "evaluate()", "", "", e.getMessage(), null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);

	}

}
