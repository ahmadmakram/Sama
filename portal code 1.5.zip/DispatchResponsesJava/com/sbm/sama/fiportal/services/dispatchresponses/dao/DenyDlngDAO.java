package com.sbm.sama.fiportal.services.dispatchresponses.dao;


public class DenyDlngDAO {

//	public TFIDenyDlngCallBackRq GetDenyTaskMessageBody(int _task_id,
//			Connection _conn) {String _sql_Deny_response = "SELECT * FROM FIPORTAL.Deny_DEALING_RESPONSE WHERE TASK_ID=?";
//			TFIDenyDlngCallBackRq _output = new TFIDenyDlngCallBackRq();
//
//			try {
//				PreparedStatement _psr = _conn.prepareStatement(_sql_Deny_response);
//
//				_psr.setInt(1, _task_id);
//				ResultSet _rsr = _psr.executeQuery();
//				if (_rsr.next()) {
//
//					TCustInfo custInfo = new TCustInfo();
//					custInfo.setCustName(_rsr.getString("CUST_NAME"));
//					custInfo.setId(_rsr.getString("CUST_ID"));
//					custInfo.setIdType(_rsr.getString("CUST_IDTYPE"));
//					custInfo.setNtnlty(_rsr.getString("CUST_NTNLTY"));
//					_output.setCustInfo(custInfo);
//					_output.setExeDtTm(_rsr.getTimestamp("EXE_DTTM").toString());
//				}
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//
//			return _output;
//		}

	
}
