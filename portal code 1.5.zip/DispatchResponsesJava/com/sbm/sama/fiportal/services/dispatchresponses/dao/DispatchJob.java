package com.sbm.sama.fiportal.services.dispatchresponses.dao;

import java.io.Serializable;
import java.util.GregorianCalendar;

public class DispatchJob implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int _id;
	private int _request_metadata_id;
	private int _task_id;
	private GregorianCalendar _created_date_time;
	private GregorianCalendar _executed_date_time;
	private boolean _is_job_executed;
	private String _response_message;
	private String _request_message;
	private int _retry_count;
	private String _main_service_code;
	private String _sub_service_code;
	private boolean _bulk_processed;
	private int _manual_try;
	
	public DispatchJob(){}

	
	public DispatchJob(int _id, int _request_metadata_id, int _task_id, GregorianCalendar _created_date_time, GregorianCalendar _executed_date_time, boolean _is_job_executed, String _response_message, int _retry_cout, String _main_service_code, String _sub_service_code) {
		super();
		this._id = _id;
		this._request_metadata_id = _request_metadata_id;
		this._task_id = _task_id;
		this._created_date_time = _created_date_time;
		this._executed_date_time = _executed_date_time;
		this._is_job_executed = _is_job_executed;
		this._response_message = _response_message;
		this._retry_count = _retry_cout;
		this._main_service_code = _main_service_code;
		this._sub_service_code = _sub_service_code;
	}


	public int get_id() {
		return _id;
	}

	public void set_id(int _id) {
		this._id = _id;
	}

	public int get_request_metadata_id() {
		return _request_metadata_id;
	}

	public void set_request_metadata_id(int _request_metadata_id) {
		this._request_metadata_id = _request_metadata_id;
	}

	public int get_task_id() {
		return _task_id;
	}

	public void set_task_id(int _task_id) {
		this._task_id = _task_id;
	}

	public GregorianCalendar get_created_date_time() {
		return _created_date_time;
	}

	public void set_created_date_time(GregorianCalendar _created_date_time) {
		this._created_date_time = _created_date_time;
	}

	public GregorianCalendar get_executed_date_time() {
		return _executed_date_time;
	}

	public void set_executed_date_time(GregorianCalendar _executed_date_time) {
		this._executed_date_time = _executed_date_time;
	}

	public boolean is_is_job_executed() {
		return _is_job_executed;
	}

	public void set_is_job_executed(boolean _is_job_executed) {
		this._is_job_executed = _is_job_executed;
	}

	public String get_response_message() {
		return _response_message;
	}

	public void set_response_message(String _response_message) {
		this._response_message = _response_message;
	}

	public String get_request_message() {
		return _request_message;
	}

	public void set_request_message(String _request_message) {
		this._request_message = _request_message;
	}

	public int get_retry_count() {
		return _retry_count;
	}

	public void set_retry_count(int _retry_cout) {
		this._retry_count = _retry_cout;
	}

	public String get_main_service_code() {
		return _main_service_code;
	}

	public void set_main_service_code(String _main_service_code) {
		this._main_service_code = _main_service_code;
	}
	
	public String get_sub_service_code() {
		return _sub_service_code;
	}
	
	public void set_sub_service_code(String _sub_service_code) {
		this._sub_service_code = _sub_service_code;
	}

	public boolean is_bulk_processed() {
		return _bulk_processed;
	}

	public void set_bulk_processed(boolean _bulk_processed) {
		this._bulk_processed = _bulk_processed;
	}

	public int get_manual_try() {
		return _manual_try;
	}

	public void set_manual_try(int _manual_try) {
		this._manual_try = _manual_try;
	}

}
