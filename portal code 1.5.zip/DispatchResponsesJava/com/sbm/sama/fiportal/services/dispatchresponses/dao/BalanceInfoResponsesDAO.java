package com.sbm.sama.fiportal.services.dispatchresponses.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.tanfeeth.common.service.CommonShareService;
import com.sbm.sama.portal.tanfeeth.common.service.CommonUserService;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonShareServiceImpl;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonUserServiceImpl;
import com.sbm.sama.portal.tanfeeth.jaxb.common.JAXBProtectedHandler;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TAccountInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TAcctsList;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFIGetBalsInfoCallBackRq;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TRsrvInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TRsrvList;

public class BalanceInfoResponsesDAO {

	public TFIGetBalsInfoCallBackRq GetBalanceInfoMessageBody(int _task_id,
			Connection _conn) throws SQLException,
			DatatypeConfigurationException {
		SimpleDateFormat _sdf = new SimpleDateFormat("YYYY-MM-dd");
		String _sql_bal_info_res = "SELECT ID, TASK_ID, FI_ID, ACCOUNT_NO, IBAN, ACCOUNT_TYPE, CURRENCY, ACCOUNT_STATUS, INSTITUTION, ACCOUNT_OPENING_DATE, ACCOUNT_CLOSING_DATE, AVAILABLE_BALANCE, TOTAL_BALANCE, BALANCE_DATE, IS_JOINT_ACCOUNT, CREATED_DATE_TIME, IS_DELETED FROM FIPORTAL.ACCOUNT_BALANCE_INFO_RESPONSE WHERE TASK_ID=? ";
		String _sql_reserve_info = "SELECT ID, RESPONSE_ID, RESERVED_AMOUNT, RESERVED_BY, RRN, IS_DELETED FROM FIPORTAL.BALANCE_INFO_RESERVE WHERE RESPONSE_ID=? ";

		TFIGetBalsInfoCallBackRq _output = new TFIGetBalsInfoCallBackRq();
		CommonUserService cudi = new CommonUserServiceImpl();
		CommonShareService csidi = new CommonShareServiceImpl();
		// mabdelrahman
		PreparedStatement _psr = _conn.prepareStatement(_sql_bal_info_res);
		PreparedStatement _psrs = _conn.prepareStatement(_sql_reserve_info);
		int _resp_id = 0;

		_psr.setInt(1, _task_id);
		ResultSet _rsr = _psr.executeQuery();
		List<TAccountInfo> _items = new ArrayList<TAccountInfo>();
		while (_rsr.next()) {
			TAccountInfo _item = new TAccountInfo();
			_item.setAccNum(_rsr.getString("ACCOUNT_NO"));
			_item.setIBAN(_rsr.getString("IBAN"));
			_item.setAccType(_rsr.getString("ACCOUNT_TYPE"));
			_item.setAccCur(_rsr.getString("CURRENCY"));
			_item.setAccStatus(_rsr.getString("ACCOUNT_STATUS"));
			_item.setInst(_rsr.getString("INSTITUTION"));
			if (_rsr.getTimestamp("ACCOUNT_OPENING_DATE") != null)
				_item.setOpnDt(_sdf.format(_rsr
						.getTimestamp("ACCOUNT_OPENING_DATE")));
			if (_rsr.getTimestamp("ACCOUNT_CLOSING_DATE") != null)
				_item.setClsDt(_sdf.format(_rsr
						.getTimestamp("ACCOUNT_CLOSING_DATE")));
			_item.setAvailBal(_rsr.getBigDecimal("AVAILABLE_BALANCE"));
			_item.setTotBal(_rsr.getBigDecimal("TOTAL_BALANCE"));
			if (_rsr.getTimestamp("BALANCE_DATE") != null)
				_item.setBalDt(_sdf.format(_rsr.getTimestamp("BALANCE_DATE")));
			_item.setJntAcc(_rsr.getString("IS_JOINT_ACCOUNT"));

			_resp_id = _rsr.getInt("ID");
			_item.setPrdUsrsList(cudi.selectUserCallBack(_conn, _resp_id));

			_psrs.setInt(1, Integer.valueOf(_resp_id));
			ResultSet _rsrs = _psrs.executeQuery();
			List<TRsrvInfo> _ritems = new ArrayList<TRsrvInfo>();
			;
			while (_rsrs.next()) {
				TRsrvInfo _ritem = new TRsrvInfo();
				_ritem.setRsrvAmt(_rsrs.getBigDecimal("RESERVED_AMOUNT"));
				_ritem.setRsrvBy(_rsrs.getString("RESERVED_BY"));
				_ritem.setRRN(_rsrs.getString("RRN"));
				_ritems.add(_ritem);
			}
			if (_ritems.size() > 0) {
				TRsrvList _rsrvList = new TRsrvList();
				JAXBProtectedHandler.setRsrvInfo(_rsrvList, _ritems);
//				_rsrvList.rsrvInfo = _ritems;
				_item.setRsrvList(_rsrvList);
			}
			_items.add(_item);
		}
		TAcctsList _acctsList = new TAcctsList();
		JAXBProtectedHandler.setAccInfo(_acctsList, _items);
//		_acctsList.accInfo = _items;
		_output.setAcctsList(_acctsList);

		_output.setShrsList(csidi.selectShareServiceCallBack(_resp_id, _conn));

		// mabdelrahman
		if (_psr != null)
			_psr.close();
		if (_psrs != null)
			_psrs.close();
		return _output;
	}

}
