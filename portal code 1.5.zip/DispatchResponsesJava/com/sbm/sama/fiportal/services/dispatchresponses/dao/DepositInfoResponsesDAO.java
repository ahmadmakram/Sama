package com.sbm.sama.fiportal.services.dispatchresponses.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.common.service.CommonUserService;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonUserServiceImpl;
import com.sbm.sama.portal.tanfeeth.jaxb.common.JAXBProtectedHandler;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TDepotInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TDepotsList;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFIGetDepotsInfoCallBackRq;

public class DepositInfoResponsesDAO {

	public TFIGetDepotsInfoCallBackRq GetDepositsInfoMessageBody(int _task_id,
			Connection _conn) throws SQLException {
		SimpleDateFormat _sdf = new SimpleDateFormat("YYYY-MM-dd");
		String _sql_depo_info_res = "SELECT ID, TASK_ID, FI_ID, DEPOSIT_NO, DEPOSIT_TYPE, CURRENCY, DEPOSIT_STATUS, START_DATE, DUE_DATE, DEPOSIT_BALANCE, IS_JOINT_DEPOSIT, CREATED_DATE_TIME FROM FIPORTAL.DEPOSIT_INFO_RESPONSE WHERE TASK_ID=? ";

		TFIGetDepotsInfoCallBackRq _output = new TFIGetDepotsInfoCallBackRq();
		CommonUserService cudi = new CommonUserServiceImpl();

		// mabdelrahman
		PreparedStatement _psr = _conn.prepareStatement(_sql_depo_info_res);
		_psr.setInt(1, _task_id);
		ResultSet _rsr = _psr.executeQuery();
		List<TDepotInfo> _items = new ArrayList<TDepotInfo>();
		while (_rsr.next()) {
			TDepotInfo _item = new TDepotInfo();
			_item.setDepotNum(_rsr.getString("DEPOSIT_NO"));
			_item.setDepotType(_rsr.getString("DEPOSIT_TYPE"));
			_item.setDepotCur(_rsr.getString("CURRENCY"));
			_item.setDepotStatus(_rsr.getString("DEPOSIT_STATUS"));
			if (_rsr.getTimestamp("START_DATE") != null)
				_item.setDepotStrtDt(_sdf.format(_rsr
						.getTimestamp("START_DATE")));
			if (_rsr.getTimestamp("DUE_DATE") != null)
				_item.setDepotDueDt(_sdf.format(_rsr.getTimestamp("DUE_DATE")));
			_item.setDepotBal(_rsr.getBigDecimal("DEPOSIT_BALANCE"));
			_item.setJntAcc(_rsr.getString("IS_JOINT_DEPOSIT"));

			int _resp_id = _rsr.getInt("ID");

			_item.setPrdUsrsList(cudi.selectUserCallBack(_conn, _resp_id));

			_items.add(_item);
		}
		TDepotsList _depotsList = new TDepotsList();
		JAXBProtectedHandler.setDepotInfo(_depotsList, _items);
//		_depotsList.depotInfo = _items;
		_output.setDepotsList(_depotsList);
		// mabdelrahman
		if (_psr != null)
			_psr.close();
		return _output;
	}

}
