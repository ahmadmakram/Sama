package com.sbm.sama.fiportal.services.dispatchresponses.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.sbm.sama.fiportal.services.util.LoggingHelper;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TRqHdr;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TChID;

public class DispatchJobDAOImpl implements DispatchJobDAO {

	private static Logger logger = LoggingHelper.getLogger();

	@Override
	public synchronized List<DispatchJob> GetDispatchJobs(Connection _conn) {
		List<DispatchJob> _jobs = new ArrayList<DispatchJob>();
		String _sql = "SELECT ID, REQUEST_METADATA_ID, TASK_ID, SUB_SERVICE_TYPE_CODE, RETRY_COUNT, IS_BULK, MTRY FROM FIPORTAL.RESPONSE_DISPATCH_JOB_DETAIL WHERE IS_JOB_EXECUTED!='YES' AND RETRY_COUNT<3 fetch first 10 ROWS only";
		try {
			PreparedStatement _ps = _conn.prepareStatement(_sql);
			ResultSet _rs = _ps.executeQuery();
			while (_rs.next()) {
				DispatchJob _job = new DispatchJob();
				_job.set_id(_rs.getInt("ID"));
				_job.set_request_metadata_id(_rs.getInt("REQUEST_METADATA_ID"));
				_job.set_task_id(_rs.getInt("TASK_ID"));
				_job.set_sub_service_code(_rs
						.getString("SUB_SERVICE_TYPE_CODE"));
				_job.set_retry_count(_rs.getInt("RETRY_COUNT"));
				_job.set_bulk_processed((_rs.getString("IS_BULK")
						.equalsIgnoreCase("YES") ? true : false));
				_job.set_manual_try(_rs.getInt("MTRY"));
				logger.log(Level.INFO, "Get Job ID ==>> " + _job.get_id());

				_jobs.add(_job);
			}
			_rs.close();
			_ps.close();
		} catch (SQLException _se) {
			_se.printStackTrace();
		}

		return _jobs;
	}

	@Override
	public TRqHdr GetMessageHeader(DispatchJob _job, Connection _conn)
			throws SQLException {
		TRqHdr _header = null;
		Date _now = new Date();
		SimpleDateFormat _sdf = new SimpleDateFormat("yyyy-MM-dd'T'hh:hh:ss");
		String _sql = "SELECT * FROM FIPORTAL.TANFEETH_TASK_DETAILS_VIEW WHERE TASK_ID=?";
		PreparedStatement _ps = _conn.prepareStatement(_sql);
		_ps.setInt(1, _job.get_task_id());
		ResultSet _rs = _ps.executeQuery();
		if (_rs.next()) {
			_header = new TRqHdr();
			_header.setPID(_rs.getString("FI_CODES"));
			_header.setSys(_rs.getString("SENDER_SYS"));
			_header.setMsgDtTm(_sdf.format(_now));
			_header.setChID(TChID.fromValue("Portal"));
			_header.setMsgUID(_rs.getString("SRN") + "-"
					+ _job.get_task_id()+ "-" + _job.get_retry_count());
			_header.setSRN(_rs.getString("SRN"));
			_header.setCnfd(_rs.getString("CONFIDENT_LEVEL_ID"));
			_header.setMod(_rs.getString("REQST_MOD"));
			_header.setCRN(_rs.getString("MSGUID"));
			_header.setClsf(_rs.getString("REQUEST_CLASSIFICATION"));
			//_header.setPHash(_rs.getString("PHASH")); till gawad add this coulmn in tanfeth DB then we will add it to VIEW 
			_header.setIPAdrs(_rs.getString("SENDER_SYS_IP"));
			_header.setStatus(_rs.getString("CALL_BACK_STATUS"));
		}
		_rs.close();
		_ps.close();
		return _header;
	}

	@Override
	public boolean UpdateDispatchJobs(List<DispatchJob> _jobs, Connection _conn)
			throws SQLException {
		boolean _out = false;
		String _sql = "UPDATE FIPORTAL.RESPONSE_DISPATCH_JOB SET EXECUTED_DATE_TIME=SYSDATE, IS_JOB_EXECUTED=?, RESPONSE_MESSAGE=?, REQUEST_MESSAGE=?, RETRY_COUNT=? WHERE ID=?";
		PreparedStatement _ps = _conn.prepareStatement(_sql);

		for (int i = 0; i < _jobs.size(); i++) {
			DispatchJob _job = _jobs.get(i);

			if (_job.get_request_message().length() > 4000)
				_job.set_request_message(_job.get_request_message().substring(
						0, 3750));
			_ps.setString(1, (_job.is_is_job_executed() ? "YES" : "NO"));
			
			// mabdelrahman
			java.sql.Clob clobRes = oracle.sql.CLOB.createTemporary(_conn, false,
					oracle.sql.CLOB.DURATION_SESSION);
			clobRes.setString(1, _job.get_response_message());
			_ps.setClob(2, clobRes);
		//	_ps.setString(2, _job.get_response_message());
			
			java.sql.Clob clobReq = oracle.sql.CLOB.createTemporary(_conn, false,
					oracle.sql.CLOB.DURATION_SESSION);
			clobReq.setString(1, _job.get_request_message());
			_ps.setClob(3,clobReq);
			
		//	_ps.setString(3, _job.get_request_message());
			_ps.setInt(4, _job.get_retry_count());
			_ps.setInt(5, _job.get_id());
			_ps.executeUpdate();

			logger.log(Level.INFO, "Update Job ID ===>> " + _job.get_id());
			logger.log(Level.INFO,
					"Job get_retry_count ==>> " + _job.get_retry_count());
		}
		_ps.close();
		_out = true;
		return _out;
	}

}
