package com.sbm.sama.fiportal.services.dispatchresponses.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.common.service.CommonUserService;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonUserServiceImpl;
import com.sbm.sama.portal.tanfeeth.jaxb.common.JAXBProtectedHandler;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFIGetSafsInfoCallBackRq;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TSafInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TSafsList;

public class SafeInfoResponsesDAO {

	public TFIGetSafsInfoCallBackRq GetSafesInfoMessageBody(int _task_id, Connection _conn) throws SQLException {
		SimpleDateFormat _sdf = new SimpleDateFormat("YYYY-MM-dd");
		String _sql_safe_info_res = "SELECT ID, TASK_ID, FI_ID, SAFE_BRANCH, BOX_NO, BOX_OPEN_DATE, IS_JOINT_SAFE, CREATED_DATE_TIME FROM FIPORTAL.SAFE_INFO_RESPONSE WHERE TASK_ID=? AND TRIM(IS_DELETED)='NO'";
		
		TFIGetSafsInfoCallBackRq _output = new TFIGetSafsInfoCallBackRq();
		CommonUserService cudi = new CommonUserServiceImpl();

		//mabdelrahman
				PreparedStatement _psr = _conn.prepareStatement(_sql_safe_info_res);

				_psr.setInt(1, _task_id);
		ResultSet _rsr = _psr.executeQuery();
		List<TSafInfo> _items = new ArrayList<TSafInfo>();
		while (_rsr.next()) {
			TSafInfo _item = new TSafInfo();
			_item.setSafNum(_rsr.getString("BOX_NO"));
			_item.setSafBrnch(_rsr.getString("SAFE_BRANCH"));
			if(_rsr.getTimestamp("BOX_OPEN_DATE")!=null) _item.setOpnDt(_sdf.format(_rsr.getTimestamp("BOX_OPEN_DATE")));
			_item.setJntAcc(_rsr.getString("IS_JOINT_SAFE"));

			int _resp_id = _rsr.getInt("ID");
			_item.setPrdUsrsList(cudi.selectUserCallBack(_conn, _resp_id));

			_items.add(_item);
		}
		TSafsList _safesList = new TSafsList();
		JAXBProtectedHandler.setSafInfo(_safesList,_items);
//		_safesList.safInfo = _items;
		_output.setSafsList(_safesList);
		//mabdelrahman
		if(_psr != null) _psr.close();				
		return _output;
	}

}
