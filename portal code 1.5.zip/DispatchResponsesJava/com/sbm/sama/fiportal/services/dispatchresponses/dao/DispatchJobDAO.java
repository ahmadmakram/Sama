package com.sbm.sama.fiportal.services.dispatchresponses.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.jaxb.common.TRqHdr;


public interface DispatchJobDAO {
	
	public List<DispatchJob> GetDispatchJobs(Connection _conn);
	public boolean UpdateDispatchJobs(List<DispatchJob> _jobs, Connection _conn) throws SQLException;
	public TRqHdr GetMessageHeader(DispatchJob _job, Connection _conn) throws SQLException;

}
