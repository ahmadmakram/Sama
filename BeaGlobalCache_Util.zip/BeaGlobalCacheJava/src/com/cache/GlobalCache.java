/**
 * 
 */
package com.cache;


import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbGlobalMap;

public class GlobalCache {

	static public Boolean insertCache(String cacheName, String key, String value) {
		try {
			MbGlobalMap map = MbGlobalMap.getGlobalMap(cacheName);
			String test = (String) map.get(key);
			if (test == null) {
				map.put(key, value);
			} else {
				map.update(key, value);
			}
		} catch (MbException e) {
			// TODO Auto-generated catch block
			System.err.println("error writing into cache");
			return false;
		}
		return true;
	}

	static public Boolean insertCache(String cacheName, String key, byte[] value) {
		try {
			MbGlobalMap map = MbGlobalMap.getGlobalMap(cacheName);
			byte[] test = (byte[]) map.get(key);
			if (test == null) {
				map.put(key, value);
			} else {
				map.update(key, value);
			}
		} catch (MbException e) {
			// TODO Auto-generated catch block
			System.err.println("error writing into cache");
			return false;
		}
		return true;
	}

	static public String readCache(String cacheName, String key) {
		try {
			MbGlobalMap map = MbGlobalMap.getGlobalMap(cacheName);
			return (String) map.get(key);
		} catch (MbException e) {
			// TODO Auto-generated catch block
			System.err.println("error reading  from  cache");
		}
		return null;
	}

	static public byte[] readCacheBLOB(String cacheName, String key) {
		try {
			MbGlobalMap map = MbGlobalMap.getGlobalMap(cacheName);
			return (byte[]) map.get(key);
		} catch (MbException e) {
			// TODO Auto-generated catch block
			System.err.println("error reading  from  cache");
		}
		return null;
	}

	static public Boolean deleteCache(String cacheName, String key) {
		try {
			MbGlobalMap map = MbGlobalMap.getGlobalMap(cacheName);
			String test = (String) map.get(key);
			if (test == null) {
				return false;
			} else {
				map.remove(key);
			}
		} catch (MbException e) {
			// TODO Auto-generated catch block
			System.err.println("error reading  from  cache");
			return false;
		}
		return true;
	}
}
