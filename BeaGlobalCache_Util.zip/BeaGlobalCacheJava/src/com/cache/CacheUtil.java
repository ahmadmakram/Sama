package com.cache;

import java.util.List;

import com.ibm.broker.plugin.*;

public class CacheUtil {

	public static String putInToCache (String cacheName,String key, String value) {
		try {
			boolean tmpValue = false; 
			MbGlobalMap globalMap = MbGlobalMap.getGlobalMap(cacheName,new MbGlobalMapSessionPolicy(40));
			tmpValue = globalMap.containsKey(key);
			if(tmpValue == false)
			{
				globalMap.put(key,value);
			}
			return "OK";
		} catch (MbException mbExp) {
			return "Exception in GCCacheUtil - putInToCache : "+mbExp.getMessage();
		} 
	}
	
	public static String getFromCache (String cacheName,String key) {
		String value=null;
		try {
			MbGlobalMap globalMap = MbGlobalMap.getGlobalMap(cacheName,new MbGlobalMapSessionPolicy(40));
			value = (String)globalMap.get(key);
			if (value == null) {
				value =  "NOT_AVAILABLE";
			}	
			return value;
		}catch (MbException mbExp) {
			return "Exception in GCCacheUtil - getFromCache : "+mbExp.getMessage();
		} 
	}
	
	public static String removeFromCache (String cacheName,String key) {
		try {
			MbGlobalMap globalMap = MbGlobalMap.getGlobalMap(cacheName,new MbGlobalMapSessionPolicy(40));
			if(globalMap.containsKey(key)){
				globalMap.remove(key); 
			}
			return "OK";
		} catch (MbException mbExp) {
			return "Exception in GCCacheUtil - removeFromCache : "+mbExp.getMessage();
		} 
	}
	
	public static Boolean isAvailableInCache (String cacheName,String key) {
		try {
			MbGlobalMap globalMap = MbGlobalMap.getGlobalMap(cacheName);
			return globalMap.containsKey(key);			
		} catch (MbException mbExp) {
			return false;
		} 
	}

	public static String addToCacheWithExpry (String cacheName,String key, String value,Long expiryTime) {
		try {
			boolean tmpValue = false; 
			MbGlobalMap globalMap = MbGlobalMap.getGlobalMap(cacheName,new MbGlobalMapSessionPolicy(expiryTime.intValue()));
			tmpValue = globalMap.containsKey(key);
			if(tmpValue == false)
			{
				globalMap.put(key,value);
			}
			return "OK";
		} catch (MbException mbExp) {
			return "Exception in GCCacheUtil - addInToCacheWithExpiry : "+mbExp.getMessage();
		} 
	}	
	
	//Load array list 
	public static String addDataHubDetailsToCacheWithExpry(String cacheName,String key,String value,Long expiryTime,MbElement[] envRef)
	{
		
		try{
			
			MbGlobalMap globalMap = MbGlobalMap.getGlobalMap(cacheName,new MbGlobalMapSessionPolicy(expiryTime.intValue()));
			
			for (MbElement item: (List<MbElement>)envRef[0].evaluateXPath("./Data"))
			{
				String strUserName = null;
				String strPWD 	   = null;
				String strURL      = null;
				String strKey      = null;
				String strValue    = null;
				MbElement cursor   = item.getFirstElementByPath("DB_ENV");
				strKey			   = cursor.getValue().toString();
				cursor   		   = item.getFirstElementByPath("USR_NM");
				strUserName		   = cursor.getValue().toString();
				cursor   		   = item.getFirstElementByPath("PASSWD");
				strPWD			   = cursor.getValue().toString();
				cursor   		   = item.getFirstElementByPath("URL");
				strURL			   = cursor.getValue().toString();
				strValue           = strUserName + "-" + strPWD + "||" + strURL;
				
				key = strKey;
				value = strValue;
				
				if (globalMap.containsKey(strKey))
				{
					globalMap.update(strKey,strValue);
				}
				else
				{
					globalMap.put(strKey,strValue);
				}	
			}
			if(globalMap.containsKey(key))
			{
				globalMap.update(key,value);
			}else
			{
				globalMap.put(key,value);
			}
			return "OK";
			} catch (MbException mbExp)
			{
				return "Exception in GCCacheUtil - addDatahubDetailsToCacheWithExpiry : "+mbExp.getMessage();
			}
		}
	}

