--------------------------------------------------------
--  DDL for Sequence PRD_SHRS_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PRD_SHRS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1  ;


--------------------------------------------------------
--  DDL for Table PRODUCT_SHARE
--------------------------------------------------------

  CREATE TABLE "FIPORTAL"."PRODUCT_SHARE" 
   (	"PRD_SHRS_ID" NUMBER DEFAULT "TANFEETH"."PRD_SHRS_SEQ"."NEXTVAL", 
	"TASK_ID" NUMBER, 
	"PRD_TYPE" VARCHAR2(20 CHAR), 
	"COMP_NAME" VARCHAR2(100 CHAR), 
	"SHRS_PRCNT" VARCHAR2(20 CHAR)
   )  ;
--------------------------------------------------------
--  DDL for Index PRD_SHRS_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FIPORTAL"."PRD_SHRS_PK" ON "FIPORTAL"."PRODUCT_SHARE" ("PRD_SHRS_ID")  ;
--------------------------------------------------------
--  Constraints for Table PRODUCT_SHARE
--------------------------------------------------------

  ALTER TABLE "FIPORTAL"."PRODUCT_SHARE" MODIFY ("TASK_ID" NOT NULL ENABLE);
  ALTER TABLE "FIPORTAL"."PRODUCT_SHARE" MODIFY ("PRD_TYPE" NOT NULL ENABLE);
  ALTER TABLE "FIPORTAL"."PRODUCT_SHARE" ADD CONSTRAINT "PRD_SHRS_PK" PRIMARY KEY ("PRD_SHRS_ID");
  
  
  
  
