//package com.sbm.sama.portal.tanfeeth.common.fieldsHandler;
//
//
//
//import java.util.List;
//
//import com.sbm.sama.portal.tanfeeth.jaxb.common.AccountInfoType;
//import com.sbm.sama.portal.tanfeeth.jaxb.common.BlockType;
//import com.sbm.sama.portal.tanfeeth.jaxb.common.DepositeInfoType;
//import com.sbm.sama.portal.tanfeeth.jaxb.common.DlngDcsnInfoType;
//import com.sbm.sama.portal.tanfeeth.jaxb.getAllTasks.GetAllTasksRsType;
//import com.sbm.sama.portal.tanfeeth.jaxb.common.GetBulkTasksOutputType;
//import com.sbm.sama.portal.tanfeeth.jaxb.common.GetBulkTasksRsType;
//import com.sbm.sama.portal.tanfeeth.jaxb.common.GetTaskInputType;
//import com.sbm.sama.portal.tanfeeth.jaxb.common.GetTaskOutputType;
//import com.sbm.sama.portal.tanfeeth.jaxb.common.GetTaskRqType;
//import com.sbm.sama.portal.tanfeeth.jaxb.common.GetTaskRsType;
//import com.sbm.sama.portal.tanfeeth.jaxb.common.InvolvedEntityType;
//import com.sbm.sama.portal.tanfeeth.jaxb.common.LiftRestrictionInfoType;
//import com.sbm.sama.portal.tanfeeth.jaxb.common.RequestMetadataType;
//import com.sbm.sama.portal.tanfeeth.jaxb.common.SafeInfoType;
//import com.sbm.sama.portal.tanfeeth.jaxb.updateTaskMultiStatus.UpdateTaskMultiStatusOutputType;
//import com.sbm.sama.portal.tanfeeth.jaxb.updateTaskMultiStatus.UpdateTaskMultiStatusRsType;
//
///**
// * 
// * @author Mahmoud Fahmy
// *
// */
//public class JAXBPublicHandler extends GetAllTasksRsType{
//	public static void setRMInvolvedEntityType(RequestMetadataType reqMetaData,
//			List<InvolvedEntityType> involvedEntityTypeList) {
//		reqMetaData.involvedEntityList = involvedEntityTypeList;
//	}
//	
//	public static void setRMAccountInfoRequestList(
//			RequestMetadataType reqMetaData,
//		AccountInfoType accountInfoRequestList) {
//		reqMetaData.accountInfoRequestList = accountInfoRequestList;
//	}
//
//	public static void setDepositeInfoTypeRequestList(
//			RequestMetadataType reqMetaData,
//			DepositeInfoType depositeInfoRequestList) {
//		reqMetaData.depositeInfoRequestList = depositeInfoRequestList;
//	}
//
//	public static void setSafeInfoTypeRequestList(
//			RequestMetadataType reqMetaData,
//			SafeInfoType safeInfoRequestList) {
//		reqMetaData.safeInfoRequestList = safeInfoRequestList;
//	}
//
//	public static void setTaskOutputType(GetTaskRsType response,
//			GetTaskOutputType output) {
//		response.getTaskOutput = output;
//	}
//
//	public static GetTaskInputType getTaskInputType(GetTaskRqType request) {
//		return request.getTaskInput;
//	}
//
//	public static void setDenyDlngDcsnInfoType(RequestMetadataType reqMetaData,
//			DlngDcsnInfoType denyInfoReq) {
//		reqMetaData.denyDealingRequest = denyInfoReq;
//	}
//
//	public static void setBanDlngDcsnInfoType(RequestMetadataType reqMetaData,
//			DlngDcsnInfoType denyInfoReq) {
//		reqMetaData.banDealingRequest = denyInfoReq;
//	}
//
//	public static void setLiftRestrictionInfoType(
//			RequestMetadataType reqMetaData,
//			LiftRestrictionInfoType liftRestrictionInfoType) {
//		reqMetaData.liftRestrictionRequest = liftRestrictionInfoType;
//	}
//	
//	public static void setBlockType(
//			RequestMetadataType reqMetaData,
//			BlockType blockType) {
//		reqMetaData.blockRequest = blockType;
//	}
//
//	public static void setBulkTasksOutput(GetBulkTasksRsType GetBulkTasksRs,
//			List<GetBulkTasksOutputType> getBulkTasksOutput) {
//		GetBulkTasksRs.getBulkTasksOutput = getBulkTasksOutput;
//	}
//
//	
//	public static void setUpdateTaskMultiStatusOutput(UpdateTaskMultiStatusRsType updateTaskMultiStatusRs,
//			UpdateTaskMultiStatusOutputType updateTaskMultiStatusOutput) {
//		updateTaskMultiStatusRs.setUpdateTaskMultiStatusOutput(updateTaskMultiStatusOutput);
//	}
//
//}
