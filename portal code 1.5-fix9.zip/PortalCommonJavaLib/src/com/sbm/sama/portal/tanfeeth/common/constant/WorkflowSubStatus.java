package com.sbm.sama.portal.tanfeeth.common.constant;

public class WorkflowSubStatus {

	public final static int CHECKED_OUT = 0;
	public final static int IN_QUEUE = 1;
	public final static int RETURNED_TO_QUEUE = 2;
	public final static int RETURNED_FROM_MANAGER = 3;

}
