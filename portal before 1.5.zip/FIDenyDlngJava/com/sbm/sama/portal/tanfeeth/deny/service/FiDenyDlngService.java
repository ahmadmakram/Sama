package com.sbm.sama.portal.tanfeeth.deny.service;

import java.sql.Connection;
import java.sql.SQLException;

import com.sbm.sama.portal.tanfeeth.jaxb.fiDenyDlng.TFIDenyDlngRq;

/**
 * 
 * @author Mahmoud Fahmi
 *
 */
public interface FiDenyDlngService {
	public Boolean addDenyDlngRequest(TFIDenyDlngRq denyDlngReq,
			Connection conn) throws SQLException;

}
