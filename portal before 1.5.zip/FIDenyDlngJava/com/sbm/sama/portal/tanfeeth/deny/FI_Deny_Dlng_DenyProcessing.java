package com.sbm.sama.portal.tanfeeth.deny;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;

import org.w3c.dom.Document;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import com.sbm.sama.portal.tanfeeth.deny.service.FiDenyDlngService;
import com.sbm.sama.portal.tanfeeth.jaxb.baseLib.TGovernment;
import com.sbm.sama.portal.tanfeeth.jaxb.baseLib.TIndividual;
import com.sbm.sama.portal.tanfeeth.jaxb.baseLib.TRqstr;
import com.sbm.sama.portal.tanfeeth.jaxb.baseLib.TThrdPrty;
import com.sbm.sama.portal.tanfeeth.jaxb.fiDenyDlng.ObjectFactory;
import com.sbm.sama.portal.tanfeeth.jaxb.fiDenyDlng.TFIDenyDlngRq;
import com.sbm.sama.portal.tanfeeth.jaxb.fiDenyDlng.TFIDenyDlngRs;
import com.sbm.sama.portal.tanfeeth.jaxb.header.TRqHdr;
import com.sbm.sama.portal.tanfeeth.service.InvolvedEntityService;
import com.sbm.sama.portal.tanfeeth.service.RequestMetaDataService;
import com.sbm.sama.portal.tanfeeth.service.WorkFlowTaskService;

/**
 * 
 * @author Mahmoud Fahmi
 * 
 */
public class FI_Deny_Dlng_DenyProcessing extends MbJavaComputeNode {

	private JAXBContext jaxbContextHeader = null;
	private JAXBContext jaxbContext = null;
	private JAXBContext jaxbContextBaseLib = null;
	private JAXBContext jaxbDenyDlngContext = null;

	private RequestMetaDataService requestMetaDataService;
	private InvolvedEntityService involvedEntityService;
	private WorkFlowTaskService workFlowTaskService;
	private FiDenyDlngService denyDlngService;

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

		// obtain the input message data
		MbMessage inMessage = inAssembly.getMessage();
		MbMessage inLocalEnvironment = inAssembly.getLocalEnvironment();

		// create a new empty output message
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly,
				outMessage);
		try {
			Connection connection = getJDBCType4Connection("XE",
					JDBC_TransactionType.MB_TRANSACTION_AUTO);

			jaxbDenyDlngContext = JAXBContext
					.newInstance("com.sbm.sama.portal.tanfeeth.jaxb.fiDenyDlng");

			jaxbContextHeader = JAXBContext
					.newInstance("com.sbm.sama.portal.tanfeeth.jaxb.header");

			jaxbContextBaseLib = JAXBContext
					.newInstance("com.sbm.sama.portal.tanfeeth.jaxb.baseLib");

			JAXBElement<TRqHdr> jaxRqHdr = jaxbContextHeader
					.createUnmarshaller()
					.unmarshal(
							inLocalEnvironment.getRootElement().getLastChild()
									.getLastChild().getFirstChild()
									.getLastChild().getLastChild().getDOMNode(),
							TRqHdr.class);

			JAXBElement<TRqstr> jaxRqStr = jaxbContextBaseLib
					.createUnmarshaller().unmarshal(
							inMessage.getRootElement().getLastChild()
									.getLastChild().getDOMNode(), TRqstr.class);

			JAXBElement<TThrdPrty> jaxThrdParty = jaxbContextBaseLib
					.createUnmarshaller().unmarshal(
							inMessage.getRootElement().getLastChild()
									.getLastChild().getDOMNode(),
							TThrdPrty.class);

			JAXBElement<TRqstr> jaxTRqstr = jaxbContextBaseLib
					.createUnmarshaller().unmarshal(
							inMessage.getRootElement().getLastChild()
									.getLastChild().getDOMNode(), TRqstr.class);

			JAXBElement<TGovernment> jaxTGovernment = jaxbContextBaseLib
					.createUnmarshaller().unmarshal(
							inMessage.getRootElement().getLastChild()
									.getLastChild().getDOMNode(),
							TGovernment.class);

			JAXBElement<TIndividual> jaxInvolvedEntity = jaxbContextBaseLib
					.createUnmarshaller().unmarshal(
							inMessage.getRootElement().getLastChild()
									.getLastChild().getDOMNode(),
							TIndividual.class);

			JAXBElement<TFIDenyDlngRq> jaxDenyDlng = jaxbDenyDlngContext
					.createUnmarshaller().unmarshal(
							inMessage.getRootElement().getLastChild()
									.getLastChild().getDOMNode(),
							TFIDenyDlngRq.class);

			Boolean isRMSuccess = requestMetaDataService.addRequestMetaData(
					jaxRqHdr.getValue(), jaxTGovernment.getValue(),
					jaxThrdParty.getValue(), jaxRqStr.getValue(),
					jaxTRqstr.getValue(), connection);

			Boolean isIESuccess = involvedEntityService.addInvolvedEntity(
					jaxInvolvedEntity.getValue(), connection);

			Boolean isWFSuccess = workFlowTaskService.addWorkFlowTask(
					jaxRqHdr.getValue(), connection);

			Boolean isDenyDlngReqSuccess = denyDlngService.addDenyDlngRequest(
					jaxDenyDlng.getValue(), connection);

			if (isRMSuccess || isIESuccess || isWFSuccess
					|| isDenyDlngReqSuccess) {
				ObjectFactory objFactory = new ObjectFactory();
				TFIDenyDlngRs value = new TFIDenyDlngRs();
				JAXBElement<TFIDenyDlngRs> _response = objFactory
						.createFIDenyDlngRs(value);
				Document outDocument = outMessage
						.createDOMDocument(MbXMLNSC.PARSER_NAME);
				jaxbContext.createMarshaller().marshal(_response, outDocument);
			} else {
				jaxRqHdr.getValue().setStatus("E0000000");
				jaxRqHdr.getValue().setNote("Failed");
			}

		} catch (JAXBException | SQLException | IOException | ParseException e) {
			// Example Exception handling
			throw new MbUserException(this, "evaluate()", "", "",
					e.getMessage(), null);
		}
	}
}
