package com.sbm.sama.portal.tanfeeth.deny.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.sbm.sama.portal.tanfeeth.jaxb.fiDenyDlng.TFIDenyDlngRq;

/**
 * 
 * @author Mahmoud Fahmi
 *
 */
public interface FiDenyDlngDao {
	public Boolean addDenyDlngRequest(TFIDenyDlngRq denyDlngReq,int taskId,Connection conn)throws SQLException;

}
