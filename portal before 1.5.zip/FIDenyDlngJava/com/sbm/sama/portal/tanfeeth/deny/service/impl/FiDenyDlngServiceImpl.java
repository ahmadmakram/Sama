package com.sbm.sama.portal.tanfeeth.deny.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.sbm.sama.portal.tanfeeth.deny.dao.FiDenyDlngDao;
import com.sbm.sama.portal.tanfeeth.deny.service.FiDenyDlngService;
import com.sbm.sama.portal.tanfeeth.jaxb.fiDenyDlng.TFIDenyDlngRq;

/**
 * 
 * @author Mahmoud Fahmi
 * 
 */
public class FiDenyDlngServiceImpl implements FiDenyDlngService {

	private FiDenyDlngDao fiDenyDlngDao;

	@Override
	public Boolean addDenyDlngRequest(TFIDenyDlngRq denyDlngReq,
			Connection conn) throws SQLException {
		int taskId = getTaskIdNEXTVAL(conn);
		return	fiDenyDlngDao.addDenyDlngRequest(denyDlngReq, taskId, conn);
		
	}

	private int getTaskIdNEXTVAL(Connection conn) throws SQLException {
		int id = 0;
		String sql = "SELECT FIPORTAL.WORKFLOW_TASK_ID.NEXTVAL FROM DUAL";
		PreparedStatement preparedStmt = conn.prepareStatement(sql);
		ResultSet rs = preparedStmt.executeQuery();
		if (rs.next())
			id = rs.getInt(1);
		if (preparedStmt != null)
			preparedStmt.close();
		return id;
	}
}
