package com.sbm.sama.portal.tanfeeth.deny.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.sbm.sama.portal.tanfeeth.deny.dao.FiDenyDlngDao;
import com.sbm.sama.portal.tanfeeth.jaxb.fiDenyDlng.TFIDenyDlngRq;
import com.sbm.sama.portal.tanfeeth.util.DatabaseUtility;

public class FiDenyDlngDaoImpl implements FiDenyDlngDao {

	@Override
	public Boolean addDenyDlngRequest(TFIDenyDlngRq denyDlngReq, int taskId,
			Connection conn) throws SQLException {
		Boolean isDenyDlngReqInserted = false;
		String denyDlngReqStmt = "INSERT INTO FIPORTAL.DENY_DEALING_REQUEST (ID, DCSN_NO, DCSN_DT, DUE_DATE_TIME, TASK_ID) VALUES (FIPORTAL.DENY_REQ_ID.NEXTVAL,?,?,?,?)";
		PreparedStatement denyDlngReqPreparedStmt = conn
				.prepareStatement(denyDlngReqStmt);

		denyDlngReqPreparedStmt.setString(1, denyDlngReq.getDcsnInfo().getNum());
		denyDlngReqPreparedStmt.setString(2, denyDlngReq.getDcsnInfo().getDt());
		denyDlngReqPreparedStmt.setTimestamp(3,
				DatabaseUtility.getTaskDueDateTime());
		denyDlngReqPreparedStmt.setInt(4, taskId);
		denyDlngReqPreparedStmt.executeUpdate();

		isDenyDlngReqInserted = true;

		if (denyDlngReqPreparedStmt != null) {
			denyDlngReqPreparedStmt.close();
		}

		return isDenyDlngReqInserted;
	}

}
