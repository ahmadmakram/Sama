package sa.gov.sama.be.fiportal.services.getaccountinforesponse.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.tanfeeth.jaxb.common.GetAccountInfoResponseInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetAccountInfoResponseOutputType;

public interface GetAccountInfoResponseDAO {
	public GetAccountInfoResponseOutputType GetAccountInfoResponse(GetAccountInfoResponseInputType _input, Connection _conn) throws SQLException, DatatypeConfigurationException; 

}
