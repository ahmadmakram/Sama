package sa.gov.sama.be.fiportal.services.getaccountinforesponse.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.tanfeeth.common.service.CommonShareService;
import com.sbm.sama.portal.tanfeeth.common.service.CommonTaskService;
import com.sbm.sama.portal.tanfeeth.common.service.CommonUserService;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonShareServiceImpl;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonTaskServiceImpl;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonUserServiceImpl;
import com.sbm.sama.portal.tanfeeth.common.util.FieldsProcessing;
import com.sbm.sama.portal.tanfeeth.common.util.MessageProcessor;
import com.sbm.sama.portal.tanfeeth.common.util.WorkflowTaskBean;
import com.sbm.sama.portal.tanfeeth.jaxb.common.AccountInfoResponseType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetAccountInfoResponseInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetAccountInfoResponseOutputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.ReservationInfoResponseType;

public class GetAccountInfoResponseDAOImpl implements GetAccountInfoResponseDAO {

	@Override
	public GetAccountInfoResponseOutputType GetAccountInfoResponse(
			GetAccountInfoResponseInputType _input, Connection _conn)
			throws SQLException, DatatypeConfigurationException {
		String _sql_acct_info_res = "SELECT * FROM FIPORTAL.ACCOUNT_INFO_RESPONSE WHERE TASK_ID =?";
		String _sql_reserve_info = "SELECT * FROM FIPORTAL.ACCOUNT_INFO_RESERVE WHERE RESPONSE_ID=?";
		int responseID=0;

		GetAccountInfoResponseOutputType _output = null;
		CommonUserService cudi = new CommonUserServiceImpl();
		CommonShareService csidi = new CommonShareServiceImpl();
		CommonTaskService ctdi= new CommonTaskServiceImpl();
		
		WorkflowTaskBean workflowTaskBean =ctdi.selectTaskService(_conn,  _input.getTaskId());
		if (workflowTaskBean!=null) {
			_output = new GetAccountInfoResponseOutputType();
			
			_output.setWorkflowTaskInfo(MessageProcessor.mapWorkflowTaskInfo(workflowTaskBean));

			PreparedStatement _psr = _conn.prepareStatement(_sql_acct_info_res);
			_psr.setInt(1, _input.getTaskId());
			ResultSet _rsr = _psr.executeQuery();
			List<AccountInfoResponseType> _items = new ArrayList<AccountInfoResponseType>();
			while (_rsr.next()) {
				AccountInfoResponseType _item = new AccountInfoResponseType();
				 responseID=_rsr.getInt("ID");

				_item.setAccountNo(_rsr.getString("ACCOUNT_NO"));
				_item.setIban(_rsr.getString("IBAN"));
				_item.setAccountType(_rsr.getString("ACCOUNT_TYPE"));
				_item.setCurrency(_rsr.getString("CURRENCY"));
				_item.setAccountStatus(_rsr.getString("ACCOUNT_STATUS"));
				_item.setInstitution(_rsr.getString("INSTITUTION"));
				_item.setAccountOpeningDate(FieldsProcessing.getXMLGregCal(_rsr.getTimestamp("ACCOUNT_OPENING_DATE")));
				_item.setAccountClosingDate(FieldsProcessing.getXMLGregCal(_rsr.getTimestamp("ACCOUNT_CLOSING_DATE")));
				_item.setAvailableBalance(_rsr.getBigDecimal("AVAILABLE_BALANCE"));
				_item.setTotalBalance(_rsr.getBigDecimal("TOTAL_BALANCE"));
				_item.setBalanceDate(FieldsProcessing.getXMLGregCal(_rsr.getTimestamp("BALANCE_DATE")));
				_item.setIsJointAccount(_rsr.getString("IS_JOINT_ACCOUNT"));

				_item.userInfoResponse = cudi.selectUserService(_conn,responseID);

				PreparedStatement _psrs = _conn
						.prepareStatement(_sql_reserve_info);
				_psrs.setInt(1, Integer.valueOf(_input.getTaskId()));
				ResultSet _rsrs = _psrs.executeQuery();
				List<ReservationInfoResponseType> _ritems = new ArrayList<ReservationInfoResponseType>();
				while (_rsrs.next()) {
					ReservationInfoResponseType _ritem = new ReservationInfoResponseType();
					_ritem.setReservedAmount(_rsrs.getBigDecimal("RESERVED_AMOUNT"));
					_ritem.setReservedBy(_rsrs.getString("RESERVED_BY"));
					_ritem.setRRN(_rsrs.getString("RRN"));
					_ritem.setCurrency(_rsrs.getString("CURR_CODE"));
					_ritems.add(_ritem);
				}
				_item.reservationInfoResponse = _ritems;
				_items.add(_item);
				_rsrs.close();
				_psrs.close();
			}
			_rsr.close();
			_psr.close();

			_output.accountInfoResponse = _items;

			_output.shareInfoResponse = csidi.selectShareService(_input.getTaskId(),_conn);
		}

		return _output;
	}
}
