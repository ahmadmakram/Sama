package com.sbm.sama.portal.tanfeeth.getdenydealingtask.dao;


import java.sql.Connection;

import com.sbm.sama.portal.tanfeeth.jaxb.getdenydealing.GetDenyDealingTaskInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.getdenydealing.GetDenyDealingTaskOutputType;


public interface GetDenyDealingTaskDAO {

	public GetDenyDealingTaskOutputType GetDenyDealingTask(
			GetDenyDealingTaskInputType _input, Connection _conn) ;

}
