package com.sbm.sama.portal.tanfeeth.getdenydealingtask.dao.impl;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.sbm.sama.portal.tanfeeth.jaxb.getdenydealing.DenyDealTaskType;
import com.sbm.sama.portal.tanfeeth.jaxb.getdenydealing.GetDenyDealingTaskInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.getdenydealing.GetDenyDealingTaskOutputType;
import com.sbm.sama.portal.tanfeeth.jaxb.getdenydealing.TCustInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.getdenydealing.TFIRsTaskExecution;
import com.sbm.sama.portal.tanfeeth.common.dao.impl.CommonTaskDaoImpl;
import com.sbm.sama.portal.tanfeeth.getdenydealingtask.dao.GetDenyDealingTaskDAO;


public class GetDenyDealingTaskDAOImpl implements GetDenyDealingTaskDAO{
	private CommonTaskDaoImpl cdi ;

	public GetDenyDealingTaskOutputType GetDenyDealingTask(
			GetDenyDealingTaskInputType _input, Connection _conn) {
		String _sql_task_status = "SELECT  STATUS_ID   , ASSIGNED_BY , ASSIGNED_BY_ROLE,NOTES FROM  FIPORTAL.WORKFLOW_TASK WHERE ID=?";
		String _sql_deny_info_res = "SELECT  id,cust_name,cust_id,cust_idtype,CUST_NTNLTY,exe_dttm,is_deleted frOM deny_dealing_response where TASK_ID = ? AND TRIM(IS_DELETED)='NO'";

		GetDenyDealingTaskOutputType _output = new GetDenyDealingTaskOutputType();
		cdi = new CommonTaskDaoImpl();
		PreparedStatement _ps;
		try {
			_ps = _conn.prepareStatement(_sql_task_status);
			_ps.setInt(1, _input.getTaskId());
			ResultSet _rs = _ps.executeQuery();
			if (_rs.next()) {
				_output.setTaskId(_input.getTaskId());
				_output.setStatusId(_rs.getInt("STATUS_ID"));
				_output.setExecutedByUserId(_rs.getString("ASSIGNED_BY"));
				_output.setExecutedByRoleId(_rs.getString("ASSIGNED_BY_ROLE"));
				_output.setNotes(_rs.getString("NOTES"));
				

				PreparedStatement _psr = _conn.prepareStatement(_sql_deny_info_res);
				_psr.setInt(1, _output.getTaskId());
				ResultSet _rsr = _psr.executeQuery();
				
				DenyDealTaskType _item = new DenyDealTaskType();
				TFIRsTaskExecution fiRsDenyDlng = new TFIRsTaskExecution();
				if (_rsr.next()) {
				
				TCustInfo _custInfo = new TCustInfo();
				_custInfo.setCustName(_rsr.getString("CUST_NAME"));
				_custInfo.setId(_rsr.getString("CUST_ID"));
				_custInfo.setIdType(_rsr.getString("CUST_IDTYPE"));
				_custInfo.setNtnlty(_rsr.getString("CUST_NTNLTY"));
				
				fiRsDenyDlng.setCustInfo(_custInfo);
				fiRsDenyDlng.setExeDtTm((_rsr.getString("exe_dttm")));
				
				fiRsDenyDlng.setStatusCode(cdi.GetTaskCallBackStatus(_conn,  _input.getTaskId()));

				_item.setFIRsDenyDlng(fiRsDenyDlng);
				
				_output.setDenyDealingTask(_item);
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		
		
		
		return _output;
	}
	


}
