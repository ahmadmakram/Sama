package com.sbm.sama.fiportal.services.assigntask.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.common.dao.impl.CommonTaskDaoImpl;
import com.sbm.sama.portal.tanfeeth.common.util.StatusCode;
import com.sbm.sama.portal.tanfeeth.common.util.WorkflowTaskBean;
import com.sbm.sama.portal.tanfeeth.jaxb.assignTask.AssignTaskInputType;

public class AssignTaskDAOImpl implements AssignTaskDAO {

	@Override
	public String assignTask(AssignTaskInputType _input, Connection _conn) throws SQLException {
		String _output = StatusCode.FATAL_ERROR.getCode();

		List<Integer> _task_id_list = _input.getTaskId();
		boolean _isAssign = _input.isIsAssignAction();
		for (int i = 0; i < _task_id_list.size(); i++) {
			CommonTaskDaoImpl ctdi = new CommonTaskDaoImpl();

			WorkflowTaskBean wfti = ctdi.selectTask(_conn, _input.getTaskId().get(i));

			if (_input.isIsAssignAction()) {
				String _old_assigned_to_db = wfti.getAssignedTo();

				if (_old_assigned_to_db == null) {
					if (_input.getOldAssignedToUserId() != null) {
						if (_input.getOldAssignedToUserId().trim().length() != 0) {
							_output = StatusCode.UNABLE_TO_ASSIGN.getCode();
							return _output;
						}
					}
				} else if (!_old_assigned_to_db.equalsIgnoreCase(_input.getOldAssignedToUserId())) {
					_output = StatusCode.UNABLE_TO_ASSIGN.getCode();
					return _output;
				}

			}
			wfti.setLastAssignedTo(wfti.getAssignedTo());
			wfti.setAssignedTo((_isAssign ? _input.getAssignedToUserId() : ""));
			wfti.setAssignedBy((_isAssign ? _input.getAssignedByUserId() : ""));
			wfti.setAssignedByRole((_isAssign ? _input.getAssignedByRoleId() : ""));

			wfti.setStatusId(_input.getStatusId());
			wfti.setNotes(null);

			Timestamp currentTime = new Timestamp(System.currentTimeMillis());
			wfti.setAssignedDateTime((_isAssign ? currentTime : null));

			ctdi.updateTask(_conn, wfti);
			_output = StatusCode.SUCCESS.getCode();
		}

		return _output;
	}
}
