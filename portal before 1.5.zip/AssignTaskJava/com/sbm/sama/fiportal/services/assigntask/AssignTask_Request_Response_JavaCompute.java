package com.sbm.sama.fiportal.services.assigntask;

import java.sql.Connection;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;

import org.w3c.dom.Document;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import com.sbm.sama.fiportal.services.assigntask.dao.AssignTaskDAOImpl;
import com.sbm.sama.portal.tanfeeth.common.util.StatusCode;
import com.sbm.sama.portal.tanfeeth.jaxb.assignTask.AssignTaskInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.assignTask.AssignTaskOutputType;
import com.sbm.sama.portal.tanfeeth.jaxb.assignTask.AssignTaskRqType;
import com.sbm.sama.portal.tanfeeth.jaxb.assignTask.AssignTaskRsType;
import com.sbm.sama.portal.tanfeeth.jaxb.assignTask.ObjectFactory;

;

public class AssignTask_Request_Response_JavaCompute extends MbJavaComputeNode {

	protected static JAXBContext jaxbContext = null;

	public void onInitialize() throws MbException {
		try {
			jaxbContext = JAXBContext
					.newInstance(com.sbm.sama.portal.tanfeeth.jaxb.assignTask.ObjectFactory.class);
		} catch (JAXBException e) {
			throw new MbUserException(this, "onInitialize()", "", "", e.getMessage(), null);
		}
	}

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		// obtain the input message data
		MbMessage inMessage = inAssembly.getMessage();
		MbOutputTerminal out = getOutputTerminal("out");
		// create a new empty output message
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);

		// optionally copy input message headers to the new output
		copyMessageHeaders(inMessage, outMessage);

		try {
			Connection _conn = getJDBCType4Connection("XE", JDBC_TransactionType.MB_TRANSACTION_AUTO);

			JAXBElement<AssignTaskRqType> JAXAssignTaskRq = jaxbContext.createUnmarshaller().unmarshal(
					inMessage.getRootElement().getLastChild().getLastChild().getDOMNode(),
					AssignTaskRqType.class);
			AssignTaskRqType _request = JAXAssignTaskRq.getValue();

			AssignTaskDAOImpl _dao = new AssignTaskDAOImpl();
			AssignTaskInputType _input = _request.getAssignTaskInput();

			AssignTaskOutputType _output = new AssignTaskOutputType();
			String _result = _dao.assignTask(_input, _conn);

			StatusCode status= StatusCode.findByCode(_result);
			_output.setStatusCode(status.getCode());
			_output.setStatusMessage(status.getDesc());

			ObjectFactory _objFac = new ObjectFactory();
			AssignTaskRsType AssignTaskRs = _objFac.createAssignTaskRsType();
			AssignTaskRs.setAssignTaskOutput(_output);

			JAXBElement<AssignTaskRsType> _response = _objFac.createAssignTaskRs(AssignTaskRs);

			Document outDocument = outMessage.createDOMDocument(MbXMLNSC.PARSER_NAME);
			jaxbContext.createMarshaller().marshal(_response, outDocument);
			out.propagate(outAssembly);
		} catch (Exception e) {
			// Example Exception handling
			throw new MbUserException(this, "evaluate()", "", "", e.getMessage(), null);
		}
	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage) throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element and stopping before the last child (message body)
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) {
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}

}
