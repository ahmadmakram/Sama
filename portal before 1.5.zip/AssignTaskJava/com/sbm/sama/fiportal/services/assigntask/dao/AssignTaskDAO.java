package com.sbm.sama.fiportal.services.assigntask.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.sbm.sama.portal.tanfeeth.jaxb.assignTask.AssignTaskInputType;



public interface AssignTaskDAO {

	public String assignTask(AssignTaskInputType _input, Connection _conn) throws SQLException;

}
