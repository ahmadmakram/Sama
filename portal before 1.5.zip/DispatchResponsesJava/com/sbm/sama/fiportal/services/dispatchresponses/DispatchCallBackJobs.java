package com.sbm.sama.fiportal.services.dispatchresponses;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.namespace.QName;


import com.sbm.sama.fiportal.services.dispatchresponses.dao.AccountInfoResponsesDAO;
import com.sbm.sama.fiportal.services.dispatchresponses.dao.BalanceInfoResponsesDAO;
import com.sbm.sama.fiportal.services.dispatchresponses.dao.DepositInfoResponsesDAO;
import com.sbm.sama.fiportal.services.dispatchresponses.dao.DispatchJob;
import com.sbm.sama.fiportal.services.dispatchresponses.dao.DispatchJobDAOImpl;
import com.sbm.sama.fiportal.services.dispatchresponses.dao.LiabilityInfoResponsesDAO;
import com.sbm.sama.fiportal.services.dispatchresponses.dao.SafeInfoResponsesDAO;
import com.sbm.sama.fiportal.services.util.ConfigurationHelper;
import com.sbm.sama.fiportal.services.util.LoggingHelper;
import com.sbm.sama.portal.tanfeeth.common.util.MainLogger;
import com.sbm.sama.portal.tanfeeth.common.util.ServiceCode;
import com.sbm.sama.portal.tanfeeth.common.util.StatusCode;
import com.sbm.sama.portal.tanfeeth.jaxb.common.Body;
import com.sbm.sama.portal.tanfeeth.jaxb.common.Envelope;
import com.sbm.sama.portal.tanfeeth.jaxb.common.Header;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFIGetAcctsInfoCallBackRq;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFIGetBalsInfoCallBackRq;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFIGetDepotsInfoCallBackRq;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFIGetLiabsInfoCallBackRq;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFIGetSafsInfoCallBackRq;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TRqHdr;

public class DispatchCallBackJobs {

	private static Logger logger = LoggingHelper.getLogger();
	private static ConfigurationHelper _config_helper = new ConfigurationHelper();
	
	// String wsURL1 = "http://192.168.100.6:7800/services/inquiry/fi-services/accounts-info-callback";


	public boolean runQueuedCallbackJobs(Connection _conn , String httpInd,String URLPrefix) throws JAXBException, IOException, DatatypeConfigurationException {
		boolean _bSuccess = false;

		String _xml_request_message = "";
		String _xml_reply_message = "";

		DispatchJobDAOImpl _dao = new DispatchJobDAOImpl();
		try {
			logger.log(Level.INFO, "runQueuedCallbackJobs Start ====");
			List<DispatchJob> _jobs = _dao.GetDispatchJobs(_conn);
			MainLogger.logData("DispatchCallBackJobs", "find "+ _jobs.size() +" to be sent");
			List<DispatchJob> _updatedjobs = new ArrayList<DispatchJob>();
			logger.log(Level.INFO,"Number of Job to be executed is ==>> " + _jobs.size());
			for (int i = 0; i < _jobs.size(); i++) {
				DispatchJob _job = _jobs.get(i);
				try {
								
				Envelope _envelope = new Envelope();
				Header _header = new Header();
				Body _body = new Body();
				JAXBElement<TRqHdr> _JAXBHeader = getXMLMessageHeader(_job, _conn);
				_header.getAny().add(_JAXBHeader);
				_envelope.setHeader(_header);

				int _retry_counter = 1 + _job.get_retry_count();
				_job.set_retry_count(_retry_counter);

				logger.log(Level.INFO, " JOB START ==>>\n");

				if (_job.get_sub_service_code().equalsIgnoreCase(ServiceCode.ACC)) { //ServiceCode.ACC
					JAXBElement<TFIGetAcctsInfoCallBackRq> _JAXBBody = new JAXBElement<TFIGetAcctsInfoCallBackRq>(new QName("http://www.sama.bea.sa/inquiry/FIGetAcctsInfo", "FIGetAcctsInfoCallBackRq"), TFIGetAcctsInfoCallBackRq.class, new TFIGetAcctsInfoCallBackRq());
					if(!_job.is_bulk_processed()) {
						_JAXBBody = getAccountInfoXMLMessageBody(_job.get_task_id(), _conn);
					}
					_body.getAny().add(_JAXBBody);
					_envelope.setBody(_body);
					_xml_request_message = BuildSOAPEnvelope(_envelope);
					_xml_reply_message = invokeCallBackWS(_xml_request_message, URLPrefix+getValue("wsURL1"), getValue("SOAPAction1"),httpInd);
				} else if (_job.get_sub_service_code().equalsIgnoreCase(ServiceCode.BAL)) {
					JAXBElement<TFIGetBalsInfoCallBackRq> _JAXBBody = new JAXBElement<TFIGetBalsInfoCallBackRq>(new QName("http://www.sama.bea.sa/inquiry/FIGetBalsInfo", "FIGetBalsInfoCallBackRq"), TFIGetBalsInfoCallBackRq.class, new TFIGetBalsInfoCallBackRq());
					if(!_job.is_bulk_processed()) {
						_JAXBBody = getBalanceInfoXMLMessageBody(_job.get_task_id(), _conn);
					}
					_body.getAny().add(_JAXBBody);
					_envelope.setBody(_body);
					_xml_request_message = BuildSOAPEnvelope(_envelope);
					_xml_reply_message = invokeCallBackWS(_xml_request_message, URLPrefix+getValue("wsURL2"), getValue("SOAPAction2"),httpInd);
				} else if (_job.get_sub_service_code().equalsIgnoreCase(ServiceCode.DEP)) {
					JAXBElement<TFIGetDepotsInfoCallBackRq> _JAXBBody = new JAXBElement<TFIGetDepotsInfoCallBackRq>(new QName("http://www.sama.bea.sa/inquiry/FIGetDepotsInfo", "FIGetDepotsInfoCallBackRq"), TFIGetDepotsInfoCallBackRq.class, new TFIGetDepotsInfoCallBackRq());
					if(!_job.is_bulk_processed()) {
						_JAXBBody = getDepositInfoXMLMessageBody(_job.get_task_id(), _conn);
					}
					_body.getAny().add(_JAXBBody);
					_envelope.setBody(_body);
					_xml_request_message = BuildSOAPEnvelope(_envelope);
					_xml_reply_message = invokeCallBackWS(_xml_request_message, URLPrefix+getValue("wsURL3"), getValue("SOAPAction3"),httpInd);
				} else if (_job.get_sub_service_code().equalsIgnoreCase(ServiceCode.LIAB)) {
					JAXBElement<TFIGetLiabsInfoCallBackRq> _JAXBBody = new JAXBElement<TFIGetLiabsInfoCallBackRq>(new QName("http://www.sama.bea.sa/inquiry/FIGetLiabsInfo", "FIGetLiabsInfoCallBackRq"), TFIGetLiabsInfoCallBackRq.class, new TFIGetLiabsInfoCallBackRq());
					if(!_job.is_bulk_processed()) {
						_JAXBBody = getLiabilityInfoXMLMessageBody(_job.get_task_id(), _conn);
					}
					_body.getAny().add(_JAXBBody);
					_envelope.setBody(_body);
					_xml_request_message = BuildSOAPEnvelope(_envelope);
					_xml_reply_message = invokeCallBackWS(_xml_request_message, URLPrefix+getValue("wsURL4"), getValue("SOAPAction4"),httpInd);
				} else if (_job.get_sub_service_code().equalsIgnoreCase(ServiceCode.SAF)) {
					JAXBElement<TFIGetSafsInfoCallBackRq> _JAXBBody = new JAXBElement<TFIGetSafsInfoCallBackRq>(new QName("http://www.sama.bea.sa/inquiry/FIGetSafsInfo", "FIGetSafsInfoCallBackRq"), TFIGetSafsInfoCallBackRq.class, new TFIGetSafsInfoCallBackRq());
					if(!_job.is_bulk_processed()) {
						_JAXBBody = getSafeInfoXMLMessageBody(_job.get_task_id(), _conn);
					}
					_body.getAny().add(_JAXBBody);
					_envelope.setBody(_body);
					_xml_request_message = BuildSOAPEnvelope(_envelope);
					_xml_reply_message = invokeCallBackWS(_xml_request_message, URLPrefix+getValue("wsURL5"), getValue("SOAPAction5"),httpInd);
				}

//				else if (_job.get_sub_service_code().equalsIgnoreCase("BanDealing")) {
//					JAXBElement<TFIBanDlngCallBackRq> _JAXBBody = new JAXBElement<TFIBanDlngCallBackRq>(new QName("http://www.sama.bea.sa/execution/FIBanDlng", "TFIBanDlngCallBackRq"), TFIBanDlngCallBackRq.class, new TFIBanDlngCallBackRq());
//					if(!_job.is_bulk_processed()) {
//						_JAXBBody = getBanDlngXMLMessageBody(_job.get_task_id(), _conn);
//								
//				}
//					_body.getAny().add(_JAXBBody);
//					_envelope.setBody(_body);
//					_xml_request_message = BuildSOAPEnvelope(_envelope);
//					_xml_reply_message = invokeCallBackWS(_xml_request_message, URLPrefix+getValue("wsURL5"), getValue("SOAPAction5"),httpInd);
//				}
				
//				else if (_job.get_sub_service_code().equalsIgnoreCase("DenyDealing")) {
//					JAXBElement<TFIDenyDlngCallBackRq> _JAXBBody = new JAXBElement<TFIDenyDlngCallBackRq>(new QName("http://www.sama.bea.sa/execution/FIDenyDlng", "TFIDenyDlngCallBackRq"), TFIDenyDlngCallBackRq.class, new TFIDenyDlngCallBackRq());
//					if(!_job.is_bulk_processed()) {
//						_JAXBBody = getDenyDlngXMLMessageBody(_job.get_task_id(), _conn);
//								
//					}
//					_body.getAny().add(_JAXBBody);
//					_envelope.setBody(_body);
//					_xml_request_message = BuildSOAPEnvelope(_envelope);
//					_xml_reply_message = invokeCallBackWS(_xml_request_message, URLPrefix+getValue("wsURL5"), getValue("SOAPAction5"),httpInd);
//				}
				logger.log(Level.INFO,"===");
				logger.log(Level.INFO," _xml_request_message ==>> \n " + _xml_request_message + "Job ID ==>> " + _job.get_id());
				logger.log(Level.INFO,"===");
				
				_job.set_response_message(_xml_reply_message);
				_job.set_request_message(_xml_request_message);
				if (_xml_reply_message.indexOf(StatusCode.SUCCESS.getCode()) > 0 || _xml_reply_message.indexOf(StatusCode.ACK.getCode()) > 0) {
					_job.set_is_job_executed(true);
					logger.log(Level.INFO, "Web Service Reply is OK !!!!!!!!!!! ...");
				} else {
					_job.set_is_job_executed(false);
					logger.log(Level.INFO, "Web Service Reply with ERROR ...");
				}
				_updatedjobs.add(_job);
				logger.log(Level.INFO,"===");
				logger.log(Level.INFO, " _xml_reply_message ==>> \n " + _xml_reply_message);
				logger.log(Level.INFO,"===");
				} catch (Exception se) {
					StringWriter sw = new StringWriter();
					PrintWriter pw = new PrintWriter(sw);
					se.printStackTrace(pw);
					_job.set_response_message("******************* INNER CATCH *************************\n"+sw.toString());
					_job.set_is_job_executed(false);
					_updatedjobs.add(_job);
					logger.log(Level.INFO,"******************* INNER CATCH *************************\n"+sw.toString());
					sw.close();
					pw.close();
				}
			}

			_bSuccess = _dao.UpdateDispatchJobs(_updatedjobs, _conn);
		} catch (Exception se) {
			logger.log(Level.SEVERE, "SQLException ====> ");
			logger.log(Level.SEVERE, se.getMessage(), se);
		}

		logger.log(Level.INFO, "runQueuedCallbackJobs End ====");
		return _bSuccess;
	}

	private String BuildSOAPEnvelope(Envelope _envelope) throws JAXBException {
		StringWriter sw = new StringWriter();
		JAXBContext jaxbContext = JAXBContext.newInstance(com.sbm.sama.portal.tanfeeth.jaxb.common.ObjectFactory.class);
		JAXBElement<Envelope> _soap_env = new JAXBElement<Envelope>(new QName("http://schemas.xmlsoap.org/soap/envelope/", "Envelope"), Envelope.class, _envelope);
		Marshaller _mar = jaxbContext.createMarshaller();
		_mar.marshal(_soap_env, sw);
		String _out = sw.toString();
		_out = _out.substring(_out.indexOf("?>")+2);
		return _out;
	}

	private JAXBElement<TFIGetAcctsInfoCallBackRq> getAccountInfoXMLMessageBody(int _task_id, Connection _conn) throws JAXBException, SQLException, DatatypeConfigurationException, IOException {
		AccountInfoResponsesDAO _dao = new AccountInfoResponsesDAO();
		TFIGetAcctsInfoCallBackRq _requset = _dao.GetAccoutInfoMessageBody(_task_id, _conn);
		JAXBElement<TFIGetAcctsInfoCallBackRq> _out = new JAXBElement<TFIGetAcctsInfoCallBackRq>(new QName("http://www.sama.bea.sa/inquiry/FIGetAcctsInfo", "FIGetAcctsInfoCallBackRq"), TFIGetAcctsInfoCallBackRq.class, _requset);

		return _out;
	}

	private JAXBElement<TFIGetBalsInfoCallBackRq> getBalanceInfoXMLMessageBody(int _task_id, Connection _conn) throws JAXBException, SQLException, DatatypeConfigurationException, IOException {
		BalanceInfoResponsesDAO _dao = new BalanceInfoResponsesDAO();
		TFIGetBalsInfoCallBackRq _requset = _dao.GetBalanceInfoMessageBody(_task_id, _conn);
		JAXBElement<TFIGetBalsInfoCallBackRq> _out = new JAXBElement<TFIGetBalsInfoCallBackRq>(new QName("http://www.sama.bea.sa/inquiry/FIGetBalsInfo", "FIGetBalsInfoCallBackRq"), TFIGetBalsInfoCallBackRq.class, _requset);

		return _out;
	}

	private JAXBElement<TFIGetDepotsInfoCallBackRq> getDepositInfoXMLMessageBody(int _task_id, Connection _conn) throws JAXBException, SQLException, DatatypeConfigurationException, IOException {
		DepositInfoResponsesDAO _dao = new DepositInfoResponsesDAO();
		TFIGetDepotsInfoCallBackRq _requset = _dao.GetDepositsInfoMessageBody(_task_id, _conn);
		JAXBElement<TFIGetDepotsInfoCallBackRq> _out = new JAXBElement<TFIGetDepotsInfoCallBackRq>(new QName("http://www.sama.bea.sa/inquiry/FIGetDepotsInfo", "FIGetDepotsInfoCallBackRq"), TFIGetDepotsInfoCallBackRq.class, _requset);

		return _out;
	}

	private JAXBElement<TFIGetLiabsInfoCallBackRq> getLiabilityInfoXMLMessageBody(int _task_id, Connection _conn) throws JAXBException, SQLException, DatatypeConfigurationException, IOException {
		LiabilityInfoResponsesDAO _dao = new LiabilityInfoResponsesDAO();
		TFIGetLiabsInfoCallBackRq _requset = _dao.GetLiabilitiesInfoMessageBody(_task_id, _conn);
		JAXBElement<TFIGetLiabsInfoCallBackRq> _out = new JAXBElement<TFIGetLiabsInfoCallBackRq>(new QName("http://www.sama.bea.sa/inquiry/FIGetLiabsInfo", "FIGetLiabsInfoCallBackRq"), TFIGetLiabsInfoCallBackRq.class, _requset);

		return _out;
	}

	private JAXBElement<TFIGetSafsInfoCallBackRq> getSafeInfoXMLMessageBody(int _task_id, Connection _conn) throws JAXBException, SQLException, DatatypeConfigurationException, IOException {
		SafeInfoResponsesDAO _dao = new SafeInfoResponsesDAO();
		TFIGetSafsInfoCallBackRq _requset = _dao.GetSafesInfoMessageBody(_task_id, _conn);
		JAXBElement<TFIGetSafsInfoCallBackRq> _out = new JAXBElement<TFIGetSafsInfoCallBackRq>(new QName("http://www.sama.bea.sa/inquiry/FIGetSafsInfo", "FIGetSafsInfoCallBackRq"), TFIGetSafsInfoCallBackRq.class, _requset);

		return _out;
	}
	
//	private JAXBElement<TFIBanDlngCallBackRq> getBanDlngXMLMessageBody(int _task_id, Connection _conn) throws JAXBException, SQLException, DatatypeConfigurationException, IOException {
//		BanDlngDAO _dao = new BanDlngDAO();
//		TFIBanDlngCallBackRq _requset = _dao.GetBanTaskMessageBody(_task_id, _conn);
//		JAXBElement<TFIBanDlngCallBackRq> _out = new JAXBElement<TFIBanDlngCallBackRq>(new QName("http://www.sama.bea.sa/execution/FIBanDlng", "TFIBanDlngCallBackRq"), TFIBanDlngCallBackRq.class, _requset);
//
//		return _out;
//	}
//
//	
//	private JAXBElement<TFIDenyDlngCallBackRq> getDenyDlngXMLMessageBody(int _task_id, Connection _conn) throws JAXBException, SQLException, DatatypeConfigurationException, IOException {
//		DenyDlngDAO _dao = new DenyDlngDAO();
//		TFIDenyDlngCallBackRq _requset = _dao.GetDenyTaskMessageBody(_task_id, _conn);
//		JAXBElement<TFIDenyDlngCallBackRq> _out = new JAXBElement<TFIDenyDlngCallBackRq>(new QName("http://www.sama.bea.sa/execution/FIDenyDlng", "TFIDenyDlngCallBackRq"), TFIDenyDlngCallBackRq.class, _requset);
//
//		return _out;
//	}
	private JAXBElement<TRqHdr> getXMLMessageHeader(DispatchJob _job , Connection _conn) throws JAXBException, SQLException, IOException {
		DispatchJobDAOImpl _dao = new DispatchJobDAOImpl();
		TRqHdr _header = _dao.GetMessageHeader(_job, _conn);
		JAXBElement<TRqHdr> _out = new JAXBElement<TRqHdr>(new QName("http://www.sama.bea.sa/common/Header", "MsgHdrRq"), TRqHdr.class, _header);
		return _out;
	}

	private String invokeCallBackWS(String _xml_message, String wsURL, String SOAPAction,String httpInd) {
		// Code to make a web service HTTP request
		String responseString = "";
		String outputString = "";
		//
		try {
			URL url = new URL(wsURL);
			URLConnection connection = url.openConnection();
			//mabdelrahman
			
            HttpURLConnection httpConn = (HttpURLConnection) connection;
            if (Boolean.valueOf(httpInd) == true ){
		            	 httpConn = (HttpsURLConnection) connection;
            	HostnameVerifier hv = new HostnameVerifier() {
					public boolean verify(String hostname,
					SSLSession session) {
						logger.log(Level.INFO, "verify " +hostname );
					return true;
					}
					public boolean verify(String hostname, String temp) {
					return true;
					}
					};
					( (HttpsURLConnection) httpConn).setDefaultHostnameVerifier(hv);
					
            }
				
//				
//				KeyStore ks = KeyStore.getInstance("JKS");
//				FileInputStream fis = new FileInputStream("/var/IIB10/cert/");
//				ks.load(fis, "Passw0rd".toCharArray());
//				KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
//				kmf.init(ks, "Passw0rd".toCharArray());
//				SSLContext sc = SSLContext.getInstance("TLS");
//				sc.init(kmf.getKeyManagers(), null, null);
//				httpConn.setSSLSocketFactory(sc.getSocketFactory());
//				
				
				//mabdelrahman

     		ByteArrayOutputStream bout = new ByteArrayOutputStream();

			byte[] buffer = new byte[_xml_message.length()];
			buffer = _xml_message.getBytes();
			bout.write(buffer);
			byte[] b = bout.toByteArray();
			//
			// Set the appropriate HTTP parameters.
			httpConn.setRequestProperty("Content-Length", String.valueOf(b.length));
			httpConn.setRequestProperty("Accept-Charset", "UTF-8");
			httpConn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
			httpConn.setRequestProperty("SOAPAction", SOAPAction);
			httpConn.setRequestMethod("POST");
			httpConn.setDoOutput(true);
			httpConn.setDoInput(true);

			//OutputStream out = httpConn.getOutputStream();
			OutputStreamWriter out = new OutputStreamWriter(httpConn.getOutputStream(), "UTF-8");

			// Write the content of the request to the output stream of the HTTP
			// Connection.
			out.write(_xml_message);
			out.close();
			// Ready with sending the request.

			if (httpConn.getResponseCode() != 200) {
				// Read the response.
				InputStreamReader isr = new InputStreamReader(httpConn.getErrorStream());
				BufferedReader in = new BufferedReader(isr);
				// Write the SOAP message response to a String.
				while ((responseString = in.readLine()) != null) {
					outputString = outputString + responseString;
				}

			} else {
				// Read the response.
				InputStreamReader isr = new InputStreamReader(httpConn.getInputStream());
				BufferedReader in = new BufferedReader(isr);
				// Write the SOAP message response to a String.
				while ((responseString = in.readLine()) != null) {
					outputString = outputString + responseString;
				}
			}

			// Write the SOAP message formatted to the console.
		} catch (Exception ioe) {
				StringWriter _sw = new StringWriter();
			ioe.printStackTrace(new PrintWriter(_sw));
			outputString = _sw.toString();
			logger.log(Level.SEVERE, ioe.getMessage(), ioe);
		}
		return outputString;

	}

	private static String getValue(String _key){
		return  _config_helper.getKeyValue(_key);
	}
}
