package com.sbm.sama.fiportal.services.dispatchresponses.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.common.service.CommonShareService;
import com.sbm.sama.portal.tanfeeth.common.service.CommonUserService;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonShareServiceImpl;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonUserServiceImpl;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TAccountInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TAcctsList;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFIGetAcctsInfoCallBackRq;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TRsrvInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TRsrvList;

public class AccountInfoResponsesDAO {

	public TFIGetAcctsInfoCallBackRq GetAccoutInfoMessageBody(int _task_id, Connection _conn) throws SQLException {
		SimpleDateFormat _sdf = new SimpleDateFormat("YYYY-MM-dd");
		String _sql_acct_info_res = "SELECT * FROM FIPORTAL.ACCOUNT_INFO_RESPONSE WHERE TASK_ID=?";
		String _sql_reserve_info = "SELECT ID, RESPONSE_ID, RESERVED_AMOUNT, RESERVED_BY, RRN FROM FIPORTAL.ACCOUNT_INFO_RESERVE WHERE RESPONSE_ID=? ";

		TFIGetAcctsInfoCallBackRq _output = new TFIGetAcctsInfoCallBackRq();
		CommonUserService cudi = new CommonUserServiceImpl();
		CommonShareService csidi = new CommonShareServiceImpl();
		int _resp_id = 0;
		PreparedStatement _psr = _conn.prepareStatement(_sql_acct_info_res);
		_psr.setInt(1, _task_id);
		ResultSet _rsr = _psr.executeQuery();
		List<TAccountInfo> _items = new ArrayList<TAccountInfo>();
		while (_rsr.next()) {
			TAccountInfo _item = new TAccountInfo();
			_item.setAccNum(_rsr.getString("ACCOUNT_NO"));
			_item.setIBAN(_rsr.getString("IBAN"));
			_item.setAccType(_rsr.getString("ACCOUNT_TYPE"));
			_item.setAccCur(_rsr.getString("CURRENCY"));
			_item.setAccStatus(_rsr.getString("ACCOUNT_STATUS"));
			_item.setInst(_rsr.getString("INSTITUTION"));
			if(_rsr.getTimestamp("ACCOUNT_OPENING_DATE")!=null) _item.setOpnDt(_sdf.format(_rsr.getTimestamp("ACCOUNT_OPENING_DATE")));
			if(_rsr.getTimestamp("ACCOUNT_CLOSING_DATE")!=null) _item.setClsDt(_sdf.format(_rsr.getTimestamp("ACCOUNT_CLOSING_DATE")));
			_item.setAvailBal(_rsr.getBigDecimal("AVAILABLE_BALANCE"));
			_item.setTotBal(_rsr.getBigDecimal("TOTAL_BALANCE"));
			if(_rsr.getTimestamp("BALANCE_DATE")!=null)
				_item.setBalDt(_sdf.format(_rsr.getTimestamp("BALANCE_DATE")));
			_item.setJntAcc(_rsr.getString("IS_JOINT_ACCOUNT"));
			 _resp_id = _rsr.getInt("ID");
			_item.setPrdUsrsList(cudi.selectUserCallBack(_conn,_resp_id));
			PreparedStatement _psrs = _conn.prepareStatement(_sql_reserve_info);
			_psrs.setInt(1, Integer.valueOf(_resp_id));
			ResultSet _rsrs = _psrs.executeQuery();
			List<TRsrvInfo> _ritems = new ArrayList<TRsrvInfo>();
			while (_rsrs.next()) {
				TRsrvInfo _ritem = new TRsrvInfo();
				_ritem.setRsrvAmt(_rsrs.getBigDecimal("RESERVED_AMOUNT"));
				_ritem.setRsrvBy(_rsrs.getString("RESERVED_BY"));
				_ritem.setRRN(_rsrs.getString("RRN"));
				_ritems.add(_ritem);
			}
			if(_ritems.size()>0) {
				TRsrvList _rsrvList = new TRsrvList();
				_rsrvList.rsrvInfo = _ritems;
				_item.setRsrvList(_rsrvList);
			}
			if(_psrs != null) _psrs.close();
			if(_rsrs != null) _rsrs.close();
			_items.add(_item);
		}
		TAcctsList _acctsList = new TAcctsList();
		_acctsList.accInfo = _items;
		_output.setAcctsList(_acctsList);
		_output.setShrsList(csidi.selectShareServiceCallBack(_resp_id, _conn));
		if(_psr != null) _psr.close();
		if(_rsr != null) _rsr.close();	
		return _output;
	}
}
