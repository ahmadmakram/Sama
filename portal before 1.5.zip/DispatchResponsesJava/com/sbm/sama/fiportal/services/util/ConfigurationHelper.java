package com.sbm.sama.fiportal.services.util;

import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ConfigurationHelper {
	  private String _ConfigFile = "sa.gov.sama.be.fiportal.services.util.config";
	  private static PropertyResourceBundle props = null;
	  private static Logger logger = LoggingHelper.getLogger();
	  
	  public ConfigurationHelper()
	  {
	    props = (PropertyResourceBundle)ResourceBundle.getBundle(this._ConfigFile);
	  }
	  
	  public ConfigurationHelper(String _ConfigFile)
	  {
	    this._ConfigFile = _ConfigFile;
	    props = (PropertyResourceBundle)ResourceBundle.getBundle(_ConfigFile);
	  }
	  
	  public String getKeyValue(String _key)
	  {
	    if (get_ConfigFile() == null)
	    {
	      logger.log(Level.CONFIG, "[" + this._ConfigFile + "] NULL Configuration File !!!!!!");
	      return null;
	    }
	    if (_key == null)
	    {
	      logger.log(Level.CONFIG, "[" + _key + "] NULL Key !!!!!!");
	      return null;
	    }
	    String _value = props.getString(_key);
	    
	    return _value;
	  }
	  
	  public String get_ConfigFile()
	  {
	    return this._ConfigFile;
	  }
	  
	  public void set_ConfigFile(String configFile)
	  {
	    this._ConfigFile = configFile;
	  }

}
