package com.sbm.sama.fiportal.services.util;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;


public class LoggingHelper {

	private static final int _logFile_limit = 5242880;
	private static final int _logFile_count = 205;
	private static final String _logger_name = "sa.gov.sama";
	private static Logger logger = Logger.getLogger(_logger_name);
	private static FileHandler _fileHandler;
	private static SimpleFormatter formatterTxt;
	private static ConfigurationHelper _configHelper = new ConfigurationHelper();

	public static void ConfigureLogger(String _log_File, Level _level) {
		SimpleDateFormat _sdf = new SimpleDateFormat("yyyy-MM-dd");
		_log_File = getValue("LOG_DIR") + "/" + _log_File + "_" + _level.getName() + "_" + _sdf.format(new Date()) + "SIT_%g.log";

		
//		if (logger.getHandlers().length == 0) {
			try {
				logger.setLevel(Level.ALL);
				_fileHandler = new FileHandler(_log_File, _logFile_limit, _logFile_count, true);
				formatterTxt = new SimpleFormatter();
				_fileHandler.setFormatter(formatterTxt);
				_fileHandler.setLevel(_level);
				logger.addHandler(_fileHandler);
				logger.setUseParentHandlers(false);
			} catch (IOException e) {
				e.printStackTrace();
			}
//		}
	}

	private static String getValue(String _key) {
		String _value = _configHelper.getKeyValue(_key);
		return _value;
	}

	public static Logger getLogger() {
		return logger;
	}

	public static void setLogger(Logger logger) {
		LoggingHelper.logger = logger;
	}

}
