
package com.sbm.sama.portal.getAllTasks.dao.impl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.getAllTasks.dao.AllTasksDAO;
import com.sbm.sama.portal.tanfeeth.common.util.FieldsProcessing;
import com.sbm.sama.portal.tanfeeth.common.util.MainLogger;
import com.sbm.sama.portal.tanfeeth.common.util.WorkflowStatus;
import com.sbm.sama.portal.tanfeeth.jaxb.getAllTasks.GetAllTasksInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.getAllTasks.GetAllTasksOutputType;
public class AllTasksDAOImpl implements AllTasksDAO {
	private List<Object> queryParams;

    @Override
    public List<GetAllTasksOutputType> getAllTasks(GetAllTasksInputType _input,
            Connection _conn) throws SQLException,
            DatatypeConfigurationException {
        int _filter_index = 0;
        int _first_row = ((_input.getPageNumber() - 1) * _input.getPageSize()) + 1;
        int _last_row = _first_row + _input.getPageSize();
        String _sort_dir = " ASC";
        if (_input.isSortDesc() != null) {
            if (_input.isSortDesc())
                _sort_dir = " DESC";
        }
        String _sql = "SELECT * FROM( SELECT ROWNUM rnum, a.* FROM( SELECT TASK_ID, TASK_REQUEST_METADATA_ID, FI_ID, TASK_CREATED_DATE_TIME, ASSIGNED_DATE_TIME, DUE_DATE_TIME, STATUS_ID, SUB_STATUS_ID, ASSIGNED_TO, ASSIGNED_BY, IS_BULK_PROCESSED, ENTITY_GOV_NAME ,  MANAGER_ACTION_DATE, MAIN_SERVICE_TYPE_NAME, SUB_SERVICE_TYPE_NAME,MAIN_SERVICE_TYPE_CODE,SUB_SERVICE_TYPE_CODE,TASK_CLOSING_DATE_TIME3, TASK_CLOSING_DATE_TIME4, TASK_CLOSING_DATE_TIME5, SLA_MINUTES, EXECUTED_BY, SRN ,LAST_RETURN_DATE_TIME ,EXECUTED_BY_MANAGER,GOV_ID ,INVOLVED_ENTITY_ID_NO ,INVOLVED_ENTITY_ID_TYPE, LAST_ASSIGNED_TO FROM FIPORTAL.TANFEETH_ALL_TASKS_VIEW ";
     
        
        _sql += BuildSQLFilter(_input) + getOrderby(_input) + _sort_dir + ") a WHERE ROWNUM<?) WHERE rnum>=?";
        System.out.println(_sql);
        MainLogger.logData("AllTasksDAOImpl","initial query without adding filter "+_sql);
        List<GetAllTasksOutputType> _output = new ArrayList<GetAllTasksOutputType>();
        PreparedStatement _ps = _conn.prepareStatement(_sql);
        
        for(Object queryParam : queryParams){
        	_ps.setObject(++_filter_index, queryParam);
        }
        
        

        _ps.setInt(++_filter_index, _last_row);
        _ps.setInt(++_filter_index, _first_row);
        
        
        MainLogger.logData("AllTasksDAOImpl","query Parameter Count"+_ps.getParameterMetaData().getParameterCount());

        ResultSet _rs = _ps.executeQuery();
        while (_rs.next()) {          
            GetAllTasksOutputType _item = new GetAllTasksOutputType();
            _item.setTaskId(_rs.getInt("TASK_ID"));
            _item.setRequestId(_rs.getString("TASK_REQUEST_METADATA_ID"));
            _item.setStatusId(_rs.getInt("STATUS_ID"));
            _item.setSubStatusId(_rs.getInt("SUB_STATUS_ID"));
            
            _item.setAssignedTo(_rs.getString("ASSIGNED_TO"));
            _item.setAssignedBy(_rs.getString("ASSIGNED_BY"));
            if(_rs.getString("MAIN_SERVICE_TYPE_CODE") != null){
                _item.setMainServiceCode(_rs.getString("MAIN_SERVICE_TYPE_CODE"));
            }
            
            if(_rs.getString("SUB_SERVICE_TYPE_CODE") != null){
                _item.setSubServiceCode(_rs.getString("SUB_SERVICE_TYPE_CODE"));
            }
            
            if (_rs.getString("SUB_SERVICE_TYPE_NAME") != null) {
                _item.setSubServiceTypeName(_rs.getString("SUB_SERVICE_TYPE_NAME"));
            }
            if (_rs.getString("MAIN_SERVICE_TYPE_NAME") != null) {
                _item.setMainServiceTypeName(_rs.getString("MAIN_SERVICE_TYPE_NAME"));
            }

            if (_rs.getString("IS_BULK_PROCESSED") != null)
                _item.setIsBulkProcessed((_rs.getString("IS_BULK_PROCESSED")
                        .equalsIgnoreCase("YES") ? true : false));
            _item.setRequestReceiveDateTime(FieldsProcessing.getXMLGregCal(_rs
                    .getTimestamp("TASK_CREATED_DATE_TIME")));
            if(_rs.getInt("STATUS_ID") == WorkflowStatus.OFFICER_SUBMIT){
                _item.setLastExecutedByStatus3(_rs.getString("EXECUTED_BY"));
            }
            
            if(_rs.getInt("STATUS_ID") == WorkflowStatus.MANAGER_SUBMIT){
                _item.setLastExecutedByStatus6(_rs.getString("EXECUTED_BY_MANAGER"));
            }
            
            
            if (_rs.getTimestamp("DUE_DATE_TIME") != null)
                _item.setSLADueDateTime(FieldsProcessing.getXMLGregCal(_rs
                        .getTimestamp("DUE_DATE_TIME")));
            
            _item.setTaskClosedBy3(_rs.getString("EXECUTED_BY"));
            _item.setLastAssignedTo(_rs.getString("EXECUTED_BY"));
            if (_rs.getTimestamp("ASSIGNED_DATE_TIME")!=null)_item.setTaskAssignedDateTime(FieldsProcessing.getXMLGregCal(_rs.getTimestamp("ASSIGNED_DATE_TIME")));
            if (_rs.getTimestamp("TASK_CLOSING_DATE_TIME3")!=null)_item.setTaskClosingDateTime3(FieldsProcessing.getXMLGregCal(_rs.getTimestamp("TASK_CLOSING_DATE_TIME3")));
            if (_rs.getTimestamp("TASK_CLOSING_DATE_TIME4")!=null)_item.setTaskClosingDateTime4(FieldsProcessing.getXMLGregCal(_rs.getTimestamp("TASK_CLOSING_DATE_TIME4")));
            if (_rs.getTimestamp("TASK_CLOSING_DATE_TIME5")!=null)_item.setTaskClosingDateTime5(FieldsProcessing.getXMLGregCal(_rs.getTimestamp("TASK_CLOSING_DATE_TIME5")));
            if (_rs.getTimestamp("MANAGER_ACTION_DATE")!=null)_item.setTaskClosingDateTime6(FieldsProcessing.getXMLGregCal(_rs.getTimestamp("MANAGER_ACTION_DATE")));
            if (_rs.getTimestamp("LAST_RETURN_DATE_TIME")!=null)_item.setLastReturnDateTime(FieldsProcessing.getXMLGregCal(_rs.getTimestamp("LAST_RETURN_DATE_TIME")));
            
            _item.setSLATotalMinutes(_rs.getInt("SLA_MINUTES"));
            _item.setSLARemainingMinutes(getSLARemainingMinutes(_rs
                    .getTimestamp("DUE_DATE_TIME")));
            _item.setSRN(_rs.getString("SRN"));
            // _item.setGovEntityName(_rs.getString("GOV_ENTITY_NAME"));
            if(_rs.getString("ENTITY_GOV_NAME") != null){
                _item.setGovEntityName(_rs.getString("ENTITY_GOV_NAME"));
            }
            if(_item.getStatusId()==WorkflowStatus.MANAGER_SUBMIT) {
                String _min = String.valueOf(getMinutesTakenTillCompleted(_rs.getTimestamp("TASK_CREATED_DATE_TIME"), _rs.getTimestamp("MANAGER_ACTION_DATE")));
                _item.setMinutesTakenTillCompleted(_min);
            }
            if(_rs.getString("LAST_ASSIGNED_TO") != null){
            	_item.setLastAssignedTo(_rs.getString("LAST_ASSIGNED_TO"));
            }
            _output.add(_item);
        }
        _rs.close();
        _ps.close();
        return _output;
    }
    private int getSLARemainingMinutes(Timestamp _due_ts) {
        int _min = 0;
        Calendar _cal_now = Calendar.getInstance();
        Timestamp _now_ts = new Timestamp(_cal_now.getTimeInMillis());
        if (_due_ts != null) {
            _min = (int) (_due_ts.getTime() - _now_ts.getTime());
            if (_min < 0) {
                _min = _min / 1000 / 60;
                return _min;
            } else {
                _min = _min / 1000 / 60;
            }
            if (_min > 930) {
                while (_min > 930) {
                    _min = _min - 930;
                }
                _min = _min - 90;
            }
        }
        return _min;
    }
    private int getMinutesTakenTillCompleted(Timestamp _receive_ts,
            Timestamp _closed_ts) {
        long _min = 0;
        if (_closed_ts != null) {
            if (_receive_ts.getDate() != _closed_ts.getDate()) {
                Timestamp _receive_eod_ts = new Timestamp(_receive_ts.getTime());
                Timestamp _closed_sod_ts = new Timestamp(_closed_ts.getTime());
                _receive_eod_ts.setHours(17);
                _receive_eod_ts.setMinutes(30);
                _receive_eod_ts.setSeconds(0);
                _closed_sod_ts.setHours(9);
                _closed_sod_ts.setMinutes(0);
                _closed_sod_ts.setSeconds(0);
                
                long _d1_min = _receive_eod_ts.getTime()
                        - _receive_ts.getTime();
                long _d2_min = _closed_ts.getTime() - _closed_sod_ts.getTime();
                Calendar _cal_receive = Calendar.getInstance();
                _cal_receive.setTimeInMillis(_receive_ts.getTime());
                Calendar _cal_closed = Calendar.getInstance();
                _cal_closed.setTimeInMillis(_closed_ts.getTime());
                int _working_days = 0;
                int _non_working_days = 0;
                while ((_cal_receive.get(Calendar.DAY_OF_YEAR) != _cal_closed
                        .get(Calendar.DAY_OF_YEAR))) {
                    if (_cal_receive.get(Calendar.DAY_OF_WEEK) != Calendar.FRIDAY
                            && _cal_receive.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY) {
                        _working_days++;
                    } else {
                        _non_working_days++;
                    }
                    _cal_receive.add(Calendar.DAY_OF_YEAR, 1);
                }
                // System.out.println("_working_days ===>>>>" + _working_days);
                // System.out.println("_non_working_days ===>>>>" +
                // _non_working_days);
                _min = _d1_min + _d2_min;
                _min = _min / 1000 / 60;
                if (_working_days > 0) {
                    _min += _working_days * 24 * 60;
                }
            } else {
                _min = _closed_ts.getTime() - _receive_ts.getTime();
                _min = _min / 1000 / 60;
            }
        }
        return (int) _min;
    }
    private String BuildSQLFilter(GetAllTasksInputType _input) {
        String _output = "";
        queryParams = new ArrayList<>();
        boolean _isFirstFilter = true;
        if (FieldsProcessing.validateFilterString(_input.getMainServiceCode())) {
            _output += (_isFirstFilter ? " WHERE " : " AND")
                    + " MAIN_SERVICE_TYPE_CODE=?";
            queryParams.add(_input.getMainServiceCode());
            _isFirstFilter = false;
        }
        if (FieldsProcessing.validateFilterString(_input.getSubServiceCode())) {
            String[] _service_codes = _input.getSubServiceCode().split(",");
            _output +=  (_isFirstFilter ? " WHERE" : " AND")
                    + " SUB_SERVICE_TYPE_CODE IN (";
            for (int i = 0; i < _service_codes.length; i++) {
                _output += (i == 0 ? "'" : ",'") + _service_codes[i] + "'";
            }
            _output += ")";
           // queryParams.add(_input.getSubServiceCode());

            _isFirstFilter = false;
        }
        if (_input.getGovEntityId() != null) {
            _output += (_isFirstFilter ? " WHERE " : " AND")
                    + " GOV_ID =?";
            queryParams.add(_input.getGovEntityId());
            _isFirstFilter = false;
        }
        if (_input.getFiCode() != null) {
            _output +=  (_isFirstFilter ? " WHERE " : " AND")
                    + " FI_ID=?";
            queryParams.add(_input.getFiCode());
            _isFirstFilter = false;
        }
        if (_input.getRequestReceiveDateTime() != null) {
            _output += (_isFirstFilter ? " WHERE " : " AND")
                    + " TO_CHAR(TASK_CREATED_DATE_TIME,'YYYY-MON-DD')=?";
             queryParams.add(FieldsProcessing.getTimestamp(_input.getRequestReceiveDateTime()));
            _isFirstFilter = false;
        }
        if (_input.getFiStartDate() != null) {
            _output += (_isFirstFilter ? " WHERE " : " AND")
                    + " TASK_CREATED_DATE_TIME>=?";
            queryParams.add(FieldsProcessing.getTimestamp(_input.getFiStartDate()));
            _isFirstFilter = false;
        }
        if (_input.getFiEndDate() != null) {
            _output +=  (_isFirstFilter ? " WHERE " : " AND")
                    + " TASK_CREATED_DATE_TIME<=?";
            queryParams.add(FieldsProcessing.getTimestamp(_input.getFiEndDate()));
            _isFirstFilter = false;
        }
        if (FieldsProcessing.validateFilterString(_input.getRequestId())) {
            _output += (_isFirstFilter ? " WHERE " : " AND")
                    + " TASK_REQUEST_METADATA_ID=?";
            queryParams.add(_input.getRequestId());
            _isFirstFilter = false;
        }
        if (_input.getTaskStatusId() != null) {
            _output += (_isFirstFilter ? " WHERE " : " AND")
                    + " STATUS_ID=?";
            queryParams.add(_input.getTaskStatusId());
            _isFirstFilter = false;
        }
        if (_input.getTaskSubStatusId() != null) {
            _output +=  (_isFirstFilter ? " WHERE " : " AND")
                    + " SUB_STATUS_ID=?";
            queryParams.add(_input.getTaskSubStatusId());

            _isFirstFilter = false;
        }
        
        if (FieldsProcessing.validateFilterString(_input.getAssignedTo())) {
            _output += (_isFirstFilter ? " WHERE " : " AND") + " ASSIGNED_TO=?";
            queryParams.add(_input.getAssignedTo());
            _isFirstFilter = false;
        }
        if (FieldsProcessing.validateFilterString(_input.getAssignedBy())) {
            _output += (_isFirstFilter ? " WHERE " : " AND") + " ASSIGNED_BY=?";
            queryParams.add(_input.getAssignedBy());

            _isFirstFilter = false;
        }
        if (_input.getDueDateTime() != null) {
            _output += (_isFirstFilter ? " WHERE " : " AND")
                    + " DUE_DATE_TIME=?";
            queryParams.add(FieldsProcessing.getTimestamp(_input.getDueDateTime()));

            _isFirstFilter = false;
        }
        if (_input.isIsBulkProcessed() != null) {
            _output += (_isFirstFilter ? " WHERE " : " AND")
                    + " IS_BULK_PROCESSED=?";
            if(_input.isIsBulkProcessed()){
                queryParams.add("YES");
            }else{
                queryParams.add("NO");
            }
            _isFirstFilter = false;
        }
        if (FieldsProcessing.validateFilterString(_input.getSRN())) {
            _output += (_isFirstFilter ? " WHERE " : " AND")
                    + " SRN=?";
            queryParams.add(_input.getSRN());
            _isFirstFilter = false;
        }
        if (_input.getTaskHistoryStatusId() != null){

        	if(_input.getTaskHistoryStatusId()== WorkflowStatus.MANAGER_SUBMIT ){
        		_output +=(_isFirstFilter ? " WHERE " : " AND") + " (STATUS_ID >= ? OR SUB_STATUS_ID = " + WorkflowStatus.OFFICER_SUBMIT + " )";
        	}else{
        		_output +=(_isFirstFilter ? " WHERE " : " AND") + " STATUS_ID >= ?";	
        	}          
            queryParams.add(_input.getTaskHistoryStatusId());
            _isFirstFilter = false;
        }
             
        if (FieldsProcessing.validateFilterString(_input.getExecutedBy())) {
        	if (_input.getTaskHistoryStatusId() != null)
        		{if (_input.getTaskHistoryStatusId() == WorkflowStatus.MANAGER_SUBMIT)
        			_output += (_isFirstFilter ? "WHERE" : " AND") + " EXECUTED_BY_MANAGER = ? ";
				else
					_output += (_isFirstFilter ? "WHERE" : " AND") + " EXECUTED_BY = ? ";
        		}
        	else
				_output += (_isFirstFilter ? "WHERE" : " AND") + " EXECUTED_BY = ? ";
            queryParams.add(_input.getExecutedBy());
			_isFirstFilter = false;
		}
        if(FieldsProcessing.validateFilterString(_input.getInvolvedEntityIdNo())){
			_output += (_isFirstFilter ? " WHERE " : " AND")
			+ " INVOLVED_ENTITY_ID_NO =?";
			queryParams.add(_input.getInvolvedEntityIdNo());
			_isFirstFilter = false;
        }
        if(FieldsProcessing.validateFilterString(_input.getInvolvedEntityIdType())){
			_output += (_isFirstFilter ? " WHERE " : " AND")
			+ " INVOLVED_ENTITY_ID_TYPE =?";
			queryParams.add(_input.getInvolvedEntityIdType());
			_isFirstFilter = false;
        }        return _output;
    }
    @Override
    public int getAllTasksTotalCount(GetAllTasksInputType _input,
            Connection _conn) throws SQLException {
        int _output = 0;
        int _filter_index = 0;
        String _sql = "SELECT COUNT(*) FROM FIPORTAL.TANFEETH_ALL_TASKS_VIEW";
        _sql += BuildSQLFilter(_input);
        PreparedStatement _ps = _conn.prepareStatement(_sql);

        for(Object queryParam : queryParams){
        	_ps.setObject(++_filter_index, queryParam);
        }
        ResultSet _rs = _ps.executeQuery();
        while (_rs.next()) {
            _output = _rs.getInt(1);
        }
        _rs.close();
        _ps.close();
        return _output;
    }
    // private boolean validateFilterString(String _input) {
    // boolean _isValid = false;
    //
    // if (_input != null && _input.trim().length() > 0) _isValid = true;
    //
    // return _isValid;
    // }
    private String getOrderby(GetAllTasksInputType _input) {
        String _out = "ORDER BY TASK_CREATED_DATE_TIME";
        if (_input.getOrderBy() != null) {
            if (_input.getOrderBy().equalsIgnoreCase("request_id"))
                _out = " ORDER BY TASK_REQUEST_METADATA_ID";
            else if (_input.getOrderBy().equalsIgnoreCase("task_id"))
                _out = " ORDER BY TASK_ID";
            else if (_input.getOrderBy().equalsIgnoreCase("status_id"))
                _out = " ORDER BY STATUS_ID";
            else if (_input.getOrderBy().equalsIgnoreCase("main_service_code"))
                _out = " ORDER BY MAIN_SERVICE_TYPE_CODE";
            else if (_input.getOrderBy().equalsIgnoreCase("sub_service_code"))
                _out = " ORDER BY SUB_SERVICE_TYPE_CODE";
             else if(
             _input.getOrderBy().equalsIgnoreCase("main_service_type_name"))
             _out = " ORDER BY MAIN_SERVICE_TYPE_NAME";
             else if(
             _input.getOrderBy().equalsIgnoreCase("sub_service_type_name"))
             _out = " ORDER BY SUB_SERVICE_TYPE_NAME";
            else if (_input.getOrderBy().equalsIgnoreCase("assigned_to"))
                _out = " ORDER BY ASSIGNED_TO";
            else if (_input.getOrderBy().equalsIgnoreCase("assigned_by"))
                _out = " ORDER BY ASSIGNED_BY";
            else if (_input.getOrderBy().equalsIgnoreCase("is_bulk_processed"))
                _out = " ORDER BY IS_BULK_PROCESSED";
            else if (_input.getOrderBy().equalsIgnoreCase(
                    "request_receive_date_time"))
                _out = " ORDER BY TASK_CREATED_DATE_TIME";
        }
        return _out;
    }
}
 