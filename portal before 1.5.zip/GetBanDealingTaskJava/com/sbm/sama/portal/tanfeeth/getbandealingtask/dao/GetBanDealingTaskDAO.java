package com.sbm.sama.portal.tanfeeth.getbandealingtask.dao;

import java.sql.Connection;

import com.sbm.sama.portal.tanfeeth.jaxb.getbandealing.GetBanDealingTaskInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.getbandealing.GetBanDealingTaskOutputType;



public interface GetBanDealingTaskDAO {

	public GetBanDealingTaskOutputType GetBanDealingTask(
			GetBanDealingTaskInputType _input, Connection _conn);
		
	

}
