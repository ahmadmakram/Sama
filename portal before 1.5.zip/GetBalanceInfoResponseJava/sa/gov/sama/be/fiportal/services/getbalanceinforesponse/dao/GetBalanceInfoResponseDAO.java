package sa.gov.sama.be.fiportal.services.getbalanceinforesponse.dao;

import java.sql.Connection;
import java.sql.SQLException;
import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.tanfeeth.jaxb.common.GetBalanceInfoResponseInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetBalanceInfoResponseOutputType;

public interface GetBalanceInfoResponseDAO {
	public GetBalanceInfoResponseOutputType GetBalanceInfoResponse(GetBalanceInfoResponseInputType _input, Connection _conn) throws SQLException, DatatypeConfigurationException;
}
