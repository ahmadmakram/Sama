package sa.gov.sama.be.fiportal.services.getsafeinforesponse.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.tanfeeth.jaxb.common.GetSafeInfoResponseInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetSafeInfoResponseOutputType;


public interface GetSafeInfoResponseDAO {
	public GetSafeInfoResponseOutputType GetSafeInfoResponse(GetSafeInfoResponseInputType _input, Connection _conn) throws SQLException, DatatypeConfigurationException;
}
