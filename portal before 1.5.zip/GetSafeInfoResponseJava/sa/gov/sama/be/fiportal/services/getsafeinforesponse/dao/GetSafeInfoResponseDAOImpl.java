package sa.gov.sama.be.fiportal.services.getsafeinforesponse.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.tanfeeth.common.service.CommonTaskService;
import com.sbm.sama.portal.tanfeeth.common.service.CommonUserService;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonTaskServiceImpl;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonUserServiceImpl;
import com.sbm.sama.portal.tanfeeth.common.util.FieldsProcessing;
import com.sbm.sama.portal.tanfeeth.common.util.MessageProcessor;
import com.sbm.sama.portal.tanfeeth.common.util.WorkflowTaskBean;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetSafeInfoResponseInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetSafeInfoResponseOutputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.SafeInfoResponseType;

public class GetSafeInfoResponseDAOImpl implements GetSafeInfoResponseDAO {

	@Override
	public GetSafeInfoResponseOutputType GetSafeInfoResponse(GetSafeInfoResponseInputType _input, Connection _conn) throws SQLException, DatatypeConfigurationException {
		String _sql_safe_info_res = "SELECT * FROM FIPORTAL.SAFE_INFO_RESPONSE WHERE TASK_ID =?";
		int responseID=0;

		GetSafeInfoResponseOutputType _output = null;
		PreparedStatement _psr = _conn.prepareStatement(_sql_safe_info_res);

		CommonUserService cudi = new CommonUserServiceImpl();
		CommonTaskService ctdi= new CommonTaskServiceImpl();
		WorkflowTaskBean workflowTaskBean = ctdi.selectTaskService(_conn,_input.getTaskId());
		
		if (workflowTaskBean.getTaskId() > 0) {
			_output = new GetSafeInfoResponseOutputType();
			_output.setWorkflowTaskInfo(MessageProcessor.mapWorkflowTaskInfo(workflowTaskBean));

			_psr.setInt(1,_input.getTaskId());
			ResultSet _rsr = _psr.executeQuery();
			List<SafeInfoResponseType> _items = new ArrayList<SafeInfoResponseType>();
			while (_rsr.next()) {
				SafeInfoResponseType _item = new SafeInfoResponseType();
				 responseID=_rsr.getInt("ID");

				_item.setSafeBranch(_rsr.getString("SAFE_BRANCH"));
				_item.setBoxNo(_rsr.getString("BOX_NO"));
				_item.setBoxOpenDate(FieldsProcessing.getXMLGregCal(_rsr.getTimestamp("BOX_OPEN_DATE")));
				_item.setIsJointSafe(_rsr.getString("IS_JOINT_SAFE"));

				_item.userInfoResponse = cudi.selectUserService(_conn,responseID);

				_items.add(_item);
			}
			_output.safeInfoResponse = _items;
		}
		
		if(_psr != null) _psr.close();
		
		return _output;
	}
}