package sa.gov.sama.be.fiportal.services.getliabilitiesinforesponse.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.tanfeeth.common.service.CommonTaskService;
import com.sbm.sama.portal.tanfeeth.common.service.CommonUserService;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonTaskServiceImpl;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonUserServiceImpl;
import com.sbm.sama.portal.tanfeeth.common.util.FieldsProcessing;
import com.sbm.sama.portal.tanfeeth.common.util.MessageProcessor;
import com.sbm.sama.portal.tanfeeth.common.util.WorkflowTaskBean;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetLiabilitiesInfoResponseInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetLiabilitiesInfoResponseOutputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.LiabilitiesInfoResponseType;

public class GetLiabilitiesInfoResponseDAOImpl implements GetLiabilitiesInfoResponseDAO {

	@Override
	public GetLiabilitiesInfoResponseOutputType GetLiabilitiesInfoResponse(GetLiabilitiesInfoResponseInputType _input, Connection _conn) throws SQLException, DatatypeConfigurationException {
		String _sql_liab_info_res = "SELECT * FROM FIPORTAL.LIABILITY_INFO_RESPONSE WHERE TASK_ID =?";
		int responseID=0;

		GetLiabilitiesInfoResponseOutputType _output = null;
		CommonUserService cudi = new CommonUserServiceImpl();
		CommonTaskService ctdi= new CommonTaskServiceImpl();
	WorkflowTaskBean workflowTaskBean = ctdi.selectTaskService(_conn,_input.getTaskId());
		
		if (workflowTaskBean.getTaskId() > 0) {
			_output = new GetLiabilitiesInfoResponseOutputType();
			_output.setWorkflowTaskInfo(MessageProcessor.mapWorkflowTaskInfo(workflowTaskBean));

			PreparedStatement _psr = _conn.prepareStatement(_sql_liab_info_res);

			_psr.setInt(1, _input.getTaskId());
			ResultSet _rsr = _psr.executeQuery();
			List<LiabilitiesInfoResponseType> _items = new ArrayList<LiabilitiesInfoResponseType>();
			while (_rsr.next()) {
				LiabilitiesInfoResponseType _item = new LiabilitiesInfoResponseType();
				 responseID=_rsr.getInt("ID");

				_item.setAccountNo(_rsr.getString("ACCOUNT_NO"));
				_item.setIban(_rsr.getString("IBAN"));
				_item.setLiabilityType(_rsr.getString("LIABILITY_TYPE"));
				_item.setCurrency(_rsr.getString("CURRENCY"));
				_item.setNumberOfInstallements(_rsr.getInt("NUMBER_OF_INSTALLEMENTS"));
				_item.setInstallmentRepInterval(_rsr.getString("INSTALLEMENT_REP_INTERVAL"));
				_item.setInstallmentAmount(_rsr.getBigDecimal("INSTALLMENT_AMOUNT"));
				// mabdelrahman LAST_PAYMENT_DATE is optional 

				if (_rsr.getTimestamp("LAST_PAYMENT_DATE") != null) {
				
				_item.setLastPaymentDate(FieldsProcessing.getXMLGregCal(_rsr.getTimestamp("LAST_PAYMENT_DATE")));
				}
				
				_item.setLiabilityDueDate(FieldsProcessing.getXMLGregCal(_rsr.getTimestamp("LIABILITY_DUE_DATE")));
				_item.setTotalLiabilityAmount(_rsr.getBigDecimal("TOTAL_LIABILITY_AMOUNT"));
				_item.setRemainingLiability(_rsr.getBigDecimal("REMAINING_LIABILITY"));
				
				
				_item.userInfoResponse = cudi.selectUserService(_conn,responseID);
				_items.add(_item);
				
			}
			_output.liabilitiesInfoResponse = _items;
		}
	
		return _output;
	}
}