package sa.gov.sama.be.fiportal.services.getliabilitiesinforesponse.dao;

import java.sql.Connection;
import java.sql.SQLException;
import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.tanfeeth.jaxb.common.GetLiabilitiesInfoResponseInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetLiabilitiesInfoResponseOutputType;

public interface GetLiabilitiesInfoResponseDAO {
	public GetLiabilitiesInfoResponseOutputType GetLiabilitiesInfoResponse(GetLiabilitiesInfoResponseInputType _input, Connection _conn) throws SQLException, DatatypeConfigurationException;

}
