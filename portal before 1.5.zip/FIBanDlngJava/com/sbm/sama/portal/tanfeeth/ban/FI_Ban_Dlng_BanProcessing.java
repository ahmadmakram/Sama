package com.sbm.sama.portal.tanfeeth.ban;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;

import org.w3c.dom.Document;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import com.sbm.portal.tanfeeth.ban.service.FiBanDlngService;
//import com.sbm.sama.portal.tanfeeth.jaxb.baseLib.TGovernment;
//import com.sbm.sama.portal.tanfeeth.jaxb.baseLib.TIndividual;
//import com.sbm.sama.portal.tanfeeth.jaxb.baseLib.TRqstr;
//import com.sbm.sama.portal.tanfeeth.jaxb.baseLib.TThrdPrty;
import com.sbm.sama.portal.tanfeeth.jaxb.fiBanDlng.ObjectFactory;
import com.sbm.sama.portal.tanfeeth.jaxb.fiBanDlng.TFIBanDlngRq;
import com.sbm.sama.portal.tanfeeth.jaxb.fiBanDlng.TFIBanDlngRs;
import com.sbm.sama.portal.tanfeeth.jaxb.header.TRqHdr;
import com.sbm.sama.portal.tanfeeth.service.InvolvedEntityService;
import com.sbm.sama.portal.tanfeeth.service.RequestMetaDataService;
import com.sbm.sama.portal.tanfeeth.service.WorkFlowTaskService;

import com.sbm.sama.portal.tanfeeth.jaxb.fiBanDlng.TThrdPrty;
import com.sbm.sama.portal.tanfeeth.jaxb.fiBanDlng.TRqstr;
import com.sbm.sama.portal.tanfeeth.jaxb.fiBanDlng.TIndividual;
import com.sbm.sama.portal.tanfeeth.jaxb.fiBanDlng.TGovernment;

/**
 * 
 * @author Mahmoud Fahmi
 * 
 */
public class FI_Ban_Dlng_BanProcessing extends MbJavaComputeNode {

	private JAXBContext jaxbContextHeader = null;
	private JAXBContext jaxbContextBanDlng = null;
	private JAXBContext jaxbContextBaseLib = null;
	private JAXBContext jaxbContext = null;

	private RequestMetaDataService requestMetaDataService;
	private InvolvedEntityService involvedEntityService;
	private FiBanDlngService fiBanDlngService;
	private WorkFlowTaskService workFlowTaskService;
	
//	public void onInitialize() throws MbException {
//		try {
//			jaxbContextBanDlng = JAXBContext
//					.newInstance("com.sbm.sama.portal.tanfeeth.jaxb.fiBanDlng");
//
//			jaxbContextHeader = JAXBContext
//					.newInstance("com.sbm.sama.portal.tanfeeth.jaxb.header");
//
//			jaxbContextBaseLib = JAXBContext
//					.newInstance("com.sbm.sama.portal.tanfeeth.jaxb.baseLib");
//
//		} catch (JAXBException e) {
//			// This exception will cause the deploy of this Java compute node to
//			// fail
//			// Typical cause is the JAXB package above is not available
//			throw new MbUserException(this, "onInitialize()", "", "",
//					e.getMessage(), null);
//		}
//	}

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {

		// obtain the input message data
		MbMessage inMessage = inAssembly.getMessage();
		MbMessage inLocalEnvironment = inAssembly.getLocalEnvironment();

		// create a new empty output message
		MbMessage outMessage = new MbMessage();
		
		try {
			Connection connection = getJDBCType4Connection("XE",
					JDBC_TransactionType.MB_TRANSACTION_AUTO);

			jaxbContextBanDlng = JAXBContext
					.newInstance("com.sbm.sama.portal.tanfeeth.jaxb.fiBanDlng");

			jaxbContextHeader = JAXBContext
					.newInstance("com.sbm.sama.portal.tanfeeth.jaxb.header");

			jaxbContextBaseLib = JAXBContext
					.newInstance("com.sbm.sama.portal.tanfeeth.jaxb.baseLib");

			JAXBElement<TRqHdr> jaxRqHdr = 
					jaxbContextHeader.createUnmarshaller()
					.unmarshal(
							inLocalEnvironment.getRootElement().getLastChild()
									.getLastChild().getFirstChild()
									.getLastChild().getLastChild().getDOMNode(),
							TRqHdr.class);

			JAXBElement<TRqstr> jaxRqStr = 
					jaxbContextBanDlng.createUnmarshaller().unmarshal(
							inMessage.getRootElement().getLastChild()
									.getLastChild().getDOMNode(), TRqstr.class);//jaxbContextBaseLib

			JAXBElement<TThrdPrty> jaxThrdParty = 
					jaxbContextBanDlng.createUnmarshaller().unmarshal(
							inMessage.getRootElement().getLastChild()
									.getLastChild().getDOMNode(),
							TThrdPrty.class);//jaxbContextBaseLib

			JAXBElement<TRqstr> jaxTRqstr = 
					jaxbContextBanDlng.createUnmarshaller().unmarshal(
							inMessage.getRootElement().getLastChild()
									.getLastChild().getDOMNode(), TRqstr.class);//jaxbContextBaseLib

			JAXBElement<TGovernment> jaxTGovernment = 
					jaxbContextBanDlng.createUnmarshaller().unmarshal(
							inMessage.getRootElement().getLastChild()
									.getLastChild().getDOMNode(),
							TGovernment.class);//jaxbContextBaseLib

			JAXBElement<TIndividual> jaxInvolvedEntity = 
					jaxbContextBanDlng.createUnmarshaller().unmarshal(
							inMessage.getRootElement().getLastChild()
									.getLastChild().getDOMNode(),
							TIndividual.class);//jaxbContextBaseLib

			JAXBElement<TFIBanDlngRq> jaxBanDlng = jaxbContextBanDlng
					.createUnmarshaller().unmarshal(
							inMessage.getRootElement().getLastChild()
									.getLastChild().getDOMNode(),
							TFIBanDlngRq.class);

			Boolean isRMSuccess = requestMetaDataService.addRequestMetaData(
					jaxRqHdr.getValue(), jaxTGovernment.getValue(),
					jaxThrdParty.getValue(), jaxRqStr.getValue(),
					jaxTRqstr.getValue(), connection);

			Boolean isIESuccess = involvedEntityService.addInvolvedEntity(
					jaxInvolvedEntity.getValue(), connection);

			Boolean isBanReqSuccess = fiBanDlngService.addBanDlngRequest(
					jaxBanDlng.getValue(), connection);

			Boolean isWFSuccess = workFlowTaskService.addWorkFlowTask(
					jaxRqHdr.getValue(), connection);

			if (isRMSuccess || isIESuccess ||isBanReqSuccess || isWFSuccess) {
				ObjectFactory objFactory = new ObjectFactory();
				TFIBanDlngRs value = new TFIBanDlngRs();
				JAXBElement<TFIBanDlngRs> _response = objFactory
						.createFIBanDlngRs(value);
				Document outDocument = outMessage
						.createDOMDocument(MbXMLNSC.PARSER_NAME);
				jaxbContext.createMarshaller().marshal(_response, outDocument);
			} else {
				jaxRqHdr.getValue().setStatus("E0000000");
				jaxRqHdr.getValue().setNote("Failed");
			}

		} catch (JAXBException | SQLException | IOException | ParseException e) {
			// Example Exception handling
			throw new MbUserException(this, "evaluate()", "", "",
					e.getMessage(), null);
		}
	}

}
