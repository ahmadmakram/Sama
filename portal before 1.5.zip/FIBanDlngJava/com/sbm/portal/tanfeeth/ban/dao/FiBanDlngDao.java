package com.sbm.portal.tanfeeth.ban.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.sbm.sama.portal.tanfeeth.jaxb.fiBanDlng.TFIBanDlngRq;

/**
 * 
 * @author Mahmoud Fahmi
 *
 */
public interface FiBanDlngDao {
	public Boolean addBanDlngRequest(TFIBanDlngRq banDlngReq,int taskId,Connection conn)throws SQLException;
}
