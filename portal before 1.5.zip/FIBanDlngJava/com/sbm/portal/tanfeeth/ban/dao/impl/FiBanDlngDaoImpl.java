package com.sbm.portal.tanfeeth.ban.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.sbm.portal.tanfeeth.ban.dao.FiBanDlngDao;
import com.sbm.sama.portal.tanfeeth.jaxb.fiBanDlng.TFIBanDlngRq;
import com.sbm.sama.portal.tanfeeth.util.DatabaseUtility;

/**
 * 
 * @author Mahmoud Fahmi
 *
 */
public class FiBanDlngDaoImpl implements FiBanDlngDao {

	@Override
	public Boolean addBanDlngRequest(TFIBanDlngRq banDlngReq,int taskId,Connection conn) throws SQLException{
		Boolean isBanDlngReqInserted = false;
		String banDlngReqStmt = "INSERT INTO FIPORTAL.BAN_DEALING_REQUEST (ID, DCSN_NO, DCSN_DT, DUE_DATE_TIME, TASK_ID) VALUES (FIPORTAL.BAN_REQ_ID.NEXTVAL,?,?,?,?)";
		PreparedStatement banDlngReqPreparedStmt = conn
				.prepareStatement(banDlngReqStmt);

		banDlngReqPreparedStmt.setString(1, banDlngReq.getDcsnInfo().getNum());
		banDlngReqPreparedStmt.setString(2, banDlngReq.getDcsnInfo().getDt());
		banDlngReqPreparedStmt.setTimestamp(3, DatabaseUtility.getTaskDueDateTime());
		banDlngReqPreparedStmt.setInt(4,taskId);
		banDlngReqPreparedStmt.executeUpdate();

		isBanDlngReqInserted = true;

		if (banDlngReqPreparedStmt != null) {
			banDlngReqPreparedStmt.close();
		}

		return isBanDlngReqInserted;
		
	}
	
}
