package com.sbm.portal.tanfeeth.ban.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.sbm.portal.tanfeeth.ban.dao.FiBanDlngDao;
import com.sbm.portal.tanfeeth.ban.service.FiBanDlngService;
import com.sbm.sama.portal.tanfeeth.jaxb.fiBanDlng.TFIBanDlngRq;

/**
 * 
 * @author Mahmoud Fahmi
 *
 */
public class FiBanDlngServiceImpl implements FiBanDlngService {
	
	private FiBanDlngDao banDlngDao;

	@Override
	public Boolean addBanDlngRequest(TFIBanDlngRq banDlngReq,Connection conn) throws SQLException {
		int taskId = getTaskIdNEXTVAL(conn);
		return banDlngDao.addBanDlngRequest(banDlngReq, taskId, conn);

	}

	private int getTaskIdNEXTVAL(Connection conn) throws SQLException {
		int id = 0;
		String sql = "SELECT FIPORTAL.WORKFLOW_TASK_ID.NEXTVAL FROM DUAL";
		PreparedStatement preparedStmt = conn.prepareStatement(sql);
		ResultSet _rs = preparedStmt.executeQuery();
		if (_rs.next())
			id = _rs.getInt(1);
		if (preparedStmt != null)
			preparedStmt.close();
		return id;
	}
}
