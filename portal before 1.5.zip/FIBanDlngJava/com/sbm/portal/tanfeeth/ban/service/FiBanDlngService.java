package com.sbm.portal.tanfeeth.ban.service;

import java.sql.Connection;
import java.sql.SQLException;

import com.sbm.sama.portal.tanfeeth.jaxb.fiBanDlng.TFIBanDlngRq;

/**
 * 
 * @author Mahmoud Fahmi
 *
 */
public interface FiBanDlngService {
	public Boolean addBanDlngRequest(TFIBanDlngRq banDlngReq,Connection conn)throws SQLException;
}
