package sa.gov.sama.be.fiportal.services.getdepositinforesponse.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.tanfeeth.common.service.CommonTaskService;
import com.sbm.sama.portal.tanfeeth.common.service.CommonUserService;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonTaskServiceImpl;
import com.sbm.sama.portal.tanfeeth.common.service.impl.CommonUserServiceImpl;
import com.sbm.sama.portal.tanfeeth.common.util.FieldsProcessing;
import com.sbm.sama.portal.tanfeeth.common.util.MessageProcessor;
import com.sbm.sama.portal.tanfeeth.common.util.WorkflowTaskBean;
import com.sbm.sama.portal.tanfeeth.jaxb.common.DepositeInfoResponseType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetDepositInfoResponseInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetDepositInfoResponseOutputType;

public class GetDepositInfoResponseDAOImpl implements GetDepositInfoResponseDAO {

	@Override
	public GetDepositInfoResponseOutputType GetDepositInfoResponse(GetDepositInfoResponseInputType _input, Connection _conn) throws SQLException, DatatypeConfigurationException {
		String _sql_depo_info_res = "SELECT * FROM FIPORTAL.DEPOSIT_INFO_RESPONSE WHERE TASK_ID =?";
		int responseID=0;


		GetDepositInfoResponseOutputType _output = null;
		CommonUserService cudi = new CommonUserServiceImpl();
		CommonTaskService ctdi= new CommonTaskServiceImpl();
	
		WorkflowTaskBean workflowTaskBean = ctdi.selectTaskService(_conn,_input.getTaskId());
		
		if (workflowTaskBean.getTaskId() > 0) {
			_output = new GetDepositInfoResponseOutputType();
			_output.setWorkflowTaskInfo(MessageProcessor.mapWorkflowTaskInfo(workflowTaskBean));

			PreparedStatement _psr = _conn.prepareStatement(_sql_depo_info_res);
			_psr.setInt(1, _input.getTaskId());
			ResultSet _rsr = _psr.executeQuery();
			List<DepositeInfoResponseType> _items = new ArrayList<DepositeInfoResponseType>();
			while (_rsr.next()) {
				DepositeInfoResponseType _item = new DepositeInfoResponseType();
				 responseID=_rsr.getInt("ID");

				_item.setDepositNo(_rsr.getString("DEPOSIT_NO"));
				_item.setDepositType(_rsr.getString("DEPOSIT_TYPE"));
				_item.setCurrency(_rsr.getString("CURRENCY"));
				_item.setDepositStatus(_rsr.getString("DEPOSIT_STATUS"));
				_item.setStartDate(FieldsProcessing.getXMLGregCal(_rsr.getTimestamp("START_DATE")));
				_item.setDueDate(FieldsProcessing.getXMLGregCal(_rsr.getTimestamp("DUE_DATE")));
				_item.setDepositBalance(_rsr.getBigDecimal("DEPOSIT_BALANCE"));
				_item.setIsJointDeposit(_rsr.getString("IS_JOINT_DEPOSIT"));

				_item.userInfoResponse = cudi.selectUserService(_conn,responseID);
				_items.add(_item);
			}
			_output.depositeInfoResponse = _items;
			_rsr.close();
		}
		return _output;
	}
}
