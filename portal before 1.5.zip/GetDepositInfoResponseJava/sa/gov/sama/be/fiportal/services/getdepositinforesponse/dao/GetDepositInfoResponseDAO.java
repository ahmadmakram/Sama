package sa.gov.sama.be.fiportal.services.getdepositinforesponse.dao;

import java.sql.Connection;
import java.sql.SQLException;
import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.tanfeeth.jaxb.common.GetDepositInfoResponseInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetDepositInfoResponseOutputType;

public interface GetDepositInfoResponseDAO {
	public GetDepositInfoResponseOutputType GetDepositInfoResponse(GetDepositInfoResponseInputType _input, Connection _conn) throws SQLException, DatatypeConfigurationException;
}
