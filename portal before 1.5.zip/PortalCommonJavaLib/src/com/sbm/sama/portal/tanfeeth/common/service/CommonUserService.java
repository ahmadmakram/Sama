package com.sbm.sama.portal.tanfeeth.common.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.jaxb.common.TPrdUsrsLis;
import com.sbm.sama.portal.tanfeeth.jaxb.common.UserInfoResponseType;


public interface CommonUserService {
	public void addUserService(List<UserInfoResponseType> userInfoResponseTypeList,
			Connection conn, int taskId ,int responseID, String prodcutType) throws SQLException;

	public void deleteUserService(int taskId, Connection conn)
			throws SQLException;
	
	public List<UserInfoResponseType>  selectUserService(Connection _conn, int taskId) throws SQLException ;

	public TPrdUsrsLis selectUserCallBack(Connection _conn, int _task_id) throws SQLException;

}
