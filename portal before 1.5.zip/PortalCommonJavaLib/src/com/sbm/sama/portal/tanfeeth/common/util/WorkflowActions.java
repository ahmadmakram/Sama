package com.sbm.sama.portal.tanfeeth.common.util;

public class WorkflowActions {

	public final static String SUBMIT = "OFFICER_SUBMIT";
	public final static String SUBMIT_BULK = "OFFICER_SUBMIT_BULK";
	public final static String APPROVE = "MANAGER_APPROVE";
	public final static String REJECT_TO_OFF = "REJECT_TO_OFFICER";
	public final static String REJECT_TO_OFF_QUEUE = "REJECT_TO_QUEUE";
	public final static String RETURN_TO_OFF_QUEUE = "RETURN_TO_OFFICER_QUEUE";
	public final static String RETURN_TO_MANG_QUEUE = "RETURN_TO_MANAGER_QUEUE";
	

}
