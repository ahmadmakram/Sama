package com.sbm.sama.portal.tanfeeth.common.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import com.sbm.sama.portal.tanfeeth.jaxb.common.ShareInfoResponseType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TShrsList;

public interface CommonShareInfoDao {
	public void addShare(Connection conn,List<ShareInfoResponseType> _shareInfo_list,int taskId, String prodcutType) throws SQLException;
	public void deleteShare(int taskId,Connection _conn) throws SQLException;
	public List<ShareInfoResponseType> selectShare(int taskId,Connection _conn) throws SQLException;
	public TShrsList selectShareCallBack(int taskId, Connection _conn) throws SQLException;
}
