package com.sbm.sama.portal.tanfeeth.common.enums;

public enum AccountType {
	TRANSFER,
	BLOCK
}
