package com.sbm.sama.portal.tanfeeth.common.service.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.common.dao.CommonUserDao;
import com.sbm.sama.portal.tanfeeth.common.dao.impl.CommonUserDaoImpl;
import com.sbm.sama.portal.tanfeeth.common.service.CommonUserService;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TPrdUsrsLis;
import com.sbm.sama.portal.tanfeeth.jaxb.common.UserInfoResponseType;

public class CommonUserServiceImpl implements CommonUserService{

	private CommonUserDao commonUserDao = new CommonUserDaoImpl();
	

	@Override
	public void deleteUserService(int taskId,
			Connection conn) throws SQLException {
		commonUserDao.deleteUser(taskId, conn);		
	}

	@Override
	public List<UserInfoResponseType> selectUserService(Connection _conn, int taskId)
			throws SQLException {

		return commonUserDao.selectUser(_conn, taskId);
	}

	@Override
	public TPrdUsrsLis selectUserCallBack(Connection _conn, int _task_id) throws SQLException {
		// TODO Auto-generated method stub
 		return commonUserDao.selectUserCallBack(_conn, _task_id);

	}

	@Override
	public void addUserService(
			List<UserInfoResponseType> userInfoResponseTypeList,
			Connection conn, int taskId, int responseID, String prodcutType)
			throws SQLException {
		commonUserDao.addUser(userInfoResponseTypeList,conn, taskId,responseID , prodcutType);
		
	}


}
