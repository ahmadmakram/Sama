package com.sbm.sama.portal.tanfeeth.common.service;

import java.sql.Connection;
import java.sql.SQLException;

import com.sbm.sama.portal.tanfeeth.common.util.WorkflowTaskBean;

public interface CommonTaskService {
	public void updateTaskService( Connection conn,WorkflowTaskBean workflowTaskBean) throws SQLException ;
	public String getTaskCallBackStatusService( Connection conn, int taskId) throws SQLException;
	public WorkflowTaskBean selectTaskService( Connection _conn, int TaskId ) throws SQLException ;
	
}
