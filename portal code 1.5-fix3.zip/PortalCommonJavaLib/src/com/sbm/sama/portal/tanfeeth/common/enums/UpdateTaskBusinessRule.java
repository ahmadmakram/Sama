package com.sbm.sama.portal.tanfeeth.common.enums;

public enum UpdateTaskBusinessRule {
	MANAGER_OFFICER_INBOX ("2235"),
	MANAGER_SUBMIT ("2605"),
	MANAGER_OFFICER_Q ("2135");
	
	String updateTaskBusinessRule = null;
	
	UpdateTaskBusinessRule (String updateTaskBusinessRule){
		this.updateTaskBusinessRule = updateTaskBusinessRule;
	}
	
	public String getValue(){
		return this.updateTaskBusinessRule;
	}

}
