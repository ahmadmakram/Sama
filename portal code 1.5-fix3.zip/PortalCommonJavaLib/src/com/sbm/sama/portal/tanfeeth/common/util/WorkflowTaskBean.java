package com.sbm.sama.portal.tanfeeth.common.util;

import java.sql.Timestamp;



public class WorkflowTaskBean {

 
    private Integer taskId;
    private Integer requestId;
    private String pid;
    private Timestamp createdDateTime;
    private Timestamp dueDateTime;
    private Timestamp assignedDateTime;
    private String assignedTo;
    private String assignedBy;
    private String assignedByRole;
    private Integer statusId;
    private Integer subStatusId;
    private String isBulkProcessed;
    private String requireChecker;
    private Timestamp managerActionTime;
    private String executedBy;
    private Integer slaMinutes;
    private Timestamp lastReturnDateTime;
    private Integer exetrSrvcTaskId;
    private String notes;
    private String statusCode;
    private Timestamp officerExecutedDate;
    private Timestamp modificationDate;
    private String executedByManager;
    private String lastAssignedTo;
    private String msgUID;
    
    
	public Integer getTaskId() {
		return taskId;
	}
	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}
	public Integer getRequestId() {
		return requestId;
	}
	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public Timestamp getCreatedDateTime() {
		return createdDateTime;
	}
	public void setCreatedDateTime(Timestamp createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	public Timestamp getDueDateTime() {
		return dueDateTime;
	}
	public void setDueDateTime(Timestamp dueDateTime) {
		this.dueDateTime = dueDateTime;
	}
	public Timestamp getAssignedDateTime() {
		return assignedDateTime;
	}
	public void setAssignedDateTime(Timestamp assignedDateTime) {
		this.assignedDateTime = assignedDateTime;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getAssignedBy() {
		return assignedBy;
	}
	public void setAssignedBy(String assignedBy) {
		this.assignedBy = assignedBy;
	}
	public String getAssignedByRole() {
		return assignedByRole;
	}
	public void setAssignedByRole(String assignedByRole) {
		this.assignedByRole = assignedByRole;
	}
	public Integer getStatusId() {
		return statusId;
	}
	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}
	public Integer getSubStatusId() {
		return subStatusId;
	}
	public void setSubStatusId(Integer subStatusId) {
		this.subStatusId = subStatusId;
	}
	public String getIsBulkProcessed() {
		return isBulkProcessed;
	}
	public void setIsBulkProcessed(String isBulkProcessed) {
		this.isBulkProcessed = isBulkProcessed;
	}
	public String getRequireChecker() {
		return requireChecker;
	}
	public void setRequireChecker(String requireChecker) {
		this.requireChecker = requireChecker;
	}
	public Timestamp getManagerActionTime() {
		return managerActionTime;
	}
	public void setManagerActionTime(Timestamp managerActionTime) {
		this.managerActionTime = managerActionTime;
	}
	public String getExecutedBy() {
		return executedBy;
	}
	public void setExecutedBy(String executedBy) {
		this.executedBy = executedBy;
	}
	public Integer getSlaMinutes() {
		return slaMinutes;
	}
	public void setSlaMinutes(Integer slaMinutes) {
		this.slaMinutes = slaMinutes;
	}
	public Timestamp getLastReturnDateTime() {
		return lastReturnDateTime;
	}
	public void setLastReturnDateTime(Timestamp lastReturnDateTime) {
		this.lastReturnDateTime = lastReturnDateTime;
	}
	public Integer getExetrSrvcTaskId() {
		return exetrSrvcTaskId;
	}
	public void setExetrSrvcTaskId(Integer exetrSrvcTaskId) {
		this.exetrSrvcTaskId = exetrSrvcTaskId;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public Timestamp getOfficerExecutedDate() {
		return officerExecutedDate;
	}
	public void setOfficerExecutedDate(Timestamp officerExecutedDate) {
		this.officerExecutedDate = officerExecutedDate;
	}
	public Timestamp getModificationDate() {
		return modificationDate;
	}
	public void setModificationDate(Timestamp modificationDate) {
		this.modificationDate = modificationDate;
	}
	public String getExecutedByManager() {
		return executedByManager;
	}
	public void setExecutedByManager(String executedByManager) {
		this.executedByManager = executedByManager;
	}
	public String getLastAssignedTo() {
		return lastAssignedTo;
	}
	public void setLastAssignedTo(String lastAssignedTo) {
		this.lastAssignedTo = lastAssignedTo;
	}
	public String getMsgUID() {
		return msgUID;
	}
	public void setMsgUID(String msgUID) {
		this.msgUID = msgUID;
	}
    
    
	
    
    
}
