package com.sbm.sama.portal.getBulkTasks.service.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.getBulkTasks.dao.GetBulkTasksDAO;
import com.sbm.sama.portal.getBulkTasks.dao.impl.GetBulkTasksDAOImpl;
import com.sbm.sama.portal.getBulkTasks.service.GetBulkTasksService;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetBulkTasksInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetBulkTasksOutputType;

public class GetBulkTasksServiceImpl implements GetBulkTasksService {

	private GetBulkTasksDAO bulktasksDao = new GetBulkTasksDAOImpl();
	@Override
	public List<GetBulkTasksOutputType> GetBulkTasks(
			GetBulkTasksInputType input, Connection conn)
			throws SQLException, DatatypeConfigurationException {
		// TODO Auto-generated method stub
		return bulktasksDao.GetBulkTasks(input, conn);
	}

}
