package com.sama.sbm.date;

import java.util.Calendar;

import com.ibm.broker.plugin.MbTimestamp;

public class DateUtil {

	public static MbTimestamp getCurrentTimestamp() {

//		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
//		System.out.println(timestamp);
		Calendar cal = Calendar.getInstance();
		  MbTimestamp mbTs = new MbTimestamp(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH),cal.get(Calendar.HOUR_OF_DAY)
				  , cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND),cal.get(Calendar.MILLISECOND));
		return mbTs;
		
	}
}
