package com.sbm.sama.watheeq.wsrr;


public class EndpointId {
	
	String serviceName;
	String serviceNamespace;
	String serviceVersion;
	String endpointType;
	String partnerId;


	
	
	public String getEndpointType() {
		return endpointType;
	}



	public void setEndpointType(String endpointType) {
		this.endpointType = endpointType;
	}



	public String getServiceName() {
		return serviceName;
	}



	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}



	public String getServiceNamespace() {
		return serviceNamespace;
	}



	public void setServiceNamespace(String serviceNamespace) {
		this.serviceNamespace = serviceNamespace;
	}



	public String getServiceVersion() {
		return serviceVersion;
	}



	public void setServiceVersion(String serviceVersion) {
		this.serviceVersion = serviceVersion;
	}



	public String getPartnerId() {
		return partnerId;
	}



	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}



	public EndpointId(String serviceName, String serviceNamespace, String serviceVersion,String endpointType, String partnerId) 
	{
		super();
		this.serviceName = serviceName;
		this.serviceNamespace = serviceNamespace;
		this.serviceVersion = serviceVersion;
		this.endpointType=endpointType;
		this.partnerId = partnerId;
	}
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((serviceName == null) ? 0 : serviceName.hashCode());
		result = prime * result + ((serviceNamespace == null) ? 0 : serviceNamespace.hashCode());
		result = prime * result + ((serviceVersion == null) ? 0 : serviceVersion.hashCode());
		result = prime * result + ((partnerId == null) ? 0 : partnerId.hashCode());
		result = prime * result + ((endpointType == null) ? 0 : endpointType.hashCode());
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EndpointId other = (EndpointId) obj;
		if (serviceName == null) {
			if (other.serviceName != null)
				return false;
		} else if (!serviceName.equals(other.serviceName))
			return false;
		if (serviceNamespace == null) {
			if (other.serviceNamespace != null)
				return false;
		} else if (!serviceNamespace.equals(other.serviceNamespace))
			return false;
		if (serviceVersion == null) {
			if (other.serviceVersion != null)
				return false;
		} else if (!serviceVersion.equals(other.serviceVersion))
			return false;
		if (partnerId == null) {
			if (other.partnerId != null)
				return false;
		} else if (!partnerId.equals(other.partnerId))
			return false;
		if (endpointType == null) {
			if (other.endpointType != null)
				return false;
		} else if (!endpointType.equals(other.endpointType))
			return false;
		
		return true;
	}
	
	
}