package com.sbm.sama.watheeq.lov;


public class LOVId {

	private String key;

	public LOVId(String key) {
		this.key = key;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LOVId other = (LOVId) obj;
		if (key == null) {
			if (other.key != null)
				return false;
		}
		return true;
	}
}
