package com.sbm.sama.watheeq.utils;

public class StringUtils {

	public static boolean isNullOrEmpty(String string) {
		return string == null || string.length() == 0;
	}

	public static String nullToEmpty(String string) {
		return (string == null) ? "" : string;
	}
}
