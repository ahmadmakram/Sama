package com.sbm.sama.watheeq.cache;

public interface ICacheManager {

	public void invalidateAll();
}
