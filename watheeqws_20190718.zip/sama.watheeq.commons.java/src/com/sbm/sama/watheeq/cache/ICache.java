package com.sbm.sama.watheeq.cache;

import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;

public interface ICache<K, V> {

	String FUNC_ID__CLEAR_ALL_CACHES 					= "9999";	// clear all caches
	String FUNC_ID__CLEAR_FLOW_PROPS_CURR_FLOW_CACHE 	= "9998"; 	// clear for current flow
	String FUNC_ID__CLEAR_FLOW_PROPS_ALL_FLOWS_CACHE 	= "1";//"9997";	// clear properties for all flows of EG
	String FUNC_ID__CLEAR_REF_DATA_ALL_SETS 			= "2";//9996";	// 
	
	V getIfPresent(Object key);
	
	V get(K key, Callable<? extends V> valueLoader) throws ExecutionException;
	
	void put(K key, V value);
	
	void putAll(Map<? extends K,? extends V> m);
	
	void invalidate(Object key);
	
	void invalidateAll(Iterable<?> keys);
	
	void invalidateAll();
	
	long size();
	
	ConcurrentMap<K, V> asMap();
	
	void cleanUp();
}
