package com.sbm.sama.watheeq.properties;

import java.util.List;
import java.util.concurrent.TimeUnit;

import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbJSON;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbNode;
import com.ibm.broker.plugin.MbXMLNSC;
import com.sbm.sama.watheeq.cache.CacheRegistry;
import com.sbm.sama.watheeq.cache.ICacheManager;
import com.sbm.sama.watheeq.cache.LocalLoadingCache;
import com.sbm.sama.watheeq.lov.LOVDetails;
import com.sbm.sama.watheeq.lov.LOVDetails.LOVInfo;
import com.sbm.sama.watheeq.lov.LOVId;
import com.sbm.sama.watheeq.lov.LovDataLoader;
import com.sbm.sama.watheeq.properties.FlowProperties.EndpointDetails;
import com.sbm.sama.watheeq.properties.FlowProperties.FlowService;
import com.sbm.sama.watheeq.wsrr.EndpointId;
import com.sbm.sama.watheeq.wsrr.EndpointValue;

public class PropertyManager implements ICacheManager {

	private static final int MAX_SIZE = 1000;
	private static final long CACHE_VALIDITY_PERIOD_IN_HOURS = 1;
	private static final long LOV_LONG_CACHE_VALIDITY_PERIOD_IN_HOURS = 1;
	private static final long LOV_SHORT_CACHE_VALIDITY_PERIOD_IN_HOURS = 1;
	private static final long ENDPOINTS_CACHE_VALIDITY_PERIOD_IN_HOURS = 1;
	private static final long LOVKEYS_CACHE_VALIDITY_PERIOD_IN_HOURS = 1;

	private final LocalLoadingCache<FlowId, FlowProperties> flowPropertiesCache;
	private final LocalLoadingCache<LOVId, LOVDetails> longLovCache;
	private final LocalLoadingCache<LOVId, LOVDetails> shortLovCache;
	private final LocalLoadingCache<EndpointId, EndpointValue> endPointsCache;
	private final LocalLoadingCache<LOVId, LOVDetails> lovKeysCache;

	public static String DEFAULT_JDBC_SERVICE = "JDBCPROVIDERS_ESB";

	private static PropertyManager INSTANCE;

	static {
		INSTANCE = new PropertyManager();
		CacheRegistry.getInstance().registerCache(INSTANCE);
	}

	public static PropertyManager getInstance() {
		// if (INSTANCE == null) {
		// synchronized (PropertyManager.class) {
		// if (INSTANCE == null) {
		// INSTANCE = new PropertyManager();
		// CacheRegistry.getInstance().registerCache(INSTANCE);
		// }
		// }
		// }

		return INSTANCE;
	}

	private PropertyManager() {
		flowPropertiesCache = new LocalLoadingCache<FlowId, FlowProperties>(MAX_SIZE, CACHE_VALIDITY_PERIOD_IN_HOURS,
				TimeUnit.HOURS);
		longLovCache = new LocalLoadingCache<>(MAX_SIZE, LOV_LONG_CACHE_VALIDITY_PERIOD_IN_HOURS, TimeUnit.HOURS);
		shortLovCache = new LocalLoadingCache<>(MAX_SIZE, LOV_SHORT_CACHE_VALIDITY_PERIOD_IN_HOURS, TimeUnit.HOURS);
		endPointsCache = new LocalLoadingCache<>(MAX_SIZE, ENDPOINTS_CACHE_VALIDITY_PERIOD_IN_HOURS, TimeUnit.HOURS);
		lovKeysCache = new LocalLoadingCache<>(MAX_SIZE, LOVKEYS_CACHE_VALIDITY_PERIOD_IN_HOURS, TimeUnit.HOURS);
	}

	public void readFlowProperties(MbNode mbNode, MbMessageAssembly assembly, FlowId flowId, boolean firstCallFlag) {

		try {

			if (firstCallFlag) {
				// invalidate related cache entry
				flowPropertiesCache.invalidate(flowId);
				longLovCache.invalidateAll();
				shortLovCache.invalidateAll();
				endPointsCache.invalidateAll();
				lovKeysCache.invalidateAll();

			}

			FlowProperties flowProperties = flowPropertiesCache.get(flowId, new FlowPropertiesLoader(mbNode, flowId));

			MbElement envVars = assembly.getGlobalEnvironment().getRootElement().getFirstElementByPath("Variables");

			MbElement flowPropertiesEl = envVars.getFirstElementByPath("FlowProperties");

			if (flowPropertiesEl == null) {
				flowPropertiesEl = envVars.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
				flowPropertiesEl.setName("FlowProperties");
			}

			MbElement flowDestinationsEl = envVars.getFirstElementByPath("FlowDestinations");
			if (flowDestinationsEl == null) {
				flowDestinationsEl = envVars.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
				flowDestinationsEl.setName("FlowDestinations");
			}

			copyMapToMbElement(flowPropertiesEl, flowDestinationsEl, flowProperties);

			if (flowProperties.loadLov.equals("1")) {
				LOVId lovId;
				LOVDetails lovDetails;
				lovId = new LOVId("lovKeys"); 
				LOVDetails lovDetParent = lovKeysCache.get(lovId, new LovDataLoader(mbNode, lovId));
				for (String longlovKey : lovDetParent.getLongTimeLov().keySet()) {
					System.out.println("key:" + longlovKey);
					lovId = new LOVId(longlovKey);
					lovDetails = longLovCache.get(lovId, new LovDataLoader(mbNode, lovId));
					copyLovMapToMbElement(envVars, lovDetails, lovDetParent.getLongTimeLov().get(longlovKey));
				}
				for (String shortlovKey : lovDetParent.getShortTimeLov().keySet()) {
					System.out.println("key:" + shortlovKey);
					lovId = new LOVId(shortlovKey);
					lovDetails = shortLovCache.get(lovId, new LovDataLoader(mbNode, lovId));
					copyLovMapToMbElement(envVars, lovDetails, lovDetParent.getShortTimeLov().get(shortlovKey));
				}

			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return;
	}
	
	
	public EndpointValue retrieveEndpoint(EndpointId id) 
	{
		return endPointsCache.getIfPresent(id);
	}
	
	public void putEndpoint(EndpointId id, EndpointValue value) 
	{	
		endPointsCache.put(id, value);
	}
	
	public LOVDetails retrieveShortLov(LOVId key)
	{
		return shortLovCache.getIfPresent(key);
	}

	public void invalidate(FlowId flowId) {
		this.flowPropertiesCache.invalidate(flowId);
	}

	@Override
	public void invalidateAll() {
		this.flowPropertiesCache.invalidateAll();
		this.longLovCache.invalidateAll();
		this.shortLovCache.invalidateAll();
		this.endPointsCache.invalidateAll();
		this.lovKeysCache.invalidateAll();
	}

	public void invalidateAll(String cacheType) {
		switch (cacheType) {
		case "0":
			invalidateAll();
			break;
		case "1":
			this.flowPropertiesCache.invalidateAll();
			break;
		case "2":
			this.longLovCache.invalidateAll();
			break;
		case "3":
			this.shortLovCache.invalidateAll();
			break;
		case "4":
			this.endPointsCache.invalidateAll();
			break;
		case "5":
			this.lovKeysCache.invalidateAll();
			break;
			
		}
	}

	private static void copyMapToMbElement(MbElement configRootElement, MbElement destinationRootElement,
			FlowProperties flowProperties) throws MbException {

		MbElement parentElement = configRootElement;

		parentElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "ApplName", flowProperties.flowId.applName);

		parentElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "FlowType", flowProperties.flowType);

		parentElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "EnableTransactionAudit",
				flowProperties.enableTransactionAudit);
		parentElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "flowNum",
				flowProperties.id);
		parentElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "loadLov",
				flowProperties.loadLov);


		for (FlowService dest : flowProperties.services) {

			MbElement destinationEl = destinationRootElement.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
			destinationEl.setName(dest.serviceName);

			MbElement serviceEndpointsEl = destinationEl.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
			serviceEndpointsEl.setName("ServiceEndpoints");

			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "DestinationId", dest.id);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "DestinationDesc", dest.serviceDesc);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "DestinationCode", dest.serviceCode);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "BindingType", dest.bindingType);

			for (String key : dest.routingData.keySet()) {
			      System.out.println("Key : " + key + " map size value : " + dest.routingData.get(key).keySet());
			      MbElement routingChannelEl = serviceEndpointsEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, key,
							null);
			     
			      
			      for (String k1 : dest.routingData.get(key).keySet()) {
			    	  System.out.println("Key : " + key + " List size value : " + dest.routingData.get(key).get(k1).size());
			    	  
			    	  List<EndpointDetails> RoutingDetails =dest.routingData.get(key).get(k1);
			    	  MbElement routingPlanEl = routingChannelEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "RoutingPlan",
								null);
//			    	  MbElement planOrderEl = routingPlanEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "CurrentRoutingOrder",
//								null);
			    	 int order=1;
			    	  for (EndpointDetails routingDetails : RoutingDetails) {
			    		  MbElement endpointDetailsEl = routingPlanEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "EndpointDetails",
									null);
			    		  endpointDetailsEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "EndPoint", routingDetails.endpoint);
			    		  endpointDetailsEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "EndPointType", routingDetails.endpointType);
			    		  endpointDetailsEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "MaxRetryCount", routingDetails.retryCount);
			    		  endpointDetailsEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "WaitTime", routingDetails.waitTime);
			    		  endpointDetailsEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "RoutingOrder", order);
			    		  endpointDetailsEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "IgnoreTransformation", routingDetails.ignoreTransformation);
			    		  order++;			    		  
					}
			    	  			    	  
			      }
			    }

			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Endpoint", dest.mqEndpoint);

			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "DestinationQmgr", dest.destinationQmgr);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "ReplyToEndpoint", dest.replyToEndpoint);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "ReplyToQmg", dest.replyToQmgr);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "CCSID", dest.ccsid);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Encoding", dest.encoding);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "MsgType", dest.msgType);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TrgtSystemId", dest.trgtSystemId);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TrgtDomainId", dest.trgtDomainId);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Priority", dest.priority);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Expiry", dest.expiry);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Persistence", dest.persistence);

			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "RetryEndpoint", dest.retryEndpoint);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "RetryQMGR", dest.retryQMGR);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "RetryWaitTime", dest.retryWaitTime);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "RetryCount", dest.retryCount);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "WSRRServiceName", dest.wsrrServiceName);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "WSRRServiceNamespace",
					dest.wsrrServiceNamespace);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "WSRRServiceVersion",
					dest.wsrrServiceVersion);
			destinationEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "FaultEndpoint", dest.faultEndpoint);

		}
	}

	private static void copyLovMapToMbElement(MbElement envVars, LOVDetails lovDetails, String lovEnvVar)
			throws MbException {

		MbElement lovDataEl = envVars.getFirstElementByPath("LOVData");
		if (lovDataEl == null) {
			lovDataEl = envVars.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
			lovDataEl.setName("LOVData");
		}

		MbElement lovSubEl = lovDataEl.getFirstElementByPath(lovEnvVar);
		if (lovSubEl == null) {
			lovSubEl = lovDataEl.createElementAsLastChild(MbJSON.ARRAY, lovEnvVar, null);
		}

		for (LOVInfo lovInfo : lovDetails.getLovInfoList()) {
			MbElement itemEl = lovSubEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "ITEM", null);
			itemEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "code", lovInfo.getLovCode());
			itemEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "descEn", lovInfo.getDescEn());
			itemEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "descAr", lovInfo.getDescAr());
			itemEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "lovCond1", lovInfo.getLovCond1());
			itemEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "lovCond2", lovInfo.getLovCond2());
			itemEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "attribute9", lovInfo.getAttribute9());

		}
	}

}
