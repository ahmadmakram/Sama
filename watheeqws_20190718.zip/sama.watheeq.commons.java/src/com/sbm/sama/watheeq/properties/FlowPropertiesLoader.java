package com.sbm.sama.watheeq.properties;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

import com.ibm.broker.plugin.MbNode;
import com.ibm.broker.plugin.MbNode.JDBC_TransactionType;
import com.sbm.sama.watheeq.properties.FlowProperties.EndpointDetails;
import com.sbm.sama.watheeq.properties.FlowProperties.FlowService;
import com.sbm.sama.watheeq.utils.StringUtils;

public class FlowPropertiesLoader implements Callable<FlowProperties> {

	MbNode mbNode;
	FlowId flowId;

	public FlowPropertiesLoader(MbNode mbNode, FlowId flowId) {
		super();
		this.mbNode = mbNode;
		this.flowId = flowId;
	}

	@Override
	public FlowProperties call() throws Exception {
		try {
			String jdbcService = (String) mbNode.getUserDefinedAttribute("JDBCSERVICE");

			if (StringUtils.isNullOrEmpty(jdbcService)) {
				jdbcService = PropertyManager.DEFAULT_JDBC_SERVICE;
			}

			// Obtain a java.sql.Connection using a JDBC Type4 datasource - in
			// this example for a
			// JDBC broker configurable service called "MyDB2"

			Connection conn = this.mbNode.getJDBCType4Connection(jdbcService, JDBC_TransactionType.MB_TRANSACTION_AUTO);
			FlowProperties flowProperties = new FlowProperties(this.flowId);

			loadProperties(conn, flowProperties);
			flowProperties.services = loadDestinations(conn, flowProperties);

			return flowProperties;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private void loadProperties(Connection conn, FlowProperties flowProperties) throws SQLException {
		String statement = "SELECT FPROP.*" + "  FROM FLOW_PROPERTIES FPROP" + " WHERE DOMAIN IN ('*',?) "
				+ "   AND NODE_NAME IN ('*',?) " + "   AND IS_NAME IN ('*',?) " + "   AND APPL_NAME IN ('*',?) "
				+ "   AND FLOW_NAME IN ('*',?) ";

		PreparedStatement ps = conn.prepareStatement(statement);

		ps.setString(1, flowId.domain);
		ps.setString(2, flowId.nodeName);
		ps.setString(3, flowId.egLabel);
		ps.setString(4, flowId.applName);
		ps.setString(5, flowId.flowName);

		ResultSet rs = ps.executeQuery();

		while (rs.next()) {

			flowProperties.id = rs.getString("ID");
			flowProperties.enableTransactionAudit = rs.getString("ENABLE_AUDIT").equals("NO") ? false : true;
			flowProperties.flowType = rs.getString("FLOW_TYPE");
			flowProperties.loadLov = rs.getString("LOAD_LOV");

		}
	}

	private List<FlowService> loadDestinations(Connection conn, FlowProperties flowProperties) throws SQLException {

		List<FlowService> destinations = new ArrayList<FlowService>();
		String statement = "SELECT DEST.*  FROM FLOW_SERVICES DEST WHERE FLOW_PROPERTIES_ID = ?";

		PreparedStatement ps = conn.prepareStatement(statement);

		ps.setString(1, flowProperties.id);

		ResultSet rs = ps.executeQuery();

		while (rs.next()) {
			FlowService dest = new FlowService();

			dest.id = rs.getString("ID");
			dest.serviceName = rs.getString("SERVICE_NAME");
			dest.serviceCode = rs.getString("SERVICE_CODE");
			dest.serviceDesc = rs.getString("SERVICE_DESC");
			dest.bindingType = rs.getString("BINDING_TYPE");
			dest.mqEndpoint = rs.getString("ENDPOINT");
			dest.routingData = loadServiceEndpoints(conn, dest);
			dest.destinationQmgr = rs.getString("DESTINATION_QMGR");
			dest.replyToEndpoint = rs.getString("REPLY_TO_ENDPOINT");
			dest.replyToQmgr = rs.getString("REPLY_TO_QMGR");
			dest.retryEndpoint = rs.getString("RETRY_ENDPOINT");
			dest.retryQMGR = rs.getString("RETRY_QMGR");
			dest.retryWaitTime = rs.getString("RETRY_WAITTIME");
			dest.retryCount = rs.getString("RETRY_COUNT");
			dest.trgtSystemId = rs.getString("TRGT_SYSTEM_ID");
			dest.trgtDomainId = rs.getString("TRGT_DOMAIN_ID");
			dest.ccsid = rs.getString("CCSID");
			dest.encoding = rs.getString("ENCODING");
			dest.msgType = rs.getString("MSG_TYPE");
			dest.persistence = rs.getString("PERSISTENCE");
			dest.expiry = rs.getString("EXPIRY");
			dest.priority = rs.getString("PRIORITY");
			dest.wsrrServiceName = rs.getString("WSRR_SERVICENAME");
			dest.wsrrServiceNamespace = rs.getString("WSRR_SERVICENAMESPACE");
			dest.wsrrServiceVersion = rs.getString("WSRR_SERVICVERSION");
			dest.faultEndpoint = rs.getString("FAULT_ENDPOINT");

			destinations.add(dest);
		}

		return destinations;
	}

	
	private Map<String, Map<String, List<EndpointDetails>>> loadServiceEndpoints(Connection conn, FlowService flowService)
			throws SQLException {

		Map<String, List<EndpointDetails>> routingPlansMap;
		Map<String, Map<String, List<EndpointDetails>>> routingChannelMap = new HashMap<String, Map<String, List<EndpointDetails>>>();

		String statement = "SELECT E.* FROM SERVICE_ENDPOINTS_ROUTING E WHERE FLOW_SERVICE_ID = ? and ENABLED='TRUE' ORDER BY PID,ROUTING_PLAN,ROUTING_FAILURE_ORDER";

		PreparedStatement ps = conn.prepareStatement(statement);

		ps.setString(1, flowService.id);

		ResultSet rs = ps.executeQuery();
		EndpointDetails endPoint;
		String channelMapKey, plansMapKey = null;
		while (rs.next()) {
			endPoint = new EndpointDetails();

			endPoint.id = rs.getString("ID");
			endPoint.flowServiceId = rs.getString("FLOW_SERVICE_ID");
			endPoint.pID = rs.getString("PID");
			endPoint.channel = rs.getString("CHANNEL");
			endPoint.routingPlan = rs.getString("ROUTING_PLAN");
			endPoint.endpoint = rs.getString("ENDPOINT");
			endPoint.endpointOrder = rs.getString("ROUTING_FAILURE_ORDER");
			endPoint.endpointType = rs.getString("ENDPOINT_TYPE");
			endPoint.waitTime = rs.getString("WAIT_TIME");
			endPoint.retryCount = rs.getString("RETRY_COUNT");
			endPoint.ignoreTransformation = rs.getString("IGNORE_TRANSFORMATION");
			channelMapKey = endPoint.pID + "_" + endPoint.channel;
			plansMapKey = endPoint.routingPlan;
			routingPlansMap=routingChannelMap.get(channelMapKey);
			if (routingPlansMap == null) {
				routingPlansMap=new HashMap<String, List<EndpointDetails>>();
			}
			routingPlansMap = addListToMap(plansMapKey, endPoint, routingPlansMap);
			routingChannelMap.put(channelMapKey, routingPlansMap);

		}

		return routingChannelMap;
	}

	
	public Map<String, List<EndpointDetails>> addListToMap(String key, EndpointDetails endPoint,
			Map<String, List<EndpointDetails>> map1) {
		List<EndpointDetails> values = map1.get(key);

		if (values == null) {
			values = new ArrayList<EndpointDetails>();
			map1.put(key, values);
		}

		values.add(endPoint);

		return map1;
	}

}
