

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class MailSender {

	public void sendEmail(String serverHost,String serverPort,String userName, String pass, String emailFrom, String emailTo, 
			 String emailCc,
			 String emailBcc,
			 String subject,
			 String htmlBody) {

		final String username = userName;
		final String password = pass;

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", serverHost);
		props.put("mail.smtp.port", serverPort);

		Session session = Session.getInstance(props,
		  new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		  });

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(emailFrom));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailTo));
			message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(emailCc));
			message.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(emailBcc));
			message.setSubject(subject);
			
			Multipart multiPart = new MimeMultipart();
			MimeBodyPart htmlPart = new MimeBodyPart();
			htmlPart.setContent(htmlBody, "text/html; charset=utf-8");
			multiPart.addBodyPart(htmlPart);
			
			message.setContent(multiPart);

			Transport.send(message);

		//	System.out.println("Done");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}

}
