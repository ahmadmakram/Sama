package com.sbm.sama.portal.getTask.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.tanfeeth.jaxb.common.GetTaskInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetTaskOutputType;



public interface TaskDao {
	public GetTaskOutputType GetTask(GetTaskInputType _input, Connection _conn) throws SQLException, DatatypeConfigurationException;

}
