package com.sbm.sama.portal.tanfeeth.common.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.sbm.sama.portal.tanfeeth.common.dao.CommonInquiryService;

public class CommonInquiryServiceImpl implements CommonInquiryService {

	@Override
	public int generateResponseIdCURRVAL(Connection conn, String subServiceName)throws SQLException{
		int id = 0;
		String sql = "";
		switch (subServiceName) {
			case "AcctsInfo":
				sql = "SELECT ACCOUNT_INFO_RESPONSE_ID.NEXTVAL FROM DUAL";
				break;
			case "BalsInfo":
				sql = "SELECT ACCOUNT_BAL_INFO_RESPONSE_ID.NEXTVAL FROM DUAL";
				break;
			case "DpstsInfo":
				sql = "SELECT DEPOSIT_INFO_RESPONSE_ID.NEXTVAL FROM DUAL";
				break;
			case "LblsInfo":
				sql = "SELECT LIABILITY_INFO_RESPONSE_ID.NEXTVAL FROM DUAL";
				break;
			case "SafeInfo":
				sql = "SELECT SAFE_INFO_RESPONSE_ID.NEXTVAL FROM DUAL";
				break;
			default :
					return 0;
		}
		PreparedStatement ps = conn.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		if (rs.next())
			id = rs.getInt(1);
		return id;
	}
}
