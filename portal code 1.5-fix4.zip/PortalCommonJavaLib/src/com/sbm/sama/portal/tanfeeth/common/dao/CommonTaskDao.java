package com.sbm.sama.portal.tanfeeth.common.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.sbm.sama.portal.tanfeeth.common.util.WorkflowTaskBean;


public interface CommonTaskDao {

	public void updateTask( Connection _conn,WorkflowTaskBean workflowTaskBean ) throws SQLException ;
	public WorkflowTaskBean selectTask( Connection _conn, int TaskId ) throws SQLException ;
	public String GetTaskCallBackStatus( Connection _conn, int TaskId) throws SQLException;
	
}
