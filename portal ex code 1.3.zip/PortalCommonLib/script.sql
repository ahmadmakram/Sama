ALTER TABLE BAN_DEALING_RESPONSE DROP COLUMN IS_DELETED;
ALTER TABLE DENY_DEALING_RESPONSE DROP COLUMN IS_DELETED;
ALTER TABLE BLOCK_RESPONSE DROP COLUMN EXE_DTTM;



   CREATE SEQUENCE  "FIPORTAL"."PRD_JNT_ACCTS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 ;

   CREATE SEQUENCE  "FIPORTAL"."BLOCK_RESPONSE_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 ;

   CREATE SEQUENCE  "FIPORTAL"."DENY_DEALING_RESPONSE_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 ;

   CREATE SEQUENCE  "FIPORTAL"."BAN_DEALING_RESPONSE_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 ;

   
--------------------------------------------------------
--  DDL for  PRD_JNT_ACCTS
--------------------------------------------------------


  CREATE TABLE "FIPORTAL"."PRD_JNT_ACCTS" 
   (	"PRD_JNT_ACCTS_ID" NUMBER DEFAULT "FIPORTAL"."PRD_JNT_ACCTS_SEQ"."NEXTVAL", 
	"PRD_ID" NUMBER, 
	"PRD_TYPE" VARCHAR2(20 CHAR), 
	"ACC_NUM" VARCHAR2(24 CHAR), 
	"IBAN" VARCHAR2(24 CHAR)
   );
  CREATE UNIQUE INDEX "FIPORTAL"."PRD_JNT_ACCTS_PK" ON "FIPORTAL"."PRD_JNT_ACCTS" ("PRD_JNT_ACCTS_ID") ;
 
  ALTER TABLE "FIPORTAL"."PRD_JNT_ACCTS" MODIFY ("PRD_ID" NOT NULL ENABLE);
  ALTER TABLE "FIPORTAL"."PRD_JNT_ACCTS" MODIFY ("PRD_TYPE" NOT NULL ENABLE);
  ALTER TABLE "FIPORTAL"."PRD_JNT_ACCTS" MODIFY ("ACC_NUM" NOT NULL ENABLE);
  ALTER TABLE "FIPORTAL"."PRD_JNT_ACCTS" MODIFY ("IBAN" NOT NULL ENABLE);
  ALTER TABLE "FIPORTAL"."PRD_JNT_ACCTS" ADD CONSTRAINT "PRD_JNT_ACCTS_PK" PRIMARY KEY ("PRD_JNT_ACCTS_ID");
  ALTER TABLE "FIPORTAL"."PRD_JNT_ACCTS" ADD (TASK_ID NUMBER NOT NULL);
  
  
  
  
  
  
  
  
  --------------------------------------------------------
--  DDL for Table BLOCK_RESPONSE
--------------------------------------------------------

  CREATE TABLE "FIPORTAL"."BLOCK_RESPONSE" 
   (	"ID" NUMBER(*,0), 
	"TASK_ID" NUMBER(*,0), 
	"CUST_NAME" VARCHAR2(100 BYTE), 
	"CUST_ID" VARCHAR2(20 BYTE), 
	"CUST_IDTYPE" VARCHAR2(10 BYTE), 
	"CUST_NTNLTY" VARCHAR2(3 BYTE), 
	"EXE_DTTM" TIMESTAMP (6), 
	"CREATED_DATE_TIME" TIMESTAMP (6), 
	"SMRY_INFO_PNDNG_AMT" NUMBER(*,0) DEFAULT 0, 
	"SMRY_INFO_TOT_AMT" NUMBER(*,0) DEFAULT 0
   ) ;
--------------------------------------------------------
--  DDL for Index BLOCK_RESPONSE_REQ_ID
--------------------------------------------------------

  CREATE INDEX "FIPORTAL"."BLOCK_RESPONSE_REQ_ID" ON "FIPORTAL"."BLOCK_RESPONSE" ("TASK_ID") ;
--------------------------------------------------------
--  DDL for Index BLOCK_RESPONSE_ID
--------------------------------------------------------

  CREATE UNIQUE INDEX "FIPORTAL"."BLOCK_RESPONSE_ID" ON "FIPORTAL"."BLOCK_RESPONSE" ("ID") ;
--------------------------------------------------------
--  Constraints for Table BLOCK_RESPONSE
--------------------------------------------------------

  ALTER TABLE "FIPORTAL"."BLOCK_RESPONSE" ADD CONSTRAINT "DENY_RESP_ID1" PRIMARY KEY ("ID");
  ALTER TABLE "FIPORTAL"."BLOCK_RESPONSE" MODIFY ("ID" NOT NULL ENABLE);
  
  
  
  
  
  
 --------------------------------------------------------
--  DDL for Table LIFT_RESPONSE
--------------------------------------------------------

  CREATE TABLE "FIPORTAL"."LIFT_RESPONSE" 
   (	"ID" NUMBER , 
	"TASK_ID" NUMBER, 
	"CUST_NAME" VARCHAR2(100 CHAR), 
	"CUST_ID" VARCHAR2(20 CHAR), 
	"CUST_ID_TYPE" VARCHAR2(10 CHAR), 
	"CUST_NAT_CD" VARCHAR2(3 CHAR), 
	"EXE_DATE_TIME" DATE, 
	"TOTAL_TRANS_AMT" FLOAT(126), 
	"TOTAL_BLOCK_AMT" FLOAT(126), 
	"PENDING_AMT" FLOAT(126),
	"CREATED_DATE_TIME" TIMESTAMP (6)   )  ;
--------------------------------------------------------
--  DDL for Index LIFT_EXEC_RESP_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FIPORTAL"."LIFT_RESPONSE_PK" ON "FIPORTAL"."LIFT_RESPONSE" ("ID") ;
--------------------------------------------------------
--  Constraints for Table LIFT_RESPONSE
--------------------------------------------------------

  ALTER TABLE "FIPORTAL"."LIFT_RESPONSE" MODIFY ("ID" NOT NULL ENABLE);
  ALTER TABLE "FIPORTAL"."LIFT_RESPONSE" MODIFY ("EXE_DATE_TIME" NOT NULL ENABLE);
  ALTER TABLE "FIPORTAL"."LIFT_RESPONSE" ADD CONSTRAINT "LIFT_RESPONSE_PK" PRIMARY KEY ("ID");
  







--------------------------------------------------------
--  DDL for Table GARNISH_RESPONSE
--------------------------------------------------------

  CREATE TABLE "FIPORTAL"."GARNISH_RESPONSE" 
   (	"ID" NUMBER ,
	"TASK_ID" NUMBER, 
	"CUST_NAME" VARCHAR2(100 CHAR), 
	"CUST_ID" VARCHAR2(20 CHAR), 
	"CUST_ID_TYPE" VARCHAR2(10 CHAR), 
	"CUST_NAT_CD" VARCHAR2(3 CHAR), 
	"EXE_DATE_TIME" DATE, 
	"TOTAL_AMT" FLOAT(126), 
	"PENDING_AMT" FLOAT(126),
	"CREATED_DATE_TIME" TIMESTAMP (6)   )  ;
--------------------------------------------------------
--  DDL for Index GARNISH_EXEC_RESP_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FIPORTAL"."GARNISH_RESPONSE_PK" ON "FIPORTAL"."GARNISH_RESPONSE"  ("ID")  ;
--------------------------------------------------------
--  Constraints for Table GARNISH_RESPONSE
--------------------------------------------------------

  ALTER TABLE "FIPORTAL"."GARNISH_RESPONSE" MODIFY ("TASK_ID" NOT NULL ENABLE);
  ALTER TABLE "FIPORTAL"."GARNISH_RESPONSE" MODIFY ("EXE_DATE_TIME" NOT NULL ENABLE);
  ALTER TABLE "FIPORTAL"."GARNISH_RESPONSE" ADD CONSTRAINT "GARNISH_RESPONSE_PK" PRIMARY KEY ("ID");

  