package com.sbm.sama.portal.tanfeeth.common.enums;

public enum SubServiceCode {
	_01 ("AcctsInfo"),
	_02 ("BalsInfo"),
	_03 ("DpstsInfo"),
	_05 ("LblsInfo"),
	_04  ("SafeInfo"),
	_06 ("SrvcCtrl"),
	_07 ("DenyExe"),
	_08 ("BanExe"),
	_09 ("LiftRestriction"),
	_10("BlockExe"),
	_11 ("GarnishExe"),
	_12 ("LiftDenyExe"),
	_13 ("LiftBanExe"),
	_14 ("LiftBlockExe"),
	_15 ("LiftGarnishExe");
	
	
	private String serviceName = null;
	
	SubServiceCode (String serviceName){
		this.serviceName = serviceName;
	}
	
	public String getServiceName(){
		return this.serviceName;
	}
}
