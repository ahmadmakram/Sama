package com.sbm.sama.portal.tanfeeth.common.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.sbm.sama.portal.tanfeeth.common.dao.CommonTaskDao;
import com.sbm.sama.portal.tanfeeth.common.util.WorkflowTaskBean;

public class CommonTaskDaoImpl implements CommonTaskDao {

	public void updateTask(Connection _conn, WorkflowTaskBean workflowTaskBean) throws SQLException {
	
		String _sql_task = "UPDATE FIPORTAL.WORKFLOW_TASK SET STATUS_ID=?,SUB_STATUS_ID=? , EXECUTED_BY  = ?,  NOTES = ? ,CALL_BACK_STATUS=? ,MANAGER_ACTION_DATE=? ,ASSIGNED_BY_ROLE=? ,ASSIGNED_BY=?,ASSIGNED_DATE_TIME=? ,ASSIGNED_TO=?,LAST_RETURN_DATE_TIME=?,EXECUTED_BY_MANAGER=?,OFFICER_EXECUTED_DATE=?, IS_BULK_PROCESSED=?,LAST_ASSIGNED_TO=? ,MODIFICATION_DATE=SYSDATE WHERE ID=?";

		PreparedStatement _pst = _conn.prepareStatement(_sql_task);
		_pst.setInt(1, workflowTaskBean.getStatusId());
		_pst.setInt(2, workflowTaskBean.getSubStatusId());

		_pst.setString(3, workflowTaskBean.getExecutedBy());
		_pst.setString(4, workflowTaskBean.getNotes());
		_pst.setString(5, workflowTaskBean.getStatusCode());
		_pst.setTimestamp(6, workflowTaskBean.getManagerActionTime());
		_pst.setString(7, workflowTaskBean.getAssignedByRole());
		_pst.setString(8, workflowTaskBean.getAssignedBy());
		_pst.setTimestamp(9, workflowTaskBean.getAssignedDateTime());

		_pst.setString(10, workflowTaskBean.getAssignedTo());
		_pst.setTimestamp(11, workflowTaskBean.getLastReturnDateTime());

		_pst.setString(12, workflowTaskBean.getExecutedByManager());
		_pst.setTimestamp(13, workflowTaskBean.getOfficerExecutedDate());
		_pst.setString(14, workflowTaskBean.getIsBulkProcessed());
		
		_pst.setString(15, workflowTaskBean.getLastAssignedTo());
		_pst.setInt(16, workflowTaskBean.getTaskId());
		_pst.executeUpdate();
	}

	public String GetTaskCallBackStatus(Connection _conn, int TaskId) throws SQLException {
		String _sql_callback_status = "SELECT call_back_status FROM workflow_task where  id =?";
		PreparedStatement _pstcbs = _conn.prepareStatement(_sql_callback_status);
		_pstcbs.setInt(1, TaskId);
		ResultSet _rstcbs = _pstcbs.executeQuery();
		if (_rstcbs.next())
			return _rstcbs.getString("CALL_BACK_STATUS");
		else
			return "";
	}

	@Override
	public WorkflowTaskBean selectTask(Connection _conn, int taskId) throws SQLException {
		String _sql_task_status = "SELECT  * FROM  FIPORTAL.WORKFLOW_TASK WHERE ID=?";
		PreparedStatement _ps = _conn.prepareStatement(_sql_task_status);
		_ps.setInt(1, taskId);
		ResultSet _rs = _ps.executeQuery();
		WorkflowTaskBean workflowTaskBean = new WorkflowTaskBean();
		if (_rs.next()) {

			workflowTaskBean.setTaskId(taskId);
			workflowTaskBean.setRequestId(_rs.getInt("REQUEST_METADATA_ID"));
			workflowTaskBean.setPid(_rs.getString("FI_ID"));
			workflowTaskBean.setAssignedDateTime(_rs.getTimestamp("ASSIGNED_DATE_TIME"));
			workflowTaskBean.setAssignedTo(_rs.getString("ASSIGNED_TO"));
			workflowTaskBean.setAssignedBy(_rs.getString("ASSIGNED_BY"));
			workflowTaskBean.setAssignedByRole(_rs.getString("ASSIGNED_BY_ROLE"));
			workflowTaskBean.setStatusId(_rs.getInt("STATUS_ID"));
			workflowTaskBean.setSubStatusId(_rs.getInt("SUB_STATUS_ID"));
			workflowTaskBean.setIsBulkProcessed(_rs.getString("IS_BULK_PROCESSED"));
			workflowTaskBean.setRequireChecker(_rs.getString("REQUIRE_CHECKER"));
			workflowTaskBean.setManagerActionTime(_rs.getTimestamp("MANAGER_ACTION_DATE"));
			workflowTaskBean.setExecutedBy(_rs.getString("EXECUTED_BY"));
			workflowTaskBean.setSlaMinutes(_rs.getInt("SLA_MINUTES"));
			workflowTaskBean.setLastReturnDateTime(_rs.getTimestamp("LAST_RETURN_DATE_TIME"));
			workflowTaskBean.setExetrSrvcTaskId(_rs.getInt("EXETR_SRVC_TASK_ID"));
			workflowTaskBean.setNotes(_rs.getString("NOTES"));
			workflowTaskBean.setStatusCode(_rs.getString("CALL_BACK_STATUS"));
			workflowTaskBean.setOfficerExecutedDate(_rs.getTimestamp("OFFICER_EXECUTED_DATE"));
			workflowTaskBean.setModificationDate(_rs.getTimestamp("MODIFICATION_DATE"));
			workflowTaskBean.setExecutedByManager(_rs.getString("EXECUTED_BY_MANAGER"));
			workflowTaskBean.setLastAssignedTo(_rs.getString("LAST_ASSIGNED_TO"));
			workflowTaskBean.setMsgUID(_rs.getString("MSGUID"));


		}

		return workflowTaskBean;
	}

	

}
