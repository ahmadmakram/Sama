package com.sbm.sama.fiportal.services.updatebulktasksstatus.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.sbm.sama.portal.tanfeeth.jaxb.common.UpdateWorkflowTaskReqType;


public interface UpdateBulkTasksStatusDAO {
	
	public String updateBulkTasksStatus(UpdateWorkflowTaskReqType _input, Connection _conn) throws SQLException;

}
