package com.sbm.sama.fiportal.services.updatebulktasksstatus.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.common.constant.WorkflowStatus;
import com.sbm.sama.portal.tanfeeth.common.dao.impl.CommonTaskDaoImpl;
import com.sbm.sama.portal.tanfeeth.common.enums.StatusCode;
import com.sbm.sama.portal.tanfeeth.common.enums.UpdateBulkBusinessRule;
import com.sbm.sama.portal.tanfeeth.common.util.MessageProcessor;
import com.sbm.sama.portal.tanfeeth.common.util.WorkflowTaskBean;
import com.sbm.sama.portal.tanfeeth.jaxb.common.UpdateWorkflowTaskReqType;

public class UpdateBulkTasksStatusDAOImpl implements UpdateBulkTasksStatusDAO {

	@Override
	public synchronized String updateBulkTasksStatus(UpdateWorkflowTaskReqType _input, Connection _conn)
			throws SQLException {
		String _output = StatusCode.FATAL_ERROR.getCode();
		CommonTaskDaoImpl ctdi = new CommonTaskDaoImpl();

		List<Integer> _task_id_list = _input.getTaskId();

		for (int i = 0; i < _task_id_list.size(); i++) {
			WorkflowTaskBean wfti = ctdi.selectTask(_conn, _input.getTaskId().get(i));

			Timestamp currentTime = new Timestamp(System.currentTimeMillis());

			String inputActions = _input.getExecutedByRoleId() + _input.getStatusId()
					+ _input.getSubStatusId() + wfti.getStatusId();

			if (!(inputActions.equalsIgnoreCase(UpdateBulkBusinessRule.MANAGER_OFFICER_INBOX.getValue())
					|| inputActions.equalsIgnoreCase(UpdateBulkBusinessRule.MANAGER_SUBMIT.getValue()) 
					|| inputActions.equalsIgnoreCase(UpdateBulkBusinessRule.OFFICER_MANAGER_Q.getValue())
				)) {
				_output = StatusCode.NOT_VALID_ACTION.getCode();
				return _output;
			}

			if (_input.getStatusId() == WorkflowStatus.MANAGER_SUBMIT) {
				wfti.setExecutedByManager(_input.getExecutedByUserId());
				wfti.setManagerActionTime(currentTime);
				wfti.setIsBulkProcessed("YES");
			} else if (_input.getStatusId() == WorkflowStatus.OFFICER_INBOX) {
				wfti.setExecutedByManager(_input.getExecutedByUserId());
				wfti.setAssignedBy(_input.getExecutedByUserId());
				wfti.setManagerActionTime(currentTime);
				wfti.setLastReturnDateTime(currentTime);
				wfti.setIsBulkProcessed("NO");
				wfti.setAssignedTo(wfti.getExecutedBy());
				wfti.setLastAssignedTo(wfti.getAssignedTo());
			} else if (_input.getStatusId() == WorkflowStatus.MANAGER_QUEUE) {
				if (!MessageProcessor.isValidSubmit(wfti, _input.getExecutedByUserId(), _input.getPID())) {
					return StatusCode.NOT_VALID_ACTION.getCode();
				}
				wfti.setIsBulkProcessed("YES");
				wfti.setOfficerExecutedDate(currentTime);
				wfti.setExecutedBy(_input.getExecutedByUserId());
				wfti.setLastAssignedTo(wfti.getAssignedTo());
				wfti.setAssignedTo(null);
				wfti.setStatusCode(StatusCode.NO_RELATION.getCode());
			}
			wfti.setTaskId(_input.getTaskId().get(i));
			wfti.setStatusId(_input.getStatusId());
			wfti.setSubStatusId(_input.getSubStatusId());
			wfti.setAssignedByRole(_input.getExecutedByRoleId());
			wfti.setNotes(_input.getNotes());

			ctdi.updateTask(_conn, wfti);
		}
		_output = StatusCode.SUCCESS.getCode();

		return _output;
	}
}
