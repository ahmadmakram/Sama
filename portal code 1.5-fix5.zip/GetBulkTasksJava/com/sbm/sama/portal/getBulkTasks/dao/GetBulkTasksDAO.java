package com.sbm.sama.portal.getBulkTasks.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.tanfeeth.jaxb.common.GetBulkTasksInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetBulkTasksOutputType;

public interface GetBulkTasksDAO {
	public List<GetBulkTasksOutputType> GetBulkTasks(GetBulkTasksInputType _input, Connection _conn) throws SQLException, DatatypeConfigurationException;
}
