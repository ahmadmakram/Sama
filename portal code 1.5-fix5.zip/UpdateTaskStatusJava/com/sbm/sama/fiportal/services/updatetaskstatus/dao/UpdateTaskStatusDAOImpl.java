package com.sbm.sama.fiportal.services.updatetaskstatus.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.common.constant.WorkflowStatus;
import com.sbm.sama.portal.tanfeeth.common.dao.impl.CommonTaskDaoImpl;
import com.sbm.sama.portal.tanfeeth.common.enums.StatusCode;
import com.sbm.sama.portal.tanfeeth.common.enums.UpdateTaskBusinessRule;
import com.sbm.sama.portal.tanfeeth.common.util.MessageProcessor;
import com.sbm.sama.portal.tanfeeth.common.util.WorkflowTaskBean;
import com.sbm.sama.portal.tanfeeth.jaxb.common.UpdateWorkflowTaskReqType;

public class UpdateTaskStatusDAOImpl implements UpdateTaskStatusDAO {

	@Override
	public String updateTaskStatus(UpdateWorkflowTaskReqType _input, Connection _conn) throws SQLException {
		String _output = StatusCode.FATAL_ERROR.getCode();

		CommonTaskDaoImpl ctdi = new CommonTaskDaoImpl();
		List<Integer> taskIdList = _input.getTaskId();
		for (int i = 0; i < taskIdList.size(); i++) {
			WorkflowTaskBean wfti = ctdi.selectTask(_conn, _input.getTaskId().get(i));

			String inputAction = _input.getExecutedByRoleId() + _input.getStatusId()
					+ _input.getSubStatusId() + wfti.getStatusId();

			if (!(inputAction.equalsIgnoreCase(UpdateTaskBusinessRule.MANAGER_OFFICER_INBOX.getValue())
				 || inputAction.equalsIgnoreCase(UpdateTaskBusinessRule.MANAGER_OFFICER_Q.getValue())
				 || inputAction.equalsIgnoreCase(UpdateTaskBusinessRule.MANAGER_SUBMIT.getValue())
				)) {
				_output = StatusCode.NOT_VALID_ACTION.getCode();
				return _output;
			}

			if (!MessageProcessor.isValidUpdate(wfti, _input.getExecutedByUserId(), _input.getPID())) {
				return StatusCode.NOT_VALID_ACTION.getCode();
			}

			Timestamp currentTime = new Timestamp(System.currentTimeMillis());

			if (_input.getStatusId() == WorkflowStatus.OFFICER_INBOX) {
				wfti.setLastAssignedTo(wfti.getAssignedTo());
				wfti.setAssignedTo(wfti.getExecutedBy());
				wfti.setLastReturnDateTime(currentTime);
			} else if (_input.getStatusId() == WorkflowStatus.OFFICER_QUEUE) {
				wfti.setLastAssignedTo(wfti.getAssignedTo());
				wfti.setAssignedTo(null);
				wfti.setLastReturnDateTime(currentTime);
			}
			wfti.setManagerActionTime(currentTime);
			wfti.setExecutedByManager(_input.getExecutedByUserId());
			wfti.setStatusId(_input.getStatusId());
			wfti.setSubStatusId(_input.getSubStatusId());
			wfti.setAssignedByRole(_input.getExecutedByRoleId());
			wfti.setNotes(_input.getNotes());

			ctdi.updateTask(_conn, wfti);
		}

		_output = StatusCode.SUCCESS.getCode();

		return _output;
	}
}
