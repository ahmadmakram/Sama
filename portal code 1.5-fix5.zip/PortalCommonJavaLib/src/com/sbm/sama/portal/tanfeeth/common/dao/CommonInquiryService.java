package com.sbm.sama.portal.tanfeeth.common.dao;

import java.sql.Connection;
import java.sql.SQLException;

public interface CommonInquiryService {
	public int generateResponseIdCURRVAL(Connection conn, String subServiceName) throws SQLException;

}
