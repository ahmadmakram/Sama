package com.sbm.sama.portal.tanfeeth.common.fieldsHandler;

public class ReqMetaPublicHandler {

}
