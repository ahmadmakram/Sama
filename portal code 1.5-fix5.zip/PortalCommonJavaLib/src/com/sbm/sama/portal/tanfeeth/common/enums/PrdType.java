package com.sbm.sama.portal.tanfeeth.common.enums;

public enum PrdType {
	 ACCOUNT,
	 BALANCE,
	 DEPOSIT,
	 LIABILITY,
	 SAFE,
	 BLOCK
}
