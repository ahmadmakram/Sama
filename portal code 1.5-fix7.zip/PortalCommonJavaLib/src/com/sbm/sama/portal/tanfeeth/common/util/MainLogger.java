package com.sbm.sama.portal.tanfeeth.common.util;

import java.io.InputStream;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class MainLogger {
	
public static void logData(String fileName , String data) {
	
	Logger logger = Logger.getLogger("MyLog");  
    FileHandler fh;  
    
    try {
    	
    	Properties prop = new Properties();
        ClassLoader loader = Thread.currentThread().getContextClassLoader();           
        InputStream stream = loader.getResourceAsStream("config.properties");
        prop.load(stream);
        
    	String newPath = prop.getProperty("LOG_DIR")+"/" + fileName+".log";
    	
		fh = new FileHandler(newPath,true);
		logger.addHandler(fh);
	    logger.setLevel(Level.INFO);
		
        SimpleFormatter formatter = new SimpleFormatter();  
        fh.setFormatter(formatter); 
        
        logger.log(Level.INFO,data); 
        fh.close();
} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}  
	
}



}
