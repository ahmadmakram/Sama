package com.sbm.sama.portal.tanfeeth.common.util;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class FieldsProcessing {
	public static boolean validateFilterString(String _input) {
		boolean _isValid = false;
		
		if (_input != null && _input.trim().length() > 0) _isValid = true;
		
		return _isValid;
	}
	
	public static XMLGregorianCalendar getXMLGregCal(Timestamp _ts) throws DatatypeConfigurationException {
		XMLGregorianCalendar _xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar();
		if (_ts != null) {
			GregorianCalendar _gcal = new GregorianCalendar();
			_gcal.setTimeZone(TimeZone.getTimeZone("GMT+03:00"));
			_gcal.setTimeInMillis(_ts.getTime());
			_xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(_gcal);
		} else {
			_xgcal = null;
		}
		return _xgcal;
	}
	
	
	public static Timestamp getTimestamp(XMLGregorianCalendar _xmlgcal) {
		Timestamp _ts = null;
		if (_xmlgcal != null) {
			GregorianCalendar _gcal = _xmlgcal.toGregorianCalendar();
			_ts = new Timestamp(_gcal.getTimeInMillis());
		}
		return _ts;
	}
	
	public static XMLGregorianCalendar getXMLGregCal(Date _d) throws DatatypeConfigurationException {
		 XMLGregorianCalendar _xgcal=null;
		 if (_d != null) {
		 GregorianCalendar c = new GregorianCalendar();
		 c.setTime(_d);
		  _xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		 }
		 return _xgcal;
	}
	

	 


	public static Date getShortTimestamp(String _xmlgcal) {
		Date sqlDate = null;
		if (_xmlgcal != null) {
		    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		    try {
		    	java.util.Date parsedDate =  dateFormat.parse(_xmlgcal);
		    	 sqlDate =  new Date(parsedDate.getTime());
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return sqlDate;
	}
	
	public static Timestamp getTimestamp(String _xmlgcal) {
		Timestamp _ts = null;
		if (_xmlgcal != null) {
		    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
		    try {
				Date parsedDate = (Date) dateFormat.parse(_xmlgcal);
				_ts = new java.sql.Timestamp(parsedDate.getTime());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return _ts;
	}
}
