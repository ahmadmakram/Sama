package com.sbm.sama.portal.getAllTasks.service.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.getAllTasks.dao.AllTasksDAO;
import com.sbm.sama.portal.getAllTasks.dao.impl.AllTasksDAOImpl;
import com.sbm.sama.portal.getAllTasks.service.AllTasksService;
import com.sbm.sama.portal.tanfeeth.jaxb.getAllTasks.GetAllTasksInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.getAllTasks.GetAllTasksOutputType;

public class AllTaskServiceImpl implements AllTasksService {

	private AllTasksDAO allTaskDao = new AllTasksDAOImpl();

	@Override
	public int getAllTasksTotalCount(GetAllTasksInputType input, Connection conn)
			throws SQLException {
		return allTaskDao.getAllTasksTotalCount(input, conn);
	}

	@Override
	public List<GetAllTasksOutputType> getAllTasks(GetAllTasksInputType _input,
			Connection _conn) throws SQLException,
			DatatypeConfigurationException {
		return allTaskDao.getAllTasks(_input, _conn);
	}

}
