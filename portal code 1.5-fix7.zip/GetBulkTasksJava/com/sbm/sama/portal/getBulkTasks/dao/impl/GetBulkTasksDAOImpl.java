package com.sbm.sama.portal.getBulkTasks.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.getBulkTasks.dao.GetBulkTasksDAO;
import com.sbm.sama.portal.tanfeeth.common.constant.WorkflowStatus;
import com.sbm.sama.portal.tanfeeth.common.util.FieldsProcessing;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetBulkTasksInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetBulkTasksOutputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.InvolvedEntityType;

public class GetBulkTasksDAOImpl implements GetBulkTasksDAO {

	private List<Object> queryParams;

	@Override
	public List<GetBulkTasksOutputType> GetBulkTasks(GetBulkTasksInputType _input, Connection _conn)
			throws SQLException, DatatypeConfigurationException {
		int _filter_index = 0;
		String _sort_dir = " ASC";
		if (_input.isSortDesc() != null) {
			if (_input.isSortDesc())
				_sort_dir = " DESC";
		}

		String _sql = "select * from TASK_BULK_VIEW ";
		_sql += BuildSQLFilter(_input) + getOrderby(_input) + _sort_dir;

		List<GetBulkTasksOutputType> _output = new ArrayList<GetBulkTasksOutputType>();
		PreparedStatement _ps = _conn.prepareStatement(_sql);
		for (Object queryParam : queryParams) {
			_ps.setObject(++_filter_index, queryParam);
		}

		ResultSet _rs = _ps.executeQuery();

		while (_rs.next()) {
			GetBulkTasksOutputType _item = new GetBulkTasksOutputType();
			_item.setTaskId(_rs.getInt("ID"));
			_item.setSRN(_rs.getString("SRN"));
			_item.setSubServiceCode(_rs.getString("SUB_SERVICE_TYPE_NAME"));

			InvolvedEntityType _involved = new InvolvedEntityType();
			_involved.setName(_rs.getString("INVOLVED_ENTITY_NAME"));
			_involved.setIdNo(_rs.getString("ID_NO"));
			_involved.setIdType(_rs.getString("ID_TYPE"));

			_item.setInvolvedEntityList(_involved);
			_item.setGovEntityName(_rs.getString("ENTITY_GOV_NAME"));

			_output.add(_item);

		}
		_rs.close();
		_ps.close();

		return _output;
	}

	// private int getSLARemainingMinutes(Timestamp _due_ts) {
	// int _min = 0;
	// if (_due_ts != null) {
	// Date _now = new Date();
	// _min = (int) (_due_ts.getTime() - _now.getTime());
	// _min = _min / 1000 / 60;
	// }
	//
	// return _min;
	// }

	private String BuildSQLFilter(GetBulkTasksInputType _input) {

		String _output = "";
		queryParams = new ArrayList<>();
		boolean _isFirstFilter = true;

		if (FieldsProcessing.validateFilterString(_input.getSubServiceCode())) {
			String[] _service_codes = _input.getSubServiceCode().split(",");
			_output += (_isFirstFilter ? " WHERE" : " AND") + " bus_srvc_cd IN (";
			for (int i = 0; i < _service_codes.length; i++) {
				_output += (i == 0 ? "'" : ",'") + _service_codes[i] + "'";
			}
			_output += ")";
			_isFirstFilter = false;
		}
		if (_input.getGovEntityId() != null) {
			_output += (_isFirstFilter ? " WHERE " : " AND") + " reqstr_cd =?";
			queryParams.add(_input.getGovEntityId());
			_isFirstFilter = false;
		}
		if (_input.getFiCode() != null) {
			_output += (_isFirstFilter ? " WHERE " : " AND") + " FI_ID=?";
			queryParams.add(_input.getFiCode());
			_isFirstFilter = false;
		}
		if (_input.getRequestReceiveDateTime() != null) {
			_output += (_isFirstFilter ? " WHERE " : " AND") + " TO_CHAR(created_date_time,'YYYY-MON-DD')=?";
			queryParams.add(FieldsProcessing.getTimestamp(_input.getRequestReceiveDateTime()));
			_isFirstFilter = false;
		}
		if (_input.getFiStartDate() != null) {
			_output += (_isFirstFilter ? " WHERE " : " AND") + " created_date_time>=?";
			queryParams.add(FieldsProcessing.getTimestamp(_input.getFiStartDate()));
			_isFirstFilter = false;
		}
		if (_input.getFiEndDate() != null) {
			_output += (_isFirstFilter ? " WHERE " : " AND") + " created_date_time<=?";
			queryParams.add(FieldsProcessing.getTimestamp(_input.getFiEndDate()));
			_isFirstFilter = false;
		}
		if (FieldsProcessing.validateFilterString(_input.getRequestId())) {
			_output += (_isFirstFilter ? " WHERE " : " AND") + " REQUEST_METADATA_ID=?";
			queryParams.add(_input.getRequestId());
			_isFirstFilter = false;
		}
		if (_input.getTaskStatusId() != null) {
			_output += (_isFirstFilter ? " WHERE " : " AND") + " STATUS_ID=?";
			queryParams.add(_input.getTaskStatusId());
			_isFirstFilter = false;
		}
		if (_input.getTaskSubStatusId() != null) {
			_output += (_isFirstFilter ? " WHERE " : " AND") + " SUB_STATUS_ID=?";
			queryParams.add(_input.getTaskSubStatusId());

			_isFirstFilter = false;
		}

		if (FieldsProcessing.validateFilterString(_input.getAssignedTo())) {
			_output += (_isFirstFilter ? " WHERE " : " AND") + " ASSIGNED_TO=?";
			queryParams.add(_input.getAssignedTo());
			_isFirstFilter = false;
		}
		if (FieldsProcessing.validateFilterString(_input.getAssignedBy())) {
			_output += (_isFirstFilter ? " WHERE " : " AND") + " ASSIGNED_BY=?";
			queryParams.add(_input.getAssignedBy());

			_isFirstFilter = false;
		}
		if (_input.getDueDateTime() != null) {
			_output += (_isFirstFilter ? " WHERE " : " AND") + " DUE_DATE_TIME=?";
			queryParams.add(FieldsProcessing.getTimestamp(_input.getDueDateTime()));

			_isFirstFilter = false;
		}
		if (_input.isIsBulkProcessed() != null) {
			_output += (_isFirstFilter ? " WHERE " : " AND") + " IS_BULK_PROCESSED=?";
			if (_input.isIsBulkProcessed()) {
				queryParams.add("YES");
			} else {
				queryParams.add("NO");
			}
			_isFirstFilter = false;
		}
		if (FieldsProcessing.validateFilterString(_input.getSRN())) {
			_output += (_isFirstFilter ? " WHERE " : " AND") + " SRN=?";
			queryParams.add(_input.getSRN());
			_isFirstFilter = false;
		}
		if (_input.getTaskHistoryStatusId() != null) {

			if (_input.getTaskHistoryStatusId() == WorkflowStatus.MANAGER_SUBMIT) {
				_output += (_isFirstFilter ? " WHERE " : " AND") + " (STATUS_ID >= ? OR SUB_STATUS_ID = "
						+ WorkflowStatus.OFFICER_SUBMIT + " )";
			} else {
				_output += (_isFirstFilter ? " WHERE " : " AND") + " STATUS_ID >= ?";
			}
			queryParams.add(_input.getTaskHistoryStatusId());
			_isFirstFilter = false;
		}

		if (FieldsProcessing.validateFilterString(_input.getExecutedBy())) {
			if (_input.getTaskHistoryStatusId() != null) {
				if (_input.getTaskHistoryStatusId() == WorkflowStatus.MANAGER_SUBMIT)
					_output += (_isFirstFilter ? "WHERE" : " AND") + " EXECUTED_BY_MANAGER = ? ";
				else
					_output += (_isFirstFilter ? "WHERE" : " AND") + " EXECUTED_BY = ? ";
			} else
				_output += (_isFirstFilter ? "WHERE" : " AND") + " EXECUTED_BY = ? ";
			queryParams.add(_input.getExecutedBy());
			_isFirstFilter = false;
		}
		if (FieldsProcessing.validateFilterString(_input.getInvolvedEntityIdNo())) {
			_output += (_isFirstFilter ? " WHERE " : " AND")
					+ " REQUEST_METADATA_ID IN (select AGCY_SRVC_REQST_ID from TANFEETH.INVOLVED_PARTY where id_no = ?)";
			queryParams.add(_input.getInvolvedEntityIdNo());
			_isFirstFilter = false;
		}
		if (FieldsProcessing.validateFilterString(_input.getInvolvedEntityIdType())) {
			_output += (_isFirstFilter ? " WHERE " : " AND")
					+ " REQUEST_METADATA_ID IN (select AGCY_SRVC_REQST_ID from TANFEETH.INVOLVED_PARTY where id_type_cd = ?)";
			queryParams.add(_input.getInvolvedEntityIdType());
			_isFirstFilter = false;
		}
		return _output;

	}

	private String getOrderby(GetBulkTasksInputType _input) {
		String _out = " ORDER BY CREATED_DATE_TIME";
		if (_input.getOrderBy() != null) {
			if (_input.getOrderBy().equalsIgnoreCase("request_id"))
				_out = " ORDER BY REQUEST_METADATA_ID";
			else if (_input.getOrderBy().equalsIgnoreCase("task_id"))
				_out = " ORDER BY TASK_ID";
			else if (_input.getOrderBy().equalsIgnoreCase("status_id"))
				_out = " ORDER BY STATUS_ID";
			else if (_input.getOrderBy().equalsIgnoreCase("main_service_code"))
				_out = " ORDER BY MAIN_SERVICE_TYPE_CODE";
			else if (_input.getOrderBy().equalsIgnoreCase("sub_service_code"))
				_out = " ORDER BY BUS_SRVC_CD";
			else if (_input.getOrderBy().equalsIgnoreCase("main_service_type_name"))
				_out = " ORDER BY MAIN_SERVICE_TYPE_NAME";
			else if (_input.getOrderBy().equalsIgnoreCase("sub_service_type_name"))
				_out = " ORDER BY SUB_SERVICE_TYPE_NAME";
			else if (_input.getOrderBy().equalsIgnoreCase("assigned_to"))
				_out = " ORDER BY ASSIGNED_TO";
			else if (_input.getOrderBy().equalsIgnoreCase("assigned_by"))
				_out = " ORDER BY ASSIGNED_BY";
			else if (_input.getOrderBy().equalsIgnoreCase("is_bulk_processed"))
				_out = " ORDER BY IS_BULK_PROCESSED";
			else if (_input.getOrderBy().equalsIgnoreCase("request_receive_date_time"))
				_out = " ORDER BY CREATED_DATE_TIME";
			else if (_input.getOrderBy().equalsIgnoreCase("last_executed_by_Status3"))
				_out = " ORDER BY EXECUTED_BY";
			else if (_input.getOrderBy().equalsIgnoreCase("last_executed_by_Status6"))
				_out = " ORDER BY EXECUTED_BY_MANAGER";
		}
		return _out;
	}

}
