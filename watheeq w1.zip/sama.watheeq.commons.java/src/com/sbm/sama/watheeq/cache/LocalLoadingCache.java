package com.sbm.sama.watheeq.cache;

import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

public class LocalLoadingCache<K, V> implements ICache<K, V> {

	private LoadingCache<K, V> cache;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public LocalLoadingCache(Integer maximumSize, Long duration, TimeUnit unit) {
		super();
		
		CacheBuilder builder = CacheBuilder.newBuilder();
		
		if (maximumSize != null) {
			builder.maximumSize(maximumSize);
		}
		
		if (duration != null) { 
			builder.expireAfterWrite(duration, unit);
		}
		
		this.cache = builder.build(
			new CacheLoader<K, V>() {
				@Override
				public V load(K key) throws Exception {
					return createRandom();
				}
			});
	}
	
	private V createRandom() {
		return null;
	}
	
	@Override
	public V getIfPresent(Object key) {
		return cache.getIfPresent(key);
	}

	@Override
	public synchronized V get(K key, Callable<? extends V> valueLoader)
			throws ExecutionException {
		return cache.get(key, valueLoader);
	}

	@Override
	public void put(K key, V value) {
		cache.put(key, value);
	}

	@Override
	public void putAll(Map<? extends K, ? extends V> m) {
		cache.putAll(m);
	}

	@Override
	public void invalidate(Object key) {
		cache.invalidate(key);
	}

	@Override
	public void invalidateAll(Iterable<?> keys) {
		cache.invalidateAll(keys);
	}

	@Override
	public void invalidateAll() {
		cache.invalidateAll();
	}

	@Override
	public long size() {
		return cache.size();
	}

	@Override
	public ConcurrentMap<K, V> asMap() {
		return cache.asMap();
	}

	@Override
	public void cleanUp() {
		cache.cleanUp();
	}

}
