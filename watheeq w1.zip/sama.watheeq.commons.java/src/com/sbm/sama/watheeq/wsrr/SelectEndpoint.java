package com.sbm.sama.watheeq.wsrr;

import java.util.List;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.sbm.sama.watheeq.lov.LOVDetails;
import com.sbm.sama.watheeq.lov.LOVDetails.LOVInfo;
import com.sbm.sama.watheeq.lov.LOVId;
import com.sbm.sama.watheeq.properties.PropertyManager;

public class SelectEndpoint extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal outTerminal = null;
		MbMessage environment = new MbMessage(inAssembly.getLocalEnvironment());
		MbElement environmentRoot = environment.getRootElement();
		MbMessageAssembly outAssembly = null;

		// final String SVC_ENVIRONMENT_VAR = "SvcEnvironment";
		// final String PID_VAR = "PID";

		try {
			// String svcName = getLocalEnvVar(SVC_NAME_VAR, inAssembly);
			// String svcNamespace =
			// MessageUtils.getLocalEnvVar(Constants.SVC_NAMESPACE_VAR,
			// inAssembly);
			// String svcClassification = getLocalEnvVar(SVC_CLASSIFICATION_VAR,
			// inAssembly);
			// String svcEnvironment= getLocalEnvVar(SVC_ENVIRONMENT_VAR,
			// inAssembly);
			String svcEnvironment = "Development";
			// String pid = getPartnerIdValue("PID", inAssembly);
			String pid = (String) inAssembly.getGlobalEnvironment().getRootElement()
					.getFirstElementByPath("Variables/MsgHdrRq/PID").getValue();
			// check for endpoint from available SLA on all SLDs for selected
			// partner
			// get soapaddress location from
			// environmentRoot.evaluateXPath("ServiceRegistry/Entity/userDefinedRelationships[@name='gep63_availableEndpoints']/targetEntities/Entity/userDefinedRelationships[@name='sm63_soapAddress']/targetEntities/Entity/userDefinedProperties[@name='sm63_soapLocation']/@value");
			@SuppressWarnings("unchecked")
			List<MbElement> endpoints = (java.util.List<MbElement>) environmentRoot
					.evaluateXPath("ServiceRegistry/Entity/userDefinedRelationships[@name='gep63_availableEndpoints']/targetEntities/Entity");
			MbElement portalEndpoint = null;
			MbElement generalEndpoint = null; // if no specific partnerId
												// endpoint

			for (int i = 0; i < endpoints.size(); i++) {
				MbElement endpoint = endpoints.get(i);
				if (isOnline(endpoint) && isEnvironment(endpoint, svcEnvironment)) {
					if (isGeneralEndpoint(endpoint)) {
						generalEndpoint = endpoint;
					} else if (isPortalEndpoint(endpoint)) {
						portalEndpoint = endpoint;
					}
				}
			}

			String destName = (String) inAssembly.getGlobalEnvironment().getRootElement()
					.getFirstElementByPath("Variables/DestinationName").getValue();
			String wsrrServiceName = (String) inAssembly.getGlobalEnvironment().getRootElement()
					.getFirstElementByPath("Variables/FlowDestinations/" + destName + "/WSRRServiceName").getValue();
			String wsrrServiceNamespace = (String) inAssembly.getGlobalEnvironment().getRootElement()
					.getFirstElementByPath("Variables/FlowDestinations/" + destName + "/WSRRServiceNamespace")
					.getValue();
			String wsrrServiceVersion = (String) inAssembly.getGlobalEnvironment().getRootElement()
					.getFirstElementByPath("Variables/FlowDestinations/" + destName + "/WSRRServiceVersion").getValue();
			String endPointType;
			MbElement endPointTypeElement = inAssembly.getGlobalEnvironment().getRootElement()
					.getFirstElementByPath("Variables/Retry/MQRFH2/usr/EndPointType");
			if (endPointTypeElement != null)
				endPointType = (String) endPointTypeElement.getValue();
			else
				endPointType = "proxy";

			loadEndpointsCache(portalEndpoint, generalEndpoint, wsrrServiceName, wsrrServiceNamespace,
					wsrrServiceVersion, endPointType);

			EndpointId id = new EndpointId(wsrrServiceName, wsrrServiceNamespace, wsrrServiceVersion, endPointType, pid);
			EndpointValue value = PropertyManager.getInstance().retrieveEndpoint(id);

			// get address from endpoint with classification from env
			if (value.getAddressUrl() != null && !value.getAddressUrl().isEmpty() && !value.getAddressUrl().equals("-")) {
				/*
				 * We need to forward the message on to a SOAPRequest,
				 * SOAPAsynRequest or HTTPRequest node. In order to do this, we
				 * need to include the url of the selected endpoint in the
				 * following locations:
				 * 
				 * LocalEnvironment.Destination.SOAP.Request.Transport.HTTP.
				 * WebServiceURL LocalEnvironment.Destination.HTTP.RequestURL
				 * 
				 * We use the additional XPath functions defined by IIB so that
				 * we can set these location values in single method calls.
				 */
				environmentRoot.evaluateXPath("?Destination/?SOAP/?Request/?Transport/?HTTP/?WebServiceURL[set-value('"
						+ value.getAddressUrl() + "')]");
				environmentRoot.evaluateXPath("?Destination/?HTTP/?RequestURL[set-value('" + value.getAddressUrl()
						+ "')]");

				// Create the message assembly to return
				outAssembly = new MbMessageAssembly(inAssembly, environment, inAssembly.getExceptionList(),
						inAssembly.getMessage());
				outTerminal = getOutputTerminal("out");
			} else {
				// create SoapFault
				// outAssembly = MessageUtils.createSOAPFault(inAssembly,
				// "NoAddress", "No " + svcClassification +
				// " endpoint with env " + svcEnvironment + " for " + svcName +
				// (pid == null || pid.isEmpty() ? "" : (" and partner " + pid))
				// + "in registry", "Endpoint not found");
				outAssembly = new MbMessageAssembly(inAssembly, environment, inAssembly.getExceptionList(),
						inAssembly.getMessage());
				outTerminal = getOutputTerminal("alternate");
			}
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be
			// handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(), null);
		}

		outTerminal.propagate(outAssembly);
	}

	protected static final String OWL_URL_ENDPOINT_ONLINE = "http://www.ibm.com/xmlns/prod/serviceregistry/lifecycle/v6r3/LifecycleDefinition#Online";
	protected static final String OWL_URL_ENDPOINT_ENV_PREFIX = "http://www.ibm.com/xmlns/prod/serviceregistry/6/1/GovernanceProfileTaxonomy#";

	/**
	 * Check that endpoint state is Online (ie. has online lifecylcle definition
	 * classification)
	 * 
	 * @param endpoint
	 * @return
	 * @throws MbException
	 */
	private boolean isOnline(MbElement endpoint) throws MbException {
		return (Boolean) endpoint.evaluateXPath("classificationURIs='" + OWL_URL_ENDPOINT_ONLINE + "'");
	}

	/**
	 * Check that endpoint has proper environment classification (Development,
	 * Production, etc.)
	 * 
	 * @param endpoint
	 * @param environment
	 * @return
	 * @throws MbException
	 */
	private boolean isEnvironment(MbElement endpoint, String environment) throws MbException {
		return (Boolean) endpoint.evaluateXPath("classificationURIs='" + OWL_URL_ENDPOINT_ENV_PREFIX + environment
				+ "'");
	}

	/**
	 * Checks if given partner id parameter (pid) is found in partnerId property
	 * (list of partnerd id's for this endpoint, separated by comma)
	 * 
	 * @param endpoint
	 * @param pid
	 * @return
	 * @throws MbException
	 */
	private boolean isPartnerEndpoint(MbElement endpoint, String pid) throws MbException {
		@SuppressWarnings("unchecked")
		java.util.List<MbElement> partnerIdProp = (java.util.List<MbElement>) endpoint
				.evaluateXPath("userDefinedProperties[@name='partnerId']/@value");
		String[] partnerIds = (partnerIdProp.size() == 1 && partnerIdProp.get(0).getValueAsString() != null) ? partnerIdProp
				.get(0).getValueAsString().split(",")
				: new String[] {};
		boolean foundPartnerId = false;
		for (int i = 0; i < partnerIds.length; i++) {
			if (partnerIds[i].equals(pid)) {
				foundPartnerId = true;
				break;
			}
		}
		return foundPartnerId;
	}

	private boolean isPortalEndpoint(MbElement endpoint) throws MbException {
		@SuppressWarnings("unchecked")
		java.util.List<MbElement> partnerIdProp = (java.util.List<MbElement>) endpoint
				.evaluateXPath("userDefinedProperties[@name='partnerId']/@value");
		String[] partnerIds = (partnerIdProp.size() == 1 && partnerIdProp.get(0).getValueAsString() != null) ? partnerIdProp
				.get(0).getValueAsString().split(",")
				: new String[] {};

		return partnerIds.length > 0;
	}

	private void loadEndpointsCache(MbElement portalEndpoint, MbElement generalEndpoint, String wsrrServiceName,
			String wsrrServiceNamespace, String wsrrServiceVersion, String endPointType) throws MbException {

		@SuppressWarnings("unchecked")
		LOVId lovId = new LOVId("13");
		LOVDetails details = PropertyManager.getInstance().retrieveShortLov(lovId);
		List<LOVInfo> LovInfoList = details.getLovInfoList();

		String poralAddressUrl = null;
		String generalAddressUrl = null;
		List<MbElement> addrs;
		boolean pidFound = false;
		if (portalEndpoint != null) {
			addrs = (java.util.List<MbElement>) portalEndpoint
					.evaluateXPath("userDefinedRelationships[@name='sm63_soapAddress']/targetEntities/Entity/userDefinedProperties[@name='sm63_soapLocation']/@value");
			if (addrs.size() > 0) {
				poralAddressUrl = addrs.get(0).getValueAsString();
			}
		}
		if (generalEndpoint != null) {
			addrs = (java.util.List<MbElement>) generalEndpoint
					.evaluateXPath("userDefinedRelationships[@name='sm63_soapAddress']/targetEntities/Entity/userDefinedProperties[@name='sm63_soapLocation']/@value");
			if (addrs.size() > 0) {
				generalAddressUrl = addrs.get(0).getValueAsString();
			}
		}
		java.util.List<MbElement> partnerIdProp = (java.util.List<MbElement>) portalEndpoint
				.evaluateXPath("userDefinedProperties[@name='partnerId']/@value");
		String[] partnerIds = (partnerIdProp.size() == 1 && partnerIdProp.get(0).getValueAsString() != null) ? partnerIdProp
				.get(0).getValueAsString().split(",")
				: new String[] {};
		for (int j = 0; j < LovInfoList.size(); j++) {
			pidFound = false;
			for (int i = 0; i < partnerIds.length; i++) {
				if (partnerIds[i].equals(LovInfoList.get(j).getLovCode())) {

					EndpointId id = new EndpointId(wsrrServiceName, wsrrServiceNamespace, wsrrServiceVersion,
							endPointType, LovInfoList.get(j).getLovCode());
					EndpointValue value = new EndpointValue();
					value.setAddressUrl(poralAddressUrl);
					PropertyManager.getInstance().putEndpoint(id, value);
					pidFound = true;
					break;
				}
			}
			if (!pidFound) {
				EndpointId id = new EndpointId(wsrrServiceName, wsrrServiceNamespace, wsrrServiceVersion, endPointType,
						LovInfoList.get(j).getLovCode());
				EndpointValue value = new EndpointValue();
				value.setAddressUrl(generalAddressUrl);
				PropertyManager.getInstance().putEndpoint(id, value);
			}

		}

	}

	/**
	 * Checks that this is general endpoint (no partnerId property or empty)
	 * 
	 * @param endpoint
	 * @return true if this is general endpoint
	 * @throws MbException
	 */
	private boolean isGeneralEndpoint(MbElement endpoint) throws MbException {
		@SuppressWarnings("unchecked")
		java.util.List<MbElement> partnerIdProp = (java.util.List<MbElement>) endpoint
				.evaluateXPath("userDefinedProperties[@name='partnerId']/@value");
		return partnerIdProp.size() == 0 || partnerIdProp.get(0).getValueAsString() == null
				|| partnerIdProp.get(0).getValueAsString().isEmpty();
	}

	public String getPartnerIdValue(String varName, MbMessageAssembly inAssembly) throws MbException {
		MbElement env = inAssembly.getGlobalEnvironment().getRootElement();
		@SuppressWarnings("unchecked")
		List<MbElement> vars = (java.util.List<MbElement>) env.evaluateXPath("Variables/MsgHdrRq" + varName);
		String varValue = null;
		if (vars.size() > 0) {
			varValue = vars.get(0).getValueAsString();
		}
		return varValue;
	}

}
