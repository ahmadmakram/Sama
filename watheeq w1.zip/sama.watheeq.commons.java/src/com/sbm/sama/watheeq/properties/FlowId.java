package com.sbm.sama.watheeq.properties;

import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbNode;
import com.sbm.sama.watheeq.utils.DomainUtils;

public class FlowId {
	
	String flowName;
	String applName;
	String egLabel;
	String nodeName;
	String domain;
	
	public FlowId(String flowName, String applicationName, String egLabel, String nodeName, String domain) {
		super();
		this.flowName = flowName;
		this.applName = applicationName;
		this.egLabel = egLabel;
		this.nodeName = nodeName;
		this.domain = domain;
	}
	
	public static class Builder {
		String flowName;
		String applicationName = "";
		String egLabel;
		String nodeName;
		String domainName;
		
		public Builder flowName(String flowName) {
			this.flowName = flowName;
			return this;
		}
		
		public Builder applicationName(String applicationName) {
			this.applicationName = applicationName;
			return this;
		}
		
		public Builder egLabel(String egLabel) {
			this.egLabel = egLabel;
			return this;
		}
		
		public Builder nodeName(String nodeName) {
			this.nodeName = nodeName;
			return this;
		}
		
		public Builder domainName(String domain) {
			this.domainName = domain;
			return this;
		}
		
		public Builder mbNode(MbNode mbNode) throws MbException {
			this.flowName = mbNode.getMessageFlow().getName();
			this.applicationName = mbNode.getMessageFlow().getApplicationName();
			this.egLabel = mbNode.getExecutionGroup().getName();
			this.nodeName = mbNode.getBroker().getName();
			this.domainName = DomainUtils.getCurrentDomainName(mbNode.getBroker().getName(), mbNode.getExecutionGroup().getName());
			
			return this;
		}
		
		public FlowId build() {
			return new FlowId(flowName, applicationName, egLabel, nodeName, domainName);
		}
		
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((applName == null) ? 0 : applName.hashCode());
		result = prime * result + ((domain == null) ? 0 : domain.hashCode());
		result = prime * result + ((egLabel == null) ? 0 : egLabel.hashCode());
		result = prime * result
				+ ((flowName == null) ? 0 : flowName.hashCode());
		result = prime * result
				+ ((nodeName == null) ? 0 : nodeName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FlowId other = (FlowId) obj;
		if (applName == null) {
			if (other.applName != null)
				return false;
		} else if (!applName.equals(other.applName))
			return false;
		if (domain == null) {
			if (other.domain != null)
				return false;
		} else if (!domain.equals(other.domain))
			return false;
		if (egLabel == null) {
			if (other.egLabel != null)
				return false;
		} else if (!egLabel.equals(other.egLabel))
			return false;
		if (flowName == null) {
			if (other.flowName != null)
				return false;
		} else if (!flowName.equals(other.flowName))
			return false;
		if (nodeName == null) {
			if (other.nodeName != null)
				return false;
		} else if (!nodeName.equals(other.nodeName))
			return false;
		return true;
	}
	
	
}