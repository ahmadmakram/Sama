package com.sbm.sama.watheeq.properties;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;

public class Request_Response_InvalidateCache extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		try {
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below
	String cacheType ="0";
	MbElement cacheTypeMbElement ; 
	cacheTypeMbElement =  inMessage.getRootElement().getFirstElementByPath("/XMLNSC/invalidateCache/CacheType");
	cacheType =cacheTypeMbElement.getValueAsString();
	//.toString();
			PropertyManager.getInstance().invalidateAll(cacheType);

			outAssembly.getMessage().getRootElement().getFirstElementByPath("/XMLNSC/invalidateCacheResponse/Status").setValue("Sucess");
			
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			outAssembly.getMessage().getRootElement().getFirstElementByPath("/XMLNSC/invalidateCacheResponse/Status").setValue("Fail");

			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			outAssembly.getMessage().getRootElement().getFirstElementByPath("/XMLNSC/invalidateCacheResponse/Status").setValue("Fail");
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			outAssembly.getMessage().getRootElement().getFirstElementByPath("/XMLNSC/invalidateCacheResponse/Status").setValue("Fail");
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);

	}

}
