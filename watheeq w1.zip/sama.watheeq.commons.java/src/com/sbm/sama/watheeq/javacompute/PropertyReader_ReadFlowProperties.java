package com.sbm.sama.watheeq.javacompute;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.sbm.sama.watheeq.properties.FlowId;
import com.sbm.sama.watheeq.properties.PropertyManager;

public class PropertyReader_ReadFlowProperties extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly assembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

		try {
			MbElement envVars = assembly.getGlobalEnvironment().getRootElement().getFirstElementByPath("Variables");
			Boolean firstCall = (Boolean) envVars.getFirstElementByPath("FirstCallFlag").getValue();
			
			FlowId flowId = new FlowId.Builder().mbNode(this).build();
			
			PropertyManager.getInstance()
				.readFlowProperties(
					this, 
					assembly, 
					flowId,
					firstCall);
			
			envVars.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "ThreadId", Thread.currentThread().getId());
			envVars.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "UniqueFlowName", this.getMessageFlow().getName());
			
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}

		// Change following to propagate the message to the 'out' or 'alt' terminal
		out.propagate(assembly);
	}

}
