package com.sbm.sama.watheeq.referencedata;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.concurrent.Callable;

import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbNode;
import com.ibm.broker.plugin.MbNode.JDBC_TransactionType;
import com.ibm.broker.plugin.MbXMLNSC;
import com.sbm.sama.watheeq.cache.CacheRegistry;
import com.sbm.sama.watheeq.cache.ICacheManager;
import com.sbm.sama.watheeq.cache.LocalLoadingCache;
import com.sbm.sama.watheeq.utils.StringUtils;

public class ReferenceDataManager implements ICacheManager {

	private static final int MAX_SIZE = 100;
	
	private final LocalLoadingCache<MappingQuery, MappingQueryResult> referenceDataCache;
	
	private static String DEFAULT_JDBC_SERVICE = "JDBCPROVIDERS_ESB";
	
	private static ReferenceDataManager INSTANCE;
	
	public static ReferenceDataManager getInstance() {
		if (INSTANCE == null) {
			synchronized (ReferenceDataManager.class) {
				if (INSTANCE == null) {
					INSTANCE = new ReferenceDataManager();
					CacheRegistry.getInstance().registerCache(INSTANCE);
				}
			}
		}
		
		return INSTANCE;
	}
	
	private ReferenceDataManager() {
		referenceDataCache = new LocalLoadingCache
			<MappingQuery, MappingQueryResult>
				(MAX_SIZE, null, null);
	}
	
	public void mapReferenceData(
			MappingQuery mappingQuery,
			MbNode mbNode, 
			MbElement mappingOutParentEl,
			boolean firstCallFlag) {
		
		try {
			if (firstCallFlag) {
				// invalidate related cache entry
				referenceDataCache.invalidate(mappingQuery);
			}
			
			MappingQueryResult mappingQueryResult 
				= referenceDataCache.get(mappingQuery, 
							new ReferenceDataMappingLoader(mbNode, mappingQuery));
			
			MbElement mappingOutputEl = mappingOutParentEl.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
			mappingOutputEl.setName("Mapping");
			
			copyMapToMbElement(mappingOutputEl, mappingQueryResult);
			
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return;
	}

	public void invalidate(MappingQuery mappingQuery) {
		this.referenceDataCache.invalidate(mappingQuery);
	}
	
	public void invalidateAll() {
		this.referenceDataCache.invalidateAll();
	}
	
	private class ReferenceDataMappingLoader implements Callable<MappingQueryResult> {

		MbNode mbNode;
		MappingQuery mappingQuery;
		
		public ReferenceDataMappingLoader(
				MbNode mbNode,
				MappingQuery mappingQuery) {
			super();
			this.mbNode = mbNode;
			this.mappingQuery = mappingQuery;
		}

		@Override
		public MappingQueryResult call() throws Exception {
			try {	
				String jdbcService = (String) mbNode.getUserDefinedAttribute("JDBCSERVICE");
				
				if (StringUtils.isNullOrEmpty(jdbcService)) {
					jdbcService = DEFAULT_JDBC_SERVICE;
				}
				
		        // Obtain a java.sql.Connection using a JDBC Type4 datasource - in this example for a 
		        // JDBC broker configurable service called "MyDB2"  

		        Connection conn = this.mbNode.getJDBCType4Connection(jdbcService, JDBC_TransactionType.MB_TRANSACTION_AUTO);

		        CallableStatement cs = conn.prepareCall("{call MAP_REF_DATA(?,?,?,?,?,?,?,?,?,?,?)}");
		        cs.setString(1, StringUtils.nullToEmpty(mappingQuery.srcSetName));
		        cs.setString(2, StringUtils.nullToEmpty(mappingQuery.targetSetName));
		        cs.setString(3, StringUtils.nullToEmpty(mappingQuery.srcCode));
		        cs.setString(4, StringUtils.nullToEmpty(mappingQuery.srcProp1));
		        cs.setString(5, StringUtils.nullToEmpty(mappingQuery.srcProp2));
		        cs.setString(6, StringUtils.nullToEmpty(mappingQuery.srcProp3));
		        cs.registerOutParameter(7, Types.CHAR);
		        cs.registerOutParameter(8, Types.CHAR);
		        cs.registerOutParameter(9, Types.CHAR);
		        cs.registerOutParameter(10, Types.CHAR);
		        cs.registerOutParameter(11, Types.INTEGER);
		        cs.execute();

		        int status = cs.getInt(11); 
		        
		        MappingQueryResult mappingQueryResult = new MappingQueryResult();
		        
		        mappingQueryResult.mappingQuery = mappingQuery;
		        mappingQueryResult.status = status;
		        
		        if (status == 0) {
		        	mappingQueryResult.targetCode 	= cs.getString(7);
		        	mappingQueryResult.targetProp1 	= cs.getString(8);
		        	mappingQueryResult.targetProp2 	= cs.getString(9);
		        	mappingQueryResult.targetProp3 	= cs.getString(10);
		        }
		        
		        return mappingQueryResult;
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}
	
	private static void copyMapToMbElement(
				MbElement targetElement, 
				MappingQueryResult mappingQueryResult)
				throws MbException {
		
		targetElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Status",  mappingQueryResult.status);
		targetElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TargCode",  mappingQueryResult.targetCode);
		targetElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TargProp1",  mappingQueryResult.targetProp1);
		targetElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TargProp2",  mappingQueryResult.targetProp2);
		targetElement.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TargProp3",  mappingQueryResult.targetProp3);

	}
}
