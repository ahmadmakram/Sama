package com.sbm.sama.watheeq.lov;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;




public class LOVDetails {
	
	
	 public static final Map<String, String> shortTimeLov;
	 public static final Map<String, String> longTimeLov;
    static {
    	Map<String, String> shortMap = new HashMap<String, String>();
 		Map<String, String> longMap = new HashMap<String, String>();

 		longMap.put("4", "Nationality");
 		longMap.put("5", "Currency");
 		longMap.put("17", "Region");
 		longMap.put("18", "City");
 		longMap.put("19", "Divisions");
 		longMap.put("24", "Department");

 		shortMap.put("2", "IdType");
 		shortMap.put("6", "FIGroup_10100");
 		shortMap.put("28", "FIGroup_10200");
 		shortMap.put("12", "AllFICodes_10100");
 		shortMap.put("29", "AllFICodes_10200");
 		shortMap.put("7", "FICode_900");
 		shortMap.put("8", "FICode_901");
 		shortMap.put("9", "FICode_902");
 		shortMap.put("10", "FICode_903");
 		shortMap.put("11", "FICode_700");
 		shortMap.put("13", "Partner");
 		shortMap.put("36", "B2B_Banks");
 		shortMap.put("16", "ServiceName");
 		longTimeLov = Collections.unmodifiableMap(longMap);
 		shortTimeLov = Collections.unmodifiableMap(shortMap);
    }
	   

	

	
	List<LOVInfo> lovInfoList;
	 
	public LOVDetails() {
		
	}

	public List<LOVInfo> getLovInfoList() {
		return lovInfoList;
	}

	public void setLovInfoList(List<LOVInfo> lovInfoList) {
		this.lovInfoList = lovInfoList;
	}

	public static class LOVInfo {
		
		String id;
		String lovParent;
		String lovCode;
		String descEn;
		String descAr;
		String attribute9;
		String lovCond1;
		String lovCond2;
		
		
		 
		public LOVInfo() {
			
		}


		public String getId() {
			return id;
		}


		public void setId(String id) {
			this.id = id;
		}


		public String getLovParent() {
			return lovParent;
		}


		public void setLovParent(String lovParent) {
			this.lovParent = lovParent;
		}


		public String getLovCode() {
			return lovCode;
		}


		public void setLovCode(String lovCode) {
			this.lovCode = lovCode;
		}


		public String getDescEn() {
			return descEn;
		}


		public void setDescEn(String descEn) {
			this.descEn = descEn;
		}


		public String getDescAr() {
			return descAr;
		}


		public void setDescAr(String descAr) {
			this.descAr = descAr;
		}


		public String getAttribute9() {
			return attribute9;
		}


		public void setAttribute9(String attribute9) {
			this.attribute9 = attribute9;
		}


		public String getLovCond1() {
			return lovCond1;
		}


		public void setLovCond1(String lovCond1) {
			this.lovCond1 = lovCond1;
		}


		public String getLovCond2() {
			return lovCond2;
		}


		public void setLovCond2(String lovCond2) {
			this.lovCond2 = lovCond2;
		}
			
		
	}
}