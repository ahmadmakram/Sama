package com.sbm.sama.watheeq.lov;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

import com.ibm.broker.plugin.MbNode;
import com.ibm.broker.plugin.MbNode.JDBC_TransactionType;
import com.sbm.sama.watheeq.lov.LOVDetails.LOVInfo;
import com.sbm.sama.watheeq.properties.PropertyManager;
import com.sbm.sama.watheeq.utils.StringUtils;

public class LovDataLoader implements Callable<LOVDetails> {

	MbNode mbNode;
	LOVId lovId;

	public LovDataLoader(MbNode mbNode, LOVId lovId) {
		super();
		this.mbNode = mbNode;
		this.lovId = lovId;
	}

	@Override
	public LOVDetails call() throws Exception {
		try {
			String jdbcService = (String) mbNode.getUserDefinedAttribute("JDBCSERVICE");

			if (StringUtils.isNullOrEmpty(jdbcService)) {
				jdbcService = PropertyManager.DEFAULT_JDBC_SERVICE;
			}

			// Obtain a java.sql.Connection using a JDBC Type4 datasource - in
			// this example for a
			// JDBC broker configurable service called "WCR"

			Connection conn = this.mbNode.getJDBCType4Connection(jdbcService,
					JDBC_TransactionType.MB_TRANSACTION_AUTO);
			LOVDetails lovDetails = new LOVDetails();

			loadLovDetails(conn, lovId.getKey(), lovDetails);

			return lovDetails;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private void loadLovDetails(Connection conn, String lovParent, LOVDetails lovDetails)
			throws SQLException {
		String query = " SELECT L.LOV_PARENT, L.LOV_CODE, L.DESCRIPTION ,L.ATTRIBUTE_1 ,L.LOV_COND_1, L.LOV_COND_2,ATTRIBUTE_9 FROM LOOKUP_VALUES L WHERE L.ACTIVE=1 and L.LOV_PARENT =?";

		PreparedStatement ps = conn.prepareStatement(query);

		ps.setString(1, lovParent);

		ResultSet rs = ps.executeQuery();
		List<LOVInfo>lovInfoList=lovDetails.getLovInfoList();
		if(lovInfoList==null)
			lovInfoList=new ArrayList<LOVInfo>();
		while (rs.next()) {
			LOVInfo lovInfo = new LOVInfo();
			lovInfo.setLovParent(rs.getString("LOV_PARENT"));
			lovInfo.setLovCode(rs.getString("LOV_CODE"));
			lovInfo.setDescEn(rs.getString("DESCRIPTION"));
			lovInfo.setDescAr(rs.getString("ATTRIBUTE_1"));
			lovInfo.setLovParent(rs.getString("LOV_CODE"));
			lovInfo.setLovCond1(rs.getString("LOV_COND_1"));
			lovInfo.setLovCond2(rs.getString("LOV_COND_2"));
			lovInfo.setAttribute9(rs.getString("ATTRIBUTE_9"));
			lovInfoList.add(lovInfo);
		}
		lovDetails.setLovInfoList(lovInfoList);
	}

}
