package com.sbm.sama.portal.tanfeeth.common.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
/**
 * 
 * @author Mahmoud Fahmi
 *
 */
public class PropertyLoader {
	public static Properties loadTanfeethProperties() throws IOException{
		Properties prop = new Properties();
		ClassLoader loader = Thread.currentThread().getContextClassLoader();           
		InputStream stream = loader.getResourceAsStream("tanfeethProperties.properties");
		prop.load(stream);
		return prop;
	}
}
