package com.sbm.sama.portal.tanfeeth.common.util;

import java.sql.Timestamp;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.sbm.sama.portal.tanfeeth.common.constant.WorkflowStatus;
import com.sbm.sama.portal.tanfeeth.common.enums.StatusCode;
import com.sbm.sama.portal.tanfeeth.jaxb.common.WorkflowTaskInfo;

public class MessageProcessor {
	public static void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage) throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element and stopping before the last child (message body)
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) {
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}

	public static WorkflowTaskBean prepareSubmitTask(WorkflowTaskBean taskInfo, WorkflowTaskInfo inputTaskInfo) {

		taskInfo.setExecutedBy(inputTaskInfo.getExecutedByUserId());
		taskInfo.setStatusId(inputTaskInfo.getStatusId());
		taskInfo.setSubStatusId(inputTaskInfo.getSubStatusId());
		taskInfo.setAssignedTo(null);
		taskInfo.setStatusCode(StatusCode.SUCCESS.getCode());
		taskInfo.setIsBulkProcessed("NO");
		taskInfo.setOfficerExecutedDate(new Timestamp(System.currentTimeMillis()));
		taskInfo.setNotes(inputTaskInfo.getNotes());

		return taskInfo;
	}

	public static boolean isValidSubmit(WorkflowTaskBean taskInfo, WorkflowTaskInfo inputTaskInfo) {

		if (taskInfo.getStatusId() == WorkflowStatus.OFFICER_INBOX
				&& taskInfo.getAssignedTo().equals(inputTaskInfo.getExecutedByUserId())
				&& taskInfo.getPid().equals(inputTaskInfo.getPID())) {
			return true;
		}
		return false;
	}

	public static boolean isValidSubmit(WorkflowTaskBean taskInfo, String userId, String PID) {

		if (taskInfo.getStatusId() == WorkflowStatus.OFFICER_INBOX && taskInfo.getAssignedTo().equals(userId)
				&& taskInfo.getPid().equals(PID)) {
			return true;
		}
		return false;
	}

	/**
	 * US7,8,9,10
	 */
	public static boolean isValidUpdate(int statusId, int subStatusId) {
		if (statusId != WorkflowStatus.OFFICER_QUEUE || statusId != WorkflowStatus.OFFICER_INBOX
				|| statusId != WorkflowStatus.MANAGER_SUBMIT) {
			return false;
		} else if (statusId == WorkflowStatus.OFFICER_QUEUE
				&& (subStatusId != 1 || subStatusId != 2 || subStatusId != 3)) { //US8:If the status in the request =1 , SubstatusID should = 1 (initial status) , or = 2 (was with the officer and returned it to the Q) or = 3 and means was with the manager and returned it to the officer Q 
			return false;
		}else if(statusId == WorkflowStatus.OFFICER_INBOX && (subStatusId != 0 || subStatusId != 3)){ //US9:If the status in the request =2 , SubstatusID should = 3 as it returned from the manger to the officer again or 0 as checked out by the officer
			return false;
		}else if(statusId == WorkflowStatus.MANAGER_SUBMIT && subStatusId != 0){ //US10:If the status in the request =6 , SubstatusID should = 0 as it processed by the manger
			return false;
		}else {
			return true;
		}		
	}

	public static boolean isValidUpdate(WorkflowTaskBean taskInfo, String userId, String PID) {

		if (taskInfo.getStatusId() == WorkflowStatus.MANAGER_INBOX && taskInfo.getAssignedTo().equals(userId)
				&& taskInfo.getPid().equals(PID)) {
			return true;
		}
		return false;
	}

	public static WorkflowTaskInfo mapWorkflowTaskInfo(WorkflowTaskBean taskBean) {

		WorkflowTaskInfo taskInfo = new WorkflowTaskInfo();

		taskInfo.setTaskId(taskBean.getTaskId().intValue());
		taskInfo.setStatusId(taskBean.getStatusId());
		taskInfo.setSubStatusId(taskBean.getSubStatusId());
		taskInfo.setExecutedByUserId(taskBean.getAssignedTo());
		taskInfo.setExecutedByRoleId(taskBean.getAssignedByRole());
		taskInfo.setPID(taskBean.getPid());

		return taskInfo;
	}
}
