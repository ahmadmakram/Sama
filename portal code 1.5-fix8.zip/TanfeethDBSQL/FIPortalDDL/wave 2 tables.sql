--------------------------------------------------------
--  DDL for Table DENY_DEALING_RESPONSE
--------------------------------------------------------

  CREATE TABLE "FIPORTAL"."DENY_DEALING_RESPONSE" 
   (	"ID" NUMBER(*,0), 
	"TASK_ID" NUMBER(*,0), 
	"CUST_NAME" VARCHAR2(100 BYTE), 
	"CUST_ID" VARCHAR2(20 BYTE), 
	"CUST_IDTYPE" VARCHAR2(10 BYTE), 
	"EXE_DTTM" TIMESTAMP (6), 
	"IS_DELETED" VARCHAR2(3 BYTE) DEFAULT 'NO', 
	"CUST_NTNLTY" VARCHAR2(3 BYTE), 
	"CREATED_DATE_TIME" TIMESTAMP (6)
   );
--------------------------------------------------------
--  DDL for Index DENY_RESP_ID
--------------------------------------------------------

  CREATE UNIQUE INDEX "FIPORTAL"."DENY_RESP_ID" ON "FIPORTAL"."DENY_DEALING_RESPONSE" ("ID")  ;
--------------------------------------------------------
--  DDL for Index DENY_RESP_REQ_ID
--------------------------------------------------------

  CREATE INDEX "FIPORTAL"."DENY_RESP_REQ_ID" ON "FIPORTAL"."DENY_DEALING_RESPONSE" ("TASK_ID") ;
--------------------------------------------------------
--  Constraints for Table DENY_DEALING_RESPONSE
--------------------------------------------------------

  ALTER TABLE "FIPORTAL"."DENY_DEALING_RESPONSE" ADD CONSTRAINT "DENY_RESP_ID" PRIMARY KEY ("ID");
  ALTER TABLE "FIPORTAL"."DENY_DEALING_RESPONSE" MODIFY ("ID" NOT NULL ENABLE);


  CREATE SEQUENCE  "FIPORTAL"."DENYDEALING_TASK_SQID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 
   INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE ;






--------------------------------------------------------
--  DDL for Table BAN_DEALING_RESPONSE
--------------------------------------------------------

  CREATE TABLE "FIPORTAL"."BAN_DEALING_RESPONSE" 
   (	"ID" NUMBER(*,0), 
	"CUST_NAME" VARCHAR2(100 BYTE), 
	"CUST_ID" VARCHAR2(20 BYTE), 
	"CUST_IDTYPE" VARCHAR2(10 BYTE), 
	"CUST_NTNLTY" VARCHAR2(3 BYTE), 
	"EXE_DTTM" TIMESTAMP (6), 
	"IS_DELETED" VARCHAR2(3 BYTE) DEFAULT 'NO', 
	"TASK_ID" NUMBER(*,0), 
	"CREATED_DATE_TIME" TIMESTAMP (6)
   ) ;
--------------------------------------------------------
--  DDL for Index BAN_RESP_ID1
--------------------------------------------------------

  CREATE UNIQUE INDEX "FIPORTAL"."BAN_RESP_ID1" ON "FIPORTAL"."BAN_DEALING_RESPONSE" ("ID")  ;
--------------------------------------------------------
--  Constraints for Table BAN_DEALING_RESPONSE
--------------------------------------------------------

  ALTER TABLE "FIPORTAL"."BAN_DEALING_RESPONSE" ADD CONSTRAINT "BAN_DEALING_RESPONSE_PK" PRIMARY KEY ("ID");
  ALTER TABLE "FIPORTAL"."BAN_DEALING_RESPONSE" MODIFY ("TASK_ID" NOT NULL ENABLE);
  ALTER TABLE "FIPORTAL"."BAN_DEALING_RESPONSE" MODIFY ("ID" NOT NULL ENABLE);

  
  --------------------------------------------------------
--  DDL for Sequence BANDEALING_TASK_SQID
--------------------------------------------------------

   CREATE SEQUENCE  "FIPORTAL"."BANDEALING_TASK_SQID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 41 CACHE 20 NOORDER  NOCYCLE ;
  