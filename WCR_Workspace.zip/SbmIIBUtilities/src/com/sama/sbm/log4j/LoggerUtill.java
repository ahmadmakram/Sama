package com.sama.sbm.log4j;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.ibm.broker.plugin.MbMessage;


public class LoggerUtill {

final static Logger logger = Logger.getLogger(LoggerUtill.class);
	
	public static void main(String[] args) {
	
		initLog( "../log4j.properties");
//		PropertyConfigurator.configure(log4jConfPath);
		LoggerUtill obj = new LoggerUtill();
		obj.runMe("test");
		
	}
	
	private void runMe(String parameter){
		
		if(logger.isDebugEnabled()){
			logger.debug("This is debug : " + parameter);
		}
		
		if(logger.isInfoEnabled()){
			logger.info("This is info : " + parameter);
		}
		
		logger.warn("This is warn : " + parameter);
		logger.error("This is error : " + parameter);
		logger.fatal("This is fatal : " + parameter);
		
	}
	
	
	public static void initLog(String configPath){
			PropertyConfigurator.configure(configPath);
	}
	
	public static void logException(MbMessage inputRoot,MbMessage excpList){
		//		System.out.println(obj.toString());
//			String log4jConfPath = "log4j.properties";
//			PropertyConfigurator.configure(log4jConfPath);
			logger.info("Curent time"+ System.currentTimeMillis());
			logger.warn(inputRoot);
			logger.fatal(excpList);

		
	}
}
