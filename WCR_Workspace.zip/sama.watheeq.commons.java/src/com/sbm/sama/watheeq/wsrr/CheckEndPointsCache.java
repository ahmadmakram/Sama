package com.sbm.sama.watheeq.wsrr;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.sbm.sama.watheeq.properties.PropertyManager;

public class CheckEndPointsCache extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		
//		MbOutputTerminal out = getOutputTerminal("out");
//		MbOutputTerminal alt = getOutputTerminal("alternate");
		MbOutputTerminal outTerminal = null;

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		try {
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below
			String endPointType;
			String destName = (String) inAssembly.getGlobalEnvironment().getRootElement().getFirstElementByPath("Variables/DestinationName").getValue();
			String wsrrServiceName = (String) inAssembly.getGlobalEnvironment().getRootElement().getFirstElementByPath("Variables/FlowDestinations/"+destName+"/WSRRServiceName").getValue();
			String wsrrServiceNamespace = (String) inAssembly.getGlobalEnvironment().getRootElement().getFirstElementByPath("Variables/FlowDestinations/"+destName+"/WSRRServiceNamespace").getValue();
			String wsrrServiceVersion = (String) inAssembly.getGlobalEnvironment().getRootElement().getFirstElementByPath("Variables/FlowDestinations/"+destName+"/WSRRServiceVersion").getValue();
			
			MbElement endPointTypeElement = inAssembly.getGlobalEnvironment().getRootElement().getFirstElementByPath("Variables/Retry/MQRFH2/usr/EndPointType");
			if(endPointTypeElement!=null)
				endPointType = (String) endPointTypeElement.getValue();
			else
				endPointType="proxy";
				
			String pid = (String) inAssembly.getGlobalEnvironment().getRootElement().getFirstElementByPath("Variables/MsgHdrRq/PID").getValue();
			
			MbMessage environment = new MbMessage(inAssembly.getLocalEnvironment());
			MbElement environmentRoot = environment.getRootElement();
			
			EndpointId id = new EndpointId(wsrrServiceName, wsrrServiceNamespace, wsrrServiceVersion,endPointType,pid);
			EndpointValue value=PropertyManager.getInstance().retrieveEndpoint(id);
			
			// Service name Does not exist in endpoints cache
			if(value == null)
			{
				// propagate to WSRR registry lookup
				outTerminal = getOutputTerminal("alternate");
			}
			
			//Service name exists in endpoints cache and the address url is not empty
			else if (value.getAddressUrl() != null && !value.getAddressUrl().isEmpty() && !value.getAddressUrl().equals("-")) {
			
				environmentRoot.evaluateXPath("?Destination/?SOAP/?Request/?Transport/?HTTP/?WebServiceURL[set-value('" + value.getAddressUrl() + "')]");
				environmentRoot.evaluateXPath("?Destination/?HTTP/?RequestURL[set-value('" + value.getAddressUrl() + "')]");
				
				outAssembly = new MbMessageAssembly( inAssembly
						                           , environment
						                           , inAssembly.getExceptionList()
						                           , inAssembly.getMessage()
						                           );
				outTerminal = getOutputTerminal("out");
				
			//Service name exists in endpoints cache and the address url is empty
			} else {
					outTerminal = getOutputTerminal("failure");
			}

			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		outTerminal.propagate(outAssembly);

	}

}
