package com.sbm.sama.watheeq.wsrr;

public class EndpointValue {
	
	String addressUrl;

	public String getAddressUrl() {
		return addressUrl;
	}

	public void setAddressUrl(String addressUrl) {
		this.addressUrl = addressUrl;
	}
	
	

}
