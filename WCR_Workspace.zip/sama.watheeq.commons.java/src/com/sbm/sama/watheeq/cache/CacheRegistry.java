package com.sbm.sama.watheeq.cache;

import java.util.HashSet;
import java.util.Set;

import com.sbm.sama.watheeq.properties.FlowId;
import com.sbm.sama.watheeq.properties.PropertyManager;
import com.sbm.sama.watheeq.referencedata.ReferenceDataManager;

/**
 * Registry that holds references to all cache managers. This classes implements
 * Singleton pattern and is used to do whole-cache-level operations, 
 * mainly invalidateAll() to start with. Later on, we can add more operation 
 * if needed
 * 
 *
 */
public class CacheRegistry {

	private static CacheRegistry INSTANCE;
	
	/**
	 * each cache manager is resonsible of registering itself with CacheRegistry
	 * so that it can receive cache-level commands, such as invalidateAll
	 */
	private Set<ICacheManager> cacheManagers = new HashSet<ICacheManager>();
	
	public static CacheRegistry getInstance() {
		if (INSTANCE == null) {
			synchronized (PropertyManager.class) {
				if (INSTANCE == null) {
					INSTANCE = new CacheRegistry();
				}
			}
		}
		
		return INSTANCE;
	}
	
	public void registerCache(ICacheManager cacheManager) {
		cacheManagers.add(cacheManager);
	}
	
	public void unregisterCache(ICacheManager cacheManager) {
		cacheManagers.remove(cacheManager);
	}
	
	public void invalidateAll() {
		for (ICacheManager cacheManager : cacheManagers) {
			cacheManager.invalidateAll();
		}
	}
	
	public void invalidateCache(String command) {
		if (command.equals(ICache.FUNC_ID__CLEAR_FLOW_PROPS_ALL_FLOWS_CACHE)) {
			PropertyManager.getInstance().invalidateAll();
		} else if (command.equals(ICache.FUNC_ID__CLEAR_REF_DATA_ALL_SETS)) {
			ReferenceDataManager.getInstance().invalidateAll();
		}
	}
	
	public static void staticInvalidateCache(String command) {
		if (command.equals(ICache.FUNC_ID__CLEAR_FLOW_PROPS_ALL_FLOWS_CACHE)) {
			PropertyManager.getInstance().invalidateAll();
		} else if (command.equals(ICache.FUNC_ID__CLEAR_REF_DATA_ALL_SETS)) {
			ReferenceDataManager.getInstance().invalidateAll();
		}
	}
	
	public static void staticInvalidateFlowPropertiesCache() {
		PropertyManager.getInstance().invalidateAll();
	}
	
	public static void staticInvalidateReferenceDataCache() {
		ReferenceDataManager.getInstance().invalidateAll();
	}
}
