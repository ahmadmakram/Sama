package com.sbm.sama.watheeq.cache;

import java.util.Map;
import java.util.Queue;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;

/**
 * Basic and incomplete implmentation for cache, in case the guava-based 
 * approach is not approved due to license conflicts
 * 
 *
 * @param <K>
 * @param <V>
 */
public class BasicCache<K, V> implements ICache<K, V>{

	int maxSize = 5;
	int minSize = 2;
	
	long expiryPeriodMillis = 60 * 60 * 1000; // one hour
	
	Map<K, CacheEntry<K, V>> map = new ConcurrentHashMap<K, CacheEntry<K, V>>();
	
	final Queue<CacheEntry<K, V>> recencyQueue = new ConcurrentLinkedQueue<CacheEntry<K,V>>();
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BasicCache<String, String> cm = new BasicCache<String, String>();
		
		for (int i = 0; i < 10; i++) {
			cm.put(i + "", i + "");
		}
			
	}

	@Override
	public V get(K key, Callable<? extends V> valueLoader) {
		System.out.println("getting item for key: " + key);
		
		CacheEntry<K, V> cachedEntry = map.get(key);
		if (cachedEntry == null || isExpired(cachedEntry)) {
			System.out.println("key not found: " + key);
			return null;
		} else {
			cachedEntry.lastAccessedTime = System.currentTimeMillis();
			System.out.println("key found. K: " + key + ", Value: " + cachedEntry.value);
			return cachedEntry.value;
		}
	}

	@Override
	public void put(K k, V value) {
		CacheEntry<K, V> cacheEntry = getCacheEntry(k);
		if (cacheEntry != null) {
			V oldValue = cacheEntry.value;
			cacheEntry.updateValue(value);
			cacheEntry.isExpired = false;
			cacheEntry.lastWriteTime = System.currentTimeMillis();
			
			System.out.println("updating an existing key. K: " + k + ", old value: " + oldValue + ", new value: " + value);
		} else {
			System.out.println("adding new key. key: " + k + ", value: " + value);
			cacheEntry = new CacheEntry<K, V>(k, value);
			this.map.put(k, cacheEntry);
			
			this.recencyQueue.add(cacheEntry);
			
			// check map's capacity. if exceeded, delete the least accessed entries
			if (map.size() > maxSize) {
				drainRecencyQueue(map.size() - minSize);
			}
		}
	}

	@Override
	public V getIfPresent(Object key) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void putAll(Map<? extends K, ? extends V> m) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void invalidate(Object key) {
		map.remove(key);
	}

	@Override
	public void invalidateAll(Iterable<?> keys) {
	    for (Object key : keys) {
	    	invalidate(key);
	    }
	}

	@Override
	public void invalidateAll() {
		this.map.clear();
	}

	@Override
	public long size() {
		return this.map.size();
	}

	@SuppressWarnings("unchecked")
	@Override
	public ConcurrentMap<K, V> asMap() {
		return (ConcurrentMap<K, V>) map;
	}

	@Override
	public void cleanUp() {
		// TODO Auto-generated method stub
		
	}
	
	private CacheEntry<K, V> getCacheEntry(K key) {
		CacheEntry<K, V> cachedEntry = map.get(key);
		if (cachedEntry == null) {
			return null;
		} else {
			if (isExpired(cachedEntry)) {
				cachedEntry.isExpired = true;
			}
			return cachedEntry;
		}
	}

	
	private synchronized void drainRecencyQueue(int drainSize) {
		for (int i = 0; i < drainSize; i++) {
			CacheEntry<K, V> cacheEntry = this.recencyQueue.poll();
			System.out.println("draining item: " + this.map.remove(cacheEntry.key));
		}
		
	}

	public boolean isExpired(CacheEntry<K, V> cachedEntry) {
		return (System.currentTimeMillis() - cachedEntry.lastWriteTime) > expiryPeriodMillis;
	}
	
	class CacheEntry<K1, V2> {
		long lastAccessedTime;
		long lastWriteTime = System.currentTimeMillis();
		K1 key;
		V2 value;
		
		boolean isExpired = false;
		
		public CacheEntry(K1 k, V2 value) {
			this.key = k;
			this.value = value;
		}
		
		void updateValue(V2 value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return "CacheEntry [key=" + key + ", value=" + value + "]";
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result + ((key == null) ? 0 : key.hashCode());
			return result;
		}

		@SuppressWarnings("rawtypes")
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			CacheEntry other = (CacheEntry) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (key == null) {
				if (other.key != null)
					return false;
			} else if (!key.equals(other.key))
				return false;
			return true;
		}

		private BasicCache<K, V> getOuterType() {
			return BasicCache.this;
		}
		
		
	}
}
