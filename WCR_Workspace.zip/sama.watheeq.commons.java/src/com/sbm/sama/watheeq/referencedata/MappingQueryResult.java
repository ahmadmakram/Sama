package com.sbm.sama.watheeq.referencedata;

public class MappingQueryResult {

	/**
				Environment.Variables.ReferenceDataMapping.IN.Mapping[i].SrcSetName
				Environment.Variables.ReferenceDataMapping.IN.Mapping[i].TargSetName
				Environment.Variables.ReferenceDataMapping.IN.Mapping[i].IntermSetName (intermediary)
				
				Environment.Variables.ReferenceDataMapping.IN.Mapping[i].SrcCode
				Environment.Variables.ReferenceDataMapping.IN.Mapping[i].SrcProp1
				Environment.Variables.ReferenceDataMapping.IN.Mapping[i].SrcProp2
				Environment.Variables.ReferenceDataMapping.IN.Mapping[i].SrcProp3
				
				Environment.Variables.ReferenceDataMapping.OUT.Mapping[i].Status
				Environment.Variables.ReferenceDataMapping.OUT.Mapping[i].TargCode
				Environment.Variables.ReferenceDataMapping.OUT.Mapping[i].TargProp1
				Environment.Variables.ReferenceDataMapping.OUT.Mapping[i].TargProp2
				Environment.Variables.ReferenceDataMapping.OUT.Mapping[i].TargProp3
				
	 */
	
	MappingQuery mappingQuery;
	
	Integer status;
	
	String targetCode;
	String targetProp1 = "";
	String targetProp2 = "";
	String targetProp3 = "";
	
}
