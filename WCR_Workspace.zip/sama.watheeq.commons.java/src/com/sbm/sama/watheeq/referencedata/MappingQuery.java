package com.sbm.sama.watheeq.referencedata;

public class MappingQuery {

	/**
				Environment.Variables.ReferenceDataMapping.IN.Mapping[i].SrcSetName
				Environment.Variables.ReferenceDataMapping.IN.Mapping[i].TargSetName
				Environment.Variables.ReferenceDataMapping.IN.Mapping[i].IntermSetName (intermediary)
				
				Environment.Variables.ReferenceDataMapping.IN.Mapping[i].SrcCode
				Environment.Variables.ReferenceDataMapping.IN.Mapping[i].SrcProp1
				Environment.Variables.ReferenceDataMapping.IN.Mapping[i].SrcProp2
				Environment.Variables.ReferenceDataMapping.IN.Mapping[i].SrcProp3
	 */
	
	String srcSetName;
	String targetSetName;
	
	String srcCode;
	String srcProp1 = "";
	String srcProp2 = "";
	String srcProp3 = "";
	
	public MappingQuery(String srcSetName, String targetSetName,
			String srcCode, String srcProp1,
			String srcProp2, String srcProp3) {
		super();
		this.srcSetName = srcSetName;
		this.targetSetName = targetSetName;
		this.srcCode = srcCode;
		this.srcProp1 = srcProp1;
		this.srcProp2 = srcProp2;
		this.srcProp3 = srcProp3;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((srcCode == null) ? 0 : srcCode.hashCode());
		result = prime * result
				+ ((srcProp1 == null) ? 0 : srcProp1.hashCode());
		result = prime * result
				+ ((srcProp2 == null) ? 0 : srcProp2.hashCode());
		result = prime * result
				+ ((srcProp3 == null) ? 0 : srcProp3.hashCode());
		result = prime * result
				+ ((srcSetName == null) ? 0 : srcSetName.hashCode());
		result = prime * result
				+ ((targetSetName == null) ? 0 : targetSetName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MappingQuery other = (MappingQuery) obj;
		if (srcCode == null) {
			if (other.srcCode != null)
				return false;
		} else if (!srcCode.equals(other.srcCode))
			return false;
		if (srcProp1 == null) {
			if (other.srcProp1 != null)
				return false;
		} else if (!srcProp1.equals(other.srcProp1))
			return false;
		if (srcProp2 == null) {
			if (other.srcProp2 != null)
				return false;
		} else if (!srcProp2.equals(other.srcProp2))
			return false;
		if (srcProp3 == null) {
			if (other.srcProp3 != null)
				return false;
		} else if (!srcProp3.equals(other.srcProp3))
			return false;
		if (srcSetName == null) {
			if (other.srcSetName != null)
				return false;
		} else if (!srcSetName.equals(other.srcSetName))
			return false;
		if (targetSetName == null) {
			if (other.targetSetName != null)
				return false;
		} else if (!targetSetName.equals(other.targetSetName))
			return false;
		return true;
	}
	
	
}
