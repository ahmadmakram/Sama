package com.sbm.sama.watheeq.utils;

public class DomainUtils {

	public static String DOMAIN_NAME_WATHEEQ = "WATHEEQ";
	public static String DOMAIN_NAME_EXT = "EXT";
	
	public static String[] DOMAIN_NAMES = new String[] {
		DOMAIN_NAME_WATHEEQ,
		DOMAIN_NAME_EXT
	};
	
	public static String getCurrentDomainName(String brokerName, String intSrvrName) {
		brokerName = brokerName.toLowerCase();
		intSrvrName = intSrvrName.toLowerCase();
		
//		for (String domainName : DOMAIN_NAMES) {
//			if (brokerName.startsWith(domainName))	return domainName;
//		}
//		
//		for (String domainName : DOMAIN_NAMES) {
//			if (intSrvrName.startsWith(domainName))	return domainName;
//		}
		
		
		
//		throw new IllegalArgumentException(
//			String.format("Domain name could not be identified for nod [%1$s] and integration server [%2$s]",
//			brokerName, 
//			intSrvrName));
		
		return DOMAIN_NAME_WATHEEQ;
	}
}
