package com.sbm.sama.watheeq.properties;

public class FiDetails {
	String fiPid;
	String fiGroup;
	Integer isB2B;
	Integer isActive;
	Integer isIndv;
	Integer isCorp;
	Integer isGov;
	Integer isChrty;
	Integer isChmbr;
	
	public String getFiPid() {
		return fiPid;
	}
	public void setFiPid(String fiPid) {
		this.fiPid = fiPid;
	}
	public String getFiGroup() {
		return fiGroup;
	}
	public void setFiGroup(String fiGroup) {
		this.fiGroup = fiGroup;
	}
	public Integer getIsB2B() {
		return isB2B;
	}
	public void setIsB2B(Integer isB2B) {
		this.isB2B = isB2B;
	}
	public Integer getIsActive() {
		return isActive;
	}
	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}
	public Integer getIsIndv() {
		return isIndv;
	}
	public void setIsIndv(Integer isIndv) {
		this.isIndv = isIndv;
	}
	public Integer getIsCorp() {
		return isCorp;
	}
	public void setIsCorp(Integer isCorp) {
		this.isCorp = isCorp;
	}
	public Integer getIsGov() {
		return isGov;
	}
	public void setIsGov(Integer isGov) {
		this.isGov = isGov;
	}
	public Integer getIsChrty() {
		return isChrty;
	}
	public void setIsChrty(Integer isChrty) {
		this.isChrty = isChrty;
	}
	public Integer getIsChmbr() {
		return isChmbr;
	}
	public void setIsChmbr(Integer isChmbr) {
		this.isChmbr = isChmbr;
	}
}