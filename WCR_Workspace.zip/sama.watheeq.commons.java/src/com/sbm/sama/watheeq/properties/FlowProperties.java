package com.sbm.sama.watheeq.properties;

import java.util.List;
import java.util.Map;

class FlowProperties {
	
	FlowId flowId;
	String id;
	String flowType;
	Boolean enableTransactionAudit;
	String loadLov;
	List<FlowService> services;
	
	
	public FlowProperties(FlowId flowId) {
		super();
		this.flowId = flowId;
		
	}
	
	public static class FlowService {
		String id;
		String flowPropertiesId;
		
		String serviceName;
		String serviceDesc;
		String serviceCode;
		String bindingType;
		String mqEndpoint;
		Map<String, Map<String, List<EndpointDetails>>> routingData;
		List<ServiceFiConfig> fiConfigData;	// Added by Gabr: Copy Service FI Configuration
		String destinationQmgr;
		String replyToEndpoint;
		String replyToQmgr;
		
		String retryEndpoint;
		String retryQMGR;
		String retryWaitTime;
		String retryCount;
		
		String wsrrServiceName;
		String wsrrServiceNamespace;
		String wsrrServiceVersion;
		
		
		String ccsid;
		String encoding;
		String msgType;
		String trgtSystemId;
		String trgtDomainId;
		String priority;
		String persistence;
		String expiry;
		String faultEndpoint;

	}
	
	public static class EndpointDetails {
		String id;
		String flowServiceId;		
		String pID;
		String channel;
		String routingPlan;
		String endpoint;
		String endpointType;
		String endpointOrder;
		String retryCount;
		String waitTime;
		String ignoreTransformation;
		

	}
}