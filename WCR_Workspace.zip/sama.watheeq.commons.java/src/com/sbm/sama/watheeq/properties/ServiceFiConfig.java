package com.sbm.sama.watheeq.properties;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

class ServiceFiConfig {
	String rpPid;
	String serviceId;
	List<FiDetails> fiDetailsList;
	
	public ServiceFiConfig() {
		fiDetailsList = new ArrayList<FiDetails>();
	}
	
	public ServiceFiConfig(String serviceId) {
		this();
		this.serviceId = serviceId;		
	}
	
	public ServiceFiConfig(String rpPid, String serviceId, List<FiDetails> fiDetails) {
		this();
		this.rpPid = rpPid;
		this.serviceId = serviceId;		
	}
	
	
	
	public String getRpPid() {
		return rpPid;
	}

	public void setRpPid(String rpPid) {
		this.rpPid = rpPid;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public List<FiDetails> getFiDetails() {
		return fiDetailsList;
	}

	public void setFiDetails(List<FiDetails> fiDetailsList) {
		this.fiDetailsList = fiDetailsList;
	}
	
	public void addFiDetails(FiDetails obj) {
		fiDetailsList.add(obj);
	}
}