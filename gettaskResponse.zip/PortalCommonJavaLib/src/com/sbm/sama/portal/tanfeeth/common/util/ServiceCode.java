package com.sbm.sama.portal.tanfeeth.common.util;

public class ServiceCode {

	
	public final static String ACC = "01";
	public final static String BAL = "02";
	public final static String DEP = "03";
	public final static String SAF = "04";
	public final static String LIAB = "05";
	public final static String DENY = "07";
	public final static String BAN = "08";
	public final static String LIFT = "09";
	public final static String BLOCK = "10";
	public final static String GAR = "11";
	public final static String L_DENY = "12";
	public final static String L_BAN = "13";
	public final static String L_BLOCK = "14";
	public final static String L_GAR = "15";
	 
}
