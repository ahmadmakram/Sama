package com.sbm.sama.portal.tanfeeth.common.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.jaxb.common.ShareInfoResponseType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TShrInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TShrsList;
import com.sbm.sama.portal.tanfeeth.common.dao.CommonShareInfoDao;

/**
 * 
 * @author Mahmoud Fahmi
 * 
 */
public class CommonShareInfoDaoImpl implements CommonShareInfoDao {

	@Override
	public void addShare(Connection conn, List<ShareInfoResponseType> _shareInfo_list, int taskId,
			String prodcutType) throws SQLException {
		String sqlShareInsert = "INSERT INTO FIPORTAL.PRODUCT_SHARE (PRD_SHRS_ID, TASK_ID, COMP_NAME, SHRS_PRCNT, PRD_TYPE) VALUES ( PRD_SHRS_SEQ.NEXTVAL,?,?,?,?)";
		PreparedStatement preparedStatement = conn.prepareStatement(sqlShareInsert);

		for (ShareInfoResponseType shareInfoResponseType : _shareInfo_list) {
			preparedStatement.setInt(1, taskId);
			preparedStatement.setString(2, shareInfoResponseType.getCompanyName());
			preparedStatement.setBigDecimal(3, shareInfoResponseType.getSharePercentage());
			preparedStatement.setString(4, prodcutType);

			preparedStatement.executeUpdate();
		}
	}

	@Override
	public void deleteShare(int taskId, Connection conn) throws SQLException {
		String sqlShareDelete = "DELETE FROM FIPORTAL.PRODUCT_SHARE where TASK_ID = ?";
		PreparedStatement preparedStatement = conn.prepareStatement(sqlShareDelete);
		preparedStatement.setInt(1, taskId);
		preparedStatement.executeUpdate();
	}

	public List<ShareInfoResponseType> selectShare(int taskId, Connection _conn) throws SQLException {
		List<ShareInfoResponseType> _sitems = new ArrayList<ShareInfoResponseType>();
		String _sql_shar_info_res = "SELECT * FROM FIPORTAL.PRODUCT_SHARE WHERE TASK_ID =? ";
		PreparedStatement _pss = _conn.prepareStatement(_sql_shar_info_res);
		_pss.setInt(1, taskId);
		ResultSet _rss = _pss.executeQuery();
		while (_rss.next()) {
			ShareInfoResponseType _item = new ShareInfoResponseType();
			_item.setCompanyName(_rss.getString("COMP_NAME"));
			_item.setSharePercentage(_rss.getBigDecimal("SHRS_PRCNT"));
			_sitems.add(_item);
		}

		return _sitems;
	}

	@Override
	public TShrsList selectShareCallBack(int taskId, Connection _conn) throws SQLException {

		TShrsList _sl = new TShrsList();
		List<TShrInfo> _sitems = new ArrayList<TShrInfo>();
		String _sql_shar_info_res = "SELECT * FROM FIPORTAL.PRODUCT_SHARE WHERE TASK_ID =? ";
		PreparedStatement _pss = _conn.prepareStatement(_sql_shar_info_res);
		_pss.setInt(1, taskId);
		ResultSet _rss = _pss.executeQuery();
		while (_rss.next()) {
			TShrInfo _item = new TShrInfo();
			_item.setCmpnyName(_rss.getString("COMP_NAME"));
			_item.setShrPrcnt(_rss.getBigDecimal("SHRS_PRCNT"));
			_sitems.add(_item);
		}

		_sl.shrInfo = _sitems;
		return _sl;
	}

}
