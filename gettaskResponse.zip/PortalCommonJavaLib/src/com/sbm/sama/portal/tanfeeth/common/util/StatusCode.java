package com.sbm.sama.portal.tanfeeth.common.util;

public enum StatusCode {

//	public final static String SUCCESS = "S0000000";
//	public final static String ACK = "S1000000";
//	public final static String NO_RELATION = "S9000001";
//	public final static String NOT_CUST = "S9000002";
//	public final static String NOT_CUST_BLOCK = "S9000003";
//	public final static String CUST_NOT_MATCH_ACC = "S9000007";
//	public final static String CUST_NO_ACT = "S9000007";
//	public final static String NOT_CUST_ACT_ACC = "S9000009";
//
//	public final static String FATAL_ERROR = "E9999999";
//	public final static String NOT_VALID_ACTION = "E9700001";
//	public final static String NOT_VALID_STATUS = "E9700002";
//	public final static String NOT_VALID_BULK_PROCESS = "E9700003";
	
	SUCCESS("S0000000",  "The operation done successfully"),
	ACK("S1000000",  "MA"),
	NO_RELATION("S9000001",  "MA"),
	NOT_CUST("S9000002",  "MA"),
	NOT_CUST_BLOCK("S9000003",  "MA"),
	CUST_NOT_MATCH_ACC("S9000007",  "MA"),
	CUST_NO_ACT("S9000007",  "MA"),
	NOT_CUST_ACT_ACC("S9000009",  "MA"),
	FATAL_ERROR("E9999999",  "Fatal Error"),
	NOT_VALID_ACTION("E9700001",  "Not Valid Action"),
	NOT_VALID_STATUS("E9700002",  " Not Valid Status"),
	NOT_VALID_BULK_PROCESS("E9700003",  "Not Valid is Bulk Processing"),
	UNABLE_TO_ASSIGN("E0000001",  "Unable to Assign Task: Current ASSIGNED_TO IN Database DO NOT MATCH SUPPLIED OLD_ASSIGNED_TO INPUT");
	

	    private final String code;
	    private final String desc;

	    
	    private StatusCode(String code, String desc) {
	        this.code = code;
	        this.desc = desc;
	    }


		public String getCode() {
			return code;
		}


		public String getDesc() {
			return desc;
		}
		
		public static StatusCode findByCode(String code){
		    for(StatusCode s : values()){
		        if( s.getCode().equals(code)){
		            return s;
		        }
		    }
		    return null;
		}

	    
}
