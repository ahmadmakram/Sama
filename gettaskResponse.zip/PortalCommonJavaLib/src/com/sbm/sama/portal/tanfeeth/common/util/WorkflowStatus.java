package com.sbm.sama.portal.tanfeeth.common.util;

public class WorkflowStatus {

	public final static int OFFICER_QUEUE = 1;
	public final static int OFFICER_INBOX = 2;
	public final static int OFFICER_SUBMIT = 3;
	public final static int MANAGER_QUEUE = 4;
	public final static int MANAGER_INBOX = 5;
	public final static int MANAGER_SUBMIT = 6;
	public final static int RETURN_SUBSTATUS = 3;

}
