package com.sbm.sama.portal.tanfeeth.common.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sbm.sama.portal.tanfeeth.common.dao.CommonUserDao;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TPrdUsrsLis;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TUsrInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.UserInfoResponseType;

/**
 * 
 * @author Mahmoud Fahmi
 * 
 */
public class CommonUserDaoImpl implements CommonUserDao {
 
	public List<UserInfoResponseType>  selectUser(Connection _conn, int taskId) throws SQLException {
		String _sql_user_info_res = "SELECT * FROM FIPORTAL.PRD_USR_LST WHERE PRD_ID=? ";
		PreparedStatement _psu = _conn.prepareStatement(_sql_user_info_res);
		_psu.setInt(1, Integer.valueOf(taskId));
		ResultSet _rsu = _psu.executeQuery();
		List<UserInfoResponseType> _uitems = new ArrayList<UserInfoResponseType>();
		while (_rsu.next()) {
			UserInfoResponseType _uitem = new UserInfoResponseType();
			_uitem.setUserId(_rsu.getString("PRD_USER_ID"));
			_uitem.setIdType(_rsu.getString("PRD_USER_ID_TYPE"));
			_uitem.setName(_rsu.getString("PRD_USER_NAME"));
			_uitem.setUserType(_rsu.getString("PRD_USER_TYPE"));
			_uitems.add(_uitem);
		}
		

			return _uitems;
	}

	public TPrdUsrsLis  selectUserCallBack(Connection _conn, int taskId) throws SQLException {
		String _sql_user_info_res = "SELECT * FROM FIPORTAL.PRD_USR_LST WHERE PRD_ID=? ";
		PreparedStatement _psu = _conn.prepareStatement(_sql_user_info_res);
		_psu.setInt(1, Integer.valueOf(taskId));
		ResultSet _rsu = _psu.executeQuery();
		TPrdUsrsLis _out = new TPrdUsrsLis();
		List<TUsrInfo>  _uitems = new ArrayList<TUsrInfo> ();
		while (_rsu.next()) {
			TUsrInfo _uitem = new TUsrInfo();
			_uitem.setId(_rsu.getString("PRD_USER_ID"));
			_uitem.setIdType(_rsu.getString("PRD_USER_ID_TYPE"));
			_uitem.setName(_rsu.getString("PRD_USER_NAME"));
			_uitem.setUsrType(_rsu.getString("PRD_USER_TYPE"));
			_uitems.add(_uitem);
		}
		
		_out.usrInfo = _uitems;
			return _out;
	}
	@Override
	public void deleteUser(int taskId,
			Connection _conn) throws SQLException {
		String sqlUserDelete = "DELETE FROM FIPORTAL.PRD_USR_LST where Task_ID = ?";
		PreparedStatement preparedStatement = _conn
				.prepareStatement(sqlUserDelete);
		preparedStatement.setInt(1, taskId);
		preparedStatement.executeUpdate();
	}

	@Override
	public void addUser(List<UserInfoResponseType> userInfoResponseTypeList,
			Connection conn, int taskId, int responseID, String prodcutType) throws SQLException {
		String sqlUserInsert = "INSERT INTO FIPORTAL.PRD_USR_LST (PRD_USR_LST_ID, PRD_ID, PRD_USER_NAME, PRD_TYPE, PRD_USER_ID_TYPE, PRD_USER_TYPE,PRD_USER_ID,TASK_ID) VALUES ( PRD_USR_LST_SEQ.NEXTVAL,?,?,?,?,?,?,?)";
		PreparedStatement preparedStatement = conn
				.prepareStatement(sqlUserInsert);

			for (UserInfoResponseType userInfoResponseType : userInfoResponseTypeList) {
				preparedStatement.setInt(1, responseID);
				preparedStatement.setString(2, userInfoResponseType.getName());
				preparedStatement.setString(3, prodcutType);
				preparedStatement.setString(4, userInfoResponseType.getIdType());
				preparedStatement.setString(5, userInfoResponseType.getUserType());
				preparedStatement.setString(6,userInfoResponseType.getUserId());
				preparedStatement.setInt(7,taskId);
				preparedStatement.executeUpdate();
			}
	}
	
}
