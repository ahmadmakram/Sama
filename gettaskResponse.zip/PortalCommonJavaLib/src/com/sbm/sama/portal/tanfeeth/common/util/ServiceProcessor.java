package com.sbm.sama.portal.tanfeeth.common.util;

import com.sbm.sama.portal.tanfeeth.common.enums.MainServiceCode;
import com.sbm.sama.portal.tanfeeth.common.enums.SubServiceCode;

public class ServiceProcessor {
	public static String getMainServiceName(String mainServiceCode) {
		switch (mainServiceCode) {
		case "001":
			return MainServiceCode._001.getServiceName();
		case "002":
			return MainServiceCode._002.getServiceName();
		default:
			return "";
		}
	}

	public static String getSubServiceName(String subServiceCode) {
		switch (subServiceCode) {
		case "01":
			return SubServiceCode._01.getServiceName();
		case "02":
			return SubServiceCode._02.getServiceName();
		case "03":
			return SubServiceCode._03.getServiceName();
		case "04":
			return SubServiceCode._04.getServiceName();
		case "05":
			return SubServiceCode._05.getServiceName();
		case "07":
			return SubServiceCode._07.getServiceName();
		case "08":
			return SubServiceCode._08.getServiceName();
		case "09":
			return SubServiceCode._09.getServiceName();
		case "10":
			return SubServiceCode._10.getServiceName();
		case "11":
			return SubServiceCode._11.getServiceName();
		case "12":
			return SubServiceCode._12.getServiceName();
		case "13":
			return SubServiceCode._13.getServiceName();
		case "14":
			return SubServiceCode._14.getServiceName();
		case "15":
			return SubServiceCode._15.getServiceName();
		default:
			return "";
		}
	}
}
