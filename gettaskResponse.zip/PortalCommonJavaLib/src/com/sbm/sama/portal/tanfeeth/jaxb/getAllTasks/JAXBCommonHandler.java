package com.sbm.sama.portal.tanfeeth.jaxb.getAllTasks;

import java.util.List;

import com.sbm.sama.portal.tanfeeth.jaxb.getAllTasks.GetAllTasksOutputType;
import com.sbm.sama.portal.tanfeeth.jaxb.getAllTasks.GetAllTasksRsType;

public class JAXBCommonHandler {
	public static void setAllTasksOutputList(GetAllTasksRsType response,
			List<GetAllTasksOutputType> getAllTasksOutput){
		response.getAllTasksOutput = getAllTasksOutput;
	}
	
	public static void setTotalRowsCount(GetAllTasksRsType response,
			int totalRowsCount){
		response.totalRowsCount = totalRowsCount;
	}
}
