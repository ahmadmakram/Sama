
--------------------------------------------------------
--  DDL for Table PRD_USR_LST
--------------------------------------------------------

  CREATE TABLE "FIPORTAL"."PRD_USR_LST" 
   (	"PRD_USR_LST_ID" NUMBER DEFAULT "FIPORTAL"."PRD_USR_LST_SEQ"."NEXTVAL", 
	"PRD_ID" NUMBER, 
	"PRD_TYPE" VARCHAR2(20 CHAR), 
	"PRD_USER_ID" VARCHAR2(24 CHAR), 
	"PRD_USER_ID_TYPE" VARCHAR2(20 CHAR), 
	"PRD_USER_TYPE" VARCHAR2(20 CHAR), 
	"PRD_USER_NAME" VARCHAR2(150 CHAR), 
	"TASK_ID" VARCHAR2(38 BYTE)
   );
--------------------------------------------------------
--  DDL for Index PRD_USR_LST_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FIPORTAL"."PRD_USR_LST_PK" ON "FIPORTAL"."PRD_USR_LST" ("PRD_USR_LST_ID") ;
--------------------------------------------------------
--  Constraints for Table PRD_USR_LST
--------------------------------------------------------

  ALTER TABLE "FIPORTAL"."PRD_USR_LST" MODIFY ("PRD_ID" NOT NULL ENABLE);
  ALTER TABLE "FIPORTAL"."PRD_USR_LST" MODIFY ("PRD_TYPE" NOT NULL ENABLE);
  ALTER TABLE "FIPORTAL"."PRD_USR_LST" ADD CONSTRAINT "PRD_USR_LST_PK" PRIMARY KEY ("PRD_USR_LST_ID");





