package com.sbm.sama.portal.tanfeeth.common.enums;

public enum AssignBusinessRule {
	OFFICER_ASSIGN ("1201"),
	MANAGER_ASSIGN ("2504"),
	FOLLOWER_OFFICER_Q ("3122"),
	FOLLOWER_OFFICER_INBOX("3202"),
	FOLLOWER_MANAGER_Q("3425"),
	FOLLOWER_MANAGER_INBOX("3505"),
	FOLLOWER_Q_OFFICER("3201"),
	FOLLOWER_Q_MANAGER("3504");
	
	String assignBusinessRule = null;
	
	AssignBusinessRule (String assignBusinessRule){
		this.assignBusinessRule = assignBusinessRule;
	}
	
	public String getValue(){
		return this.assignBusinessRule;
	}
}
