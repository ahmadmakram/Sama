package com.sbm.sama.portal.tanfeeth.common.enums;

public enum UserRole {
	OFFICER ("1"),
	MANAGER ("2"),
	FOLLOWER ("3");
	
	String userRole = null;
	
	UserRole (String userRole){
		this.userRole = userRole;
	}
	
	public String getUserRole(){
		return this.userRole;
	}
}
