package com.sbm.sama.fiportal.services.updatebulktasksstatus;

import java.sql.Connection;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;

import org.w3c.dom.Document;


import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;
import com.sbm.sama.fiportal.services.updatebulktasksstatus.dao.UpdateBulkTasksStatusDAOImpl;
import com.sbm.sama.portal.tanfeeth.common.constant.WorkflowStatus;
import com.sbm.sama.portal.tanfeeth.common.enums.StatusCode;
import com.sbm.sama.portal.tanfeeth.jaxb.common.UpdateBulkTasksObjectFactory;
import com.sbm.sama.portal.tanfeeth.jaxb.common.UpdateWorkflowTaskReqType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.CommonResType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.UpdateBulkTasksStatusRqType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.UpdateBulkTasksStatusRsType;

public class UpdateBulkTasksStatus_Request_Response_JavaCompute extends MbJavaComputeNode {

	protected static JAXBContext jaxbContext = null;

	public void onInitialize() throws MbException {
		try {
			jaxbContext = JAXBContext
					.newInstance(com.sbm.sama.portal.tanfeeth.jaxb.common.UpdateBulkTasksObjectFactory.class);
		} catch (JAXBException e) {
			// This exception will cause the deploy of this Java compute node to
			// fail
			// Typical cause is the JAXB package above is not available
			throw new MbUserException(this, "onInitialize()", "", "", e.getMessage(), null);
		}
	}

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");

		// obtain the input message data
		MbMessage inMessage = inAssembly.getMessage();

		// create a new empty output message
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);

		// optionally copy input message headers to the new output
		copyMessageHeaders(inMessage, outMessage);

		try {
			Connection _conn = getJDBCType4Connection("XE", JDBC_TransactionType.MB_TRANSACTION_AUTO);

			JAXBElement<UpdateBulkTasksStatusRqType> JAXUpdateBulkTasksStatusRq = jaxbContext
					.createUnmarshaller().unmarshal(
							inMessage.getRootElement().getLastChild().getLastChild().getDOMNode(),
							UpdateBulkTasksStatusRqType.class);
			UpdateBulkTasksStatusRqType _request = JAXUpdateBulkTasksStatusRq.getValue();

			UpdateBulkTasksStatusDAOImpl _dao = new UpdateBulkTasksStatusDAOImpl();
			UpdateWorkflowTaskReqType _input = _request.getUpdateBulkTasksStatusInput();
			CommonResType _output = new CommonResType();

		

				String updateRs = _dao.updateBulkTasksStatus(_input, _conn);
				StatusCode status= StatusCode.findByCode(updateRs);

				_output.setStatusCode(status.getCode());
				_output.setStatusMessage(status.getDesc());
			
			

			UpdateBulkTasksObjectFactory _objFac = new UpdateBulkTasksObjectFactory();
			UpdateBulkTasksStatusRsType UpdateBulkTasksStatusRs = _objFac.createUpdateBulkTasksStatusRsType();
			UpdateBulkTasksStatusRs.setUpdateBulkTasksStatusOutput(_output);

			JAXBElement<UpdateBulkTasksStatusRsType> _response = _objFac
					.createUpdateBulkTasksStatusRs(UpdateBulkTasksStatusRs);

			// TODO set the required Broker domain to for the output message, eg
			// XMLNSC
			Document outDocument = outMessage.createDOMDocument(MbXMLNSC.PARSER_NAME);
			// marshal the new or updated output Java object class into the
			// Broker tree
			jaxbContext.createMarshaller().marshal(_response, outDocument);

			if (status.equals(StatusCode.SUCCESS) && _input.getStatusId() == WorkflowStatus.MANAGER_SUBMIT) {

				MbElement envVars = outAssembly.getGlobalEnvironment().getRootElement()
						.getFirstElementByPath("Variables");
				MbElement taskListEl = envVars.createElementAsLastChild(MbXMLNSC.PARSER_NAME);
				taskListEl.setName("TaskList");

				for (int i = 0; i < _input.getTaskId().size(); i++) {
					MbElement taskEl = taskListEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "Task",
							null);
					taskEl.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "TaskId", _input.getTaskId()
							.get(i));
				}

				out = getOutputTerminal("alternate");
			}
			
			// The following should only be changed if not propagating message
			// to the node's 'out' terminal
			out.propagate(outAssembly);
			// if(_conn != null)_conn.close(); //let IIB handle it
			// mabdelrahamn
		} catch (Exception e) {
			// Example Exception handling
			e.printStackTrace();
			throw new MbUserException(this, "evaluate()", "", "", e.getMessage(), null);
		}
	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage) throws MbException {
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element and stopping before the last child (message body)
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) {
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}

}
