package com.sbm.sama.fiportal.services.updatetaskstatus.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.sbm.sama.portal.tanfeeth.jaxb.common.UpdateWorkflowTaskReqType;

public interface UpdateTaskStatusDAO {
	
	public String updateTaskStatus(UpdateWorkflowTaskReqType _input, Connection _conn) throws SQLException;

}
