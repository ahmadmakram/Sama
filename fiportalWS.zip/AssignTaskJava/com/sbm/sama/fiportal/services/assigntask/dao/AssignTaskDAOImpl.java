package com.sbm.sama.fiportal.services.assigntask.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.regex.*;

import com.sbm.sama.portal.tanfeeth.common.constant.WorkflowStatus;
import com.sbm.sama.portal.tanfeeth.common.dao.impl.CommonTaskDaoImpl;
import com.sbm.sama.portal.tanfeeth.common.enums.AssignBusinessRule;
import com.sbm.sama.portal.tanfeeth.common.enums.StatusCode;
import com.sbm.sama.portal.tanfeeth.common.util.WorkflowTaskBean;
import com.sbm.sama.portal.tanfeeth.jaxb.common.AssignTaskInputType;

public class AssignTaskDAOImpl implements AssignTaskDAO {

	@Override
	public String assignTask(AssignTaskInputType _input, Connection _conn) throws SQLException {
		String _output = StatusCode.FATAL_ERROR.getCode();

	    Pattern pattern = Pattern.compile("[9]{1}[0]{1}[0]{1}[0-9]{2}");
	    Matcher userFID = pattern.matcher(_input.getAssignedToUserId());

		List<Integer> _task_id_list = _input.getTaskId();
		for (int i = 0; i < _task_id_list.size(); i++) {
			CommonTaskDaoImpl ctdi = new CommonTaskDaoImpl();

			WorkflowTaskBean wfti = ctdi.selectTask(_conn, _input.getTaskId().get(i));			

		    String PID = wfti.getPid();
		    if (userFID.find()){
		    	if(!(PID.equalsIgnoreCase(userFID.group(0)))){
		    		_output = StatusCode.NOT_VALID_ACTION.getCode();
					return _output;
		    	}
		    }else{
		    	_output = StatusCode.NOT_VALID_ACTION.getCode();
				return _output;
		    }


			String inputAction = _input.getAssignedByRoleId() + _input.getStatusId()
					+ _input.getSubStatusId() + wfti.getStatusId();
			// US4:Prevent manager to assign bulk tasks
			if (wfti.getIsBulkProcessed().equalsIgnoreCase("YES")) {
				_output = StatusCode.UNABLE_TO_ASSIGN_BULK_TASK.getCode();
				return _output;
			}

			if (!(inputAction.equals(AssignBusinessRule.FOLLOWER_MANAGER_INBOX.getValue())
					|| inputAction.equals(AssignBusinessRule.FOLLOWER_MANAGER_Q.getValue())
					|| inputAction.equals(AssignBusinessRule.FOLLOWER_OFFICER_INBOX.getValue())
					|| inputAction.equals(AssignBusinessRule.FOLLOWER_OFFICER_Q.getValue())
					|| inputAction.equals(AssignBusinessRule.MANAGER_ASSIGN.getValue()) 
					|| inputAction.equals(AssignBusinessRule.OFFICER_ASSIGN.getValue())
					|| inputAction.equals(AssignBusinessRule.FOLLOWER_Q_OFFICER.getValue())
					|| inputAction.equals(AssignBusinessRule.FOLLOWER_Q_MANAGER.getValue())
					)) 
			{
				_output = StatusCode.NOT_VALID_ACTION.getCode();
				return _output;
			}

			if (_input.getStatusId() == WorkflowStatus.OFFICER_QUEUE
					|| _input.getStatusId() == WorkflowStatus.MANAGER_QUEUE) {
				wfti.setLastAssignedTo(wfti.getAssignedTo());
				wfti.setAssignedTo(null);
			} else {
				wfti.setLastAssignedTo(wfti.getAssignedTo());
				wfti.setAssignedTo(_input.getAssignedToUserId());
			}

			wfti.setAssignedBy(_input.getAssignedByUserId());
			wfti.setAssignedByRole(_input.getAssignedByRoleId());

			wfti.setStatusId(_input.getStatusId());
			wfti.setNotes(null);

			Timestamp currentTime = new Timestamp(System.currentTimeMillis());
			wfti.setAssignedDateTime(currentTime);

			ctdi.updateTask(_conn, wfti);
			_output = StatusCode.SUCCESS.getCode();
		}

		return _output;
	}
}
