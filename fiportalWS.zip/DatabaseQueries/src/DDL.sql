
CREATE SEQUENCE "FIPORTAL"."EXEC_ACC_INFO_SEQ" MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1;

CREATE TABLE "FIPORTAL"."EXEC_ACC_INFO" (
    "ID"                  NUMBER DEFAULT "FIPORTAL"."EXEC_ACC_INFO_SEQ"."NEXTVAL",
    "TASK_ID"             NUMBER
        NOT NULL ENABLE,
    "ACC_NUM"             VARCHAR2(24 CHAR)
        NOT NULL ENABLE,
    "IBAN"                VARCHAR2(24 CHAR)
        NOT NULL ENABLE,
    "INST"                VARCHAR2(100 CHAR),
    "JNT_ACC"             VARCHAR2(1 CHAR)
        NOT NULL ENABLE,
    "ACC_CUR"             VARCHAR2(3 CHAR)
        NOT NULL ENABLE,
    "SRC_AMT"             FLOAT(126)
        NOT NULL ENABLE,
    "EXEC_AMT"            FLOAT(126)
        NOT NULL ENABLE,
    "FX_RATE"             FLOAT(126)
        NOT NULL ENABLE,
    "EXEC_DATE"           DATE
        NOT NULL ENABLE,
    "TRANSFER_REF_NO"     VARCHAR2(24 CHAR),
    "TRANSFER_STATUS"     VARCHAR2(2 CHAR),
    "CREATED_DATE_TIME"   TIMESTAMP(6),
    CONSTRAINT "EXEC_ACC_INFO_PK" PRIMARY KEY ( "ID" )
        USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255
);

ALTER TABLE "FIPORTAL"."EXEC_ACC_INFO" ADD CONSTRAINT "EXEC_ACC_INFO_FK1" FOREIGN KEY ( "TASK_ID" )
    REFERENCES "FIPORTAL"."WORKFLOW_TASK" ( "ID" );
---------------------------------------------------------------------------------------------------------------------------------------        
        
ALTER TABLE BAN_DEALING_RESPONSE DROP COLUMN IS_DELETED;
ALTER TABLE DENY_DEALING_RESPONSE DROP COLUMN IS_DELETED;
ALTER TABLE BLOCK_RESPONSE DROP COLUMN EXE_DTTM;

------------------------------------------------------------------------------------------------------------------------------------------------

   CREATE SEQUENCE  "FIPORTAL"."PRD_JNT_ACCTS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 ;

   CREATE SEQUENCE  "FIPORTAL"."BLOCK_RESPONSE_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 ;

   CREATE SEQUENCE  "FIPORTAL"."DENY_DEALING_RESPONSE_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 ;

   CREATE SEQUENCE  "FIPORTAL"."BAN_DEALING_RESPONSE_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 ;
   CREATE SEQUENCE  "FIPORTAL"."EXEC_ACC_INFO_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 ;

   
--------------------------------------------------------
--  DDL for  PRD_JNT_ACCTS
--------------------------------------------------------
CREATE TABLE "FIPORTAL"."PRD_JNT_ACCTS" (
    "PRD_JNT_ACCTS_ID"   NUMBER DEFAULT "FIPORTAL"."PRD_JNT_ACCTS_SEQ"."NEXTVAL",
    "PRD_ID"             NUMBER
        NOT NULL ENABLE,
    "PRD_TYPE"           VARCHAR2(20 CHAR)
        NOT NULL ENABLE,
    "ACC_NUM"            VARCHAR2(24 CHAR)
        NOT NULL ENABLE,
    "IBAN"               VARCHAR2(24 CHAR)
        NOT NULL ENABLE,
    "TASK_ID"            NUMBER
        NOT NULL ENABLE,
    CONSTRAINT "PRD_JNT_ACCTS_PK" PRIMARY KEY ( "PRD_JNT_ACCTS_ID" )
        USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255
)

  CREATE UNIQUE INDEX "FIPORTAL"."PRD_JNT_ACCTS_PK" ON "FIPORTAL"."PRD_JNT_ACCTS" ("PRD_JNT_ACCTS_ID") ;
 
  --------------------------------------------------------
--  DDL for Table BLOCK_RESPONSE
--------------------------------------------------------
CREATE TABLE "FIPORTAL"."BLOCK_RESPONSE" (
    "ID"                    NUMBER(*,0)
        NOT NULL ENABLE,
    "TASK_ID"               NUMBER(*,0),
    "CUST_NAME"             VARCHAR2(100 BYTE),
    "CUST_ID"               VARCHAR2(20 BYTE),
    "CUST_IDTYPE"           VARCHAR2(10 BYTE),
    "CUST_NTNLTY"           VARCHAR2(3 BYTE),
    "CREATED_DATE_TIME"     TIMESTAMP(6),
    "SMRY_INFO_PNDNG_AMT"   NUMBER(*,0) DEFAULT 0,
    "SMRY_INFO_TOT_AMT"     NUMBER(*,0) DEFAULT 0,
    CONSTRAINT "DENY_RESP_ID1" PRIMARY KEY ( "ID" )
        USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
)

CREATE INDEX "FIPORTAL"."DENY_RESP_REQ_ID1" ON
    "FIPORTAL"."BLOCK_RESPONSE" ( "TASK_ID" )
        PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS TABLESPACE "FIPORTAL_TABSPACE";

--------------------------------------------------------
--  DDL for Index BLOCK_RESPONSE_REQ_ID
--------------------------------------------------------

  CREATE INDEX "FIPORTAL"."BLOCK_RESPONSE_REQ_ID" ON "FIPORTAL"."BLOCK_RESPONSE" ("TASK_ID") ;
--------------------------------------------------------
--  DDL for Index BLOCK_RESPONSE_ID
--------------------------------------------------------

  CREATE UNIQUE INDEX "FIPORTAL"."BLOCK_RESPONSE_ID" ON "FIPORTAL"."BLOCK_RESPONSE" ("ID") ;
  
  ----------------------Alter table block --------------------------------------------------------
  
Alter table block_response
Add SAR_TOTAL_AMT FLOAT;


Alter table block_response
Add RQ_TOTAL_AMT FLOAT;

Alter table block_response
Add HAS_ACC_FLAG VARCHAR2(1 BYTE);

Alter table block_response
Add HAS_SAFS_FLAG VARCHAR2(1 BYTE);

Alter table block_response
Add HAS_JNT_ACC_FLAG VARCHAR2(1 BYTE);

Alter table block_response
Add HAS_JNT_DEPOST_FLAG VARCHAR2(1 BYTE);

Alter table block_response
Add HAS_SHRS_FLAG VARCHAR2(1 BYTE);

Alter table block_response
Add SAFS_EXE_DATE_TIME DATE;
 --------------------------------------------------------
  
 --------------------------------------------------------
--  DDL for Table LIFT_RESPONSE
--------------------------------------------------------

CREATE TABLE "FIPORTAL"."LIFT_RESPONSE" (
    "ID"                  NUMBER
        NOT NULL ENABLE,
    "TASK_ID"             NUMBER,
    "CUST_NAME"           VARCHAR2(100 CHAR),
    "CUST_ID"             VARCHAR2(20 CHAR),
    "CUST_ID_TYPE"        VARCHAR2(10 CHAR),
    "CUST_NAT_CD"         VARCHAR2(3 CHAR),
    "EXE_DATE_TIME"       DATE
        NOT NULL ENABLE,
    "TOTAL_TRANS_AMT"     FLOAT(126),
    "TOTAL_BLOCK_AMT"     FLOAT(126),
    "PENDING_AMT"         FLOAT(126),
    "CREATED_DATE_TIME"   TIMESTAMP(6),
    CONSTRAINT "LIFT_RESPONSE_PK" PRIMARY KEY ( "ID" )
        USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 );
 
 --------------------------------------------------------
--  DDL for LIFT_RESPONSE Sequence
--------------------------------------------------------        
CREATE SEQUENCE  "FIPORTAL"."Lift_DEALING_RESPONSE_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 101;      
--------------------------------------------------------
 --------------------------------------------------------
--  Alter LIFT_RESPONSE table
--------------------------------------------------------      
alter table LIFT_RESPONSE DROP column PENDING_AMT;
--------------------------------------------------------

--  DDL for Table GARNISH_RESPONSE
--------------------------------------------------------
CREATE TABLE "FIPORTAL"."GARNISH_RESPONSE" (
    "ID"                  NUMBER,
    "TASK_ID"             NUMBER
        NOT NULL ENABLE,
    "CUST_NAME"           VARCHAR2(100 CHAR),
    "CUST_ID"             VARCHAR2(20 CHAR),
    "CUST_ID_TYPE"        VARCHAR2(10 CHAR),
    "CUST_NAT_CD"         VARCHAR2(3 CHAR),
    "EXE_DATE_TIME"       DATE
        NOT NULL ENABLE,
    "TOTAL_AMT"           FLOAT(126),
    "PENDING_AMT"         FLOAT(126),
    "CREATED_DATE_TIME"   TIMESTAMP(6),
    CONSTRAINT "GARNISH_RESPONSE_PK" PRIMARY KEY ( "ID" )
        USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255
);
--------------------------------------------------------
--  DDL for Index GARNISH_EXEC_RESP_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "FIPORTAL"."GARNISH_RESPONSE_PK" ON "FIPORTAL"."GARNISH_RESPONSE"  ("ID")  ;
----------------------------------------------------------------------------------------------------------------
-- GRANT ACCESS to WCR on BAN Service
----------------------------------------------------------------------------------------------------------------

Grant select,insert,update,delete on FIPORTAL.BAN_DEALING_RESPONSE to wcr;

Grant select on FIPORTAL.BAN_DEALING_RESPONSE_ID_SEQ to wcr;

----------------------------------------------------------------------------------------------------------------

-- GRANT access to WCR on Deny service
----------------------------------------------------------------------------------------------------------------

Grant select,insert,update,delete on FIPORTAL.DENY_DEALING_RESPONSE to wcr;

Grant select on FIPORTAL.DENY_DEALING_RESPONSE_ID_SEQ to wcr;

----------------------------------------------------------------------------------------------------------------

  