package com.sbm.sama.portal.getTask.dao.impl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.getTask.dao.TaskDao;
import com.sbm.sama.portal.tanfeeth.common.constant.ServiceCode;
import com.sbm.sama.portal.tanfeeth.common.util.FieldsProcessing;
import com.sbm.sama.portal.tanfeeth.common.util.ServiceProcessor;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetTaskInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetTaskOutputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.InvolvedEntityType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.JAXBProtectedHandler;
import com.sbm.sama.portal.tanfeeth.jaxb.common.LiftRestrictionInfoType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.RelatedTaskInfoType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.RelatedTaskListType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.RequestMetadataType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TAccId;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TAccQry;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TAmt;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TBanDlngOutline;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TBenf;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TBlockDcsnInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TBlockFundXfer;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TBlockLiftCndtn;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TChamber;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TCharity;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TCorporate;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TDenyDlngOutline;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TDepot;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TDlngDcsnInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TDrtn;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TExePlan;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TExeTrgtPrds;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFIBlockOutline;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFIGarnishOutline;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFILiftExePlan;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFILiftFull;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TFILiftOutline;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TGarnishDcsnInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TGovernment;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TIndividual;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TInvPrty;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TLiftDcsnInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TLiftPart;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TPreTanfeeth;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TReqExeInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TReqInqInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TSrvcRefInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TTanfeeth;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TaskType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.WorkflowStatusHistoryType;

public class TaskDaoImpl implements TaskDao {

	@Override
	public GetTaskOutputType GetTask(GetTaskInputType _input, Connection _conn) throws SQLException,
			DatatypeConfigurationException {
		int _filter_index = 0;

		String _sql_tsk = "SELECT * FROM FIPORTAL.TANFEETH_TASK_DETAILS_VIEW WHERE TASK_ID=?";
		String _sql_acct_info_req = "SELECT ACC_INFO_REQST_ID,AGCY_SRVC_REQST_ID,ACC_NO,IBAN from tanfeeth.ACC_INFO_REQST WHERE AGCY_SRVC_REQST_ID=?";
		String _sql_bala_info_req = "SELECT ACC_BAL_INFO_REQST_ID,AGCY_SRVC_REQST_ID,ACC_NO,iban from tanfeeth.ACC_BAL_INFO_REQST where AGCY_SRVC_REQST_ID = ?";
		String _sql_depo_info_req = "SELECT DEPOSIT_INFO_REQST_ID,AGCY_SRVC_REQST_ID,DEPOSIIT_NO from tanfeeth.DEPOSIT_INFO_REQST where AGCY_SRVC_REQST_ID = ?";
		String _sql_liab_info_req = "SELECT LIAB_INFO_REQST_ID,AGCY_SRVC_REQST_ID from tanfeeth.LIAB_INFO_REQST where AGCY_SRVC_REQST_ID = ?";
		String _sql_safe_info_req = "SELECT SAFE_INFO_REQST_ID,AGCY_SRVC_REQST_ID,BOX_NO from tanfeeth.SAFE_INFO_REQST where AGCY_SRVC_REQST_ID = ?";
		String sqlBanInfoReq = "SELECT DECISION_ISSUE_DATE,DECISION_NUMBER from tanfeeth.BAN_EXEC_REQST where AGCY_SRVC_REQST_ID = ?";
		String sqlDenyInfoReq = "SELECT DECISION_ISSUE_DATE,DECISION_NUMBER from tanfeeth.DENY_EXEC_REQST where AGCY_SRVC_REQST_ID = ?";
		String sqlLiftReq = "SELECT DCSN_NUM,DCSN_DATE,LETTER_RN,SAMANET_RN,RRN,PREV_SRN,AMT,BENF_NAME,BENF_BIC,BENF_IBAN,LIFT_TYPE,BAI_NUM,BAI_BIC,BAI_IBAN,DEPOT_BIC,DEPOT_NUM FROM tanfeeth.LIFT_EXEC_REQST where AGCY_SRVC_REQST_ID = ?";
		String sqlBlockReq = "SELECT DCSN_NUM,DCSN_DATE,DBT_TYPE,AMT_VAL,AMT_CUR,BAI_NUM,BAI_IBAN,BAI_BIC,ACC_FLAG,DEPOST_FLAG,SAFS_FLAG  FROM tanfeeth.BLOCK_EXEC_REQST where AGCY_SRVC_REQST_ID = ?";
		String sqlGarnishReq = "SELECT DCSN_NUM,DCSN_DATE,CASE_TYPE,DURATION_TYPE,START_DATE,PERIOD,END_DATE,AMT_VAL,AMT_CUR,BAI_NUM,BAI_IBAN,BAI_BIC,ACC_FLAG,DEPOST_FLAG,SAFS_FLAG  FROM tanfeeth.GARNISH_EXEC_REQST where AGCY_SRVC_REQST_ID = ?";

		String _sql_task_status_events = "SELECT DISTINCT TASK_ID, STATUS_ID, SUB_STATUS_ID, EVENT_DATE_TIME, EXECUTED_BY, EXECUTED_BY_ROLE, NOTES FROM FIPORTAL.WORKFLOW_STATUS_EVENT_HISTORY WHERE TASK_ID=? AND NOTES IS NOT NULL ORDER BY event_date_time DESC";
		
		String request_metadataID = "";
		if (_input.getFiId() != null)
			_sql_tsk += " AND FI_ID=?";

		GetTaskOutputType _output = new GetTaskOutputType();
		TaskType _task = new TaskType();
		RequestMetadataType _request_metadata = new RequestMetadataType();

		PreparedStatement _ps = _conn.prepareStatement(_sql_tsk);
		_ps.setString(++_filter_index, _input.getTaskId());
		if (_input.getFiId() != null)
			_ps.setString(++_filter_index, _input.getFiId());

		ResultSet _rs = _ps.executeQuery();
		List<InvolvedEntityType> _itemlist = new ArrayList<InvolvedEntityType>();
		
		String msgUId = "";
		while (_rs.next()) {
			msgUId = _rs.getString("MSGUID");
			_task.setTaskId(_rs.getInt("TASK_ID"));
			_task.setFiId(_rs.getString("FI_ID"));
			_task.setCreatedDateTime(FieldsProcessing.getXMLGregCal(_rs
					.getTimestamp("TASK_CREATED_DATE_TIME")));
			_task.setDueDateTime(FieldsProcessing.getXMLGregCal(_rs.getTimestamp("DUE_DATE_TIME")));

			_task.setIsBulkProcessed((_rs.getString("IS_BULK_PROCESSED").equalsIgnoreCase("YES") ? true
					: false));
			
			if (_rs.getString("TASK_MODE") != null){
				_task.setTaskMode(_rs.getString("TASK_MODE"));
			}else{
				_task.setTaskMode("NOR");
			}

			request_metadataID = _rs.getString("TASK_REQUEST_METADATA_ID");

			_request_metadata.setMainServiceCode(_rs.getString("MAIN_SERVICE_TYPE_CODE"));

			_request_metadata.setSubServiceCode(_rs.getString("SUB_SERVICE_TYPE_CODE"));
			_request_metadata.setGovId(_rs.getInt("ENTITY_GOV_ID"));

			_request_metadata.setReceiveDateTime(FieldsProcessing.getXMLGregCal(_rs
					.getTimestamp("REQUEST_CREATED_DATE_TIME")));
			_request_metadata.setRequesterGeoLocation(_rs.getString("REQUESTER_GEO_LOC"));
			String _geo_loc_desc = _rs.getString("REQUESTER_GEO_LOC_DESC");
			if (_geo_loc_desc != null) {
				String[] _geo_loc_values = _geo_loc_desc.split("-");

				if (_geo_loc_values.length > 0) {
					_request_metadata.setRequesterRegion(_geo_loc_values[0]);
				}
				if (_geo_loc_values.length > 1) {
					_request_metadata.setRequesterCity(_geo_loc_values[1]);
				}
				if (_geo_loc_values.length > 2) {
					_request_metadata.setRequesterDepartment(_geo_loc_values[2]);
				}
				if (_geo_loc_values.length > 3) {
					_request_metadata.setRequesterDepartmentType(_geo_loc_values[3]);
				}
			}

			InvolvedEntityType involvedEntityTypeItem = new InvolvedEntityType();
			involvedEntityTypeItem.setName(_rs.getString("NAME"));
			involvedEntityTypeItem.setIdType(_rs.getString("ID_TYPE_TITLE"));
			involvedEntityTypeItem.setIdNo(_rs.getString("ID_NO"));
			involvedEntityTypeItem.setEntityType(_rs.getString("TYPE_CODE"));
			involvedEntityTypeItem.setNationality(_rs.getString("NATIONALITY_TITLE"));
			if (involvedEntityTypeItem.getName() != null)
				_itemlist.add(involvedEntityTypeItem);

			// _request_metadata.setRequesterGeoArea(_rs.getString(""));
			// _request_metadata.setRequesterDepartment(_rs.getString("REQUESTER_DEPARTMENT"));
			_request_metadata.setRequesterPosition(_rs.getString("REQUESTER_POSITION"));
			_request_metadata.setRequesterName(_rs.getString("REQUESTER_NAME"));
			_request_metadata.setConfidentLevelId(_rs.getString("CONFIDENT_LEVEL_ID"));
			_request_metadata.setRequestClassification(_rs.getString("REQUEST_CLASSIFICATION"));
			_request_metadata.setSRN(_rs.getString("SRN"));// _rs.getString("SRN")
			_request_metadata.setRRN(_rs.getString("RRN"));// _rs.getString("SRN")

			if (_itemlist.size() > 0) {
				// _request_metadata.involvedEntityList = _itemlist;
				JAXBProtectedHandler.setRMInvolvedEntityType(_request_metadata, _itemlist);
			} else {
				// _request_metadata.involvedEntityList = null;
				JAXBProtectedHandler.setRMInvolvedEntityType(_request_metadata, null);
			}

			PreparedStatement _psts = _conn.prepareStatement(_sql_task_status_events);
			_psts.setInt(1, Integer.valueOf(_input.getTaskId()));
			ResultSet _rsts = _psts.executeQuery();
			List<WorkflowStatusHistoryType> _hitemlist = new ArrayList<WorkflowStatusHistoryType>();
			while (_rsts.next()) {
				WorkflowStatusHistoryType _item = new WorkflowStatusHistoryType();
				_item.setTaskId(_rsts.getInt("TASK_ID"));
				_item.setTaskStatusId(_rsts.getInt("STATUS_ID"));
				_item.setTaskSubStatusId(_rsts.getInt("SUB_STATUS_ID"));
				_item.setEventDateTime(FieldsProcessing.getXMLGregCal(_rsts.getTimestamp("EVENT_DATE_TIME")));
				_item.setExecutedBy(_rsts.getString("EXECUTED_BY"));
				_item.setExecutedByRole(_rsts.getString("EXECUTED_BY_ROLE"));
				_item.setNotes(_rsts.getString("NOTES"));
				_hitemlist.add(_item);
			}
			// _task.workflowStatusHistory = _hitemlist;
			JAXBProtectedHandler.setWorkFlowStatusHistory(_task, _hitemlist);
			_rsts.close();
			_psts.close();

			String subServiceCode = _rs.getString("SUB_SERVICE_TYPE_CODE");
			String mainServiceCode = _rs.getString("MAIN_SERVICE_TYPE_CODE");

			if (mainServiceCode != null) {
				_request_metadata.setMainServiceCode(ServiceProcessor.getMainServiceName(mainServiceCode));
			}

			if (subServiceCode != null) {
				_request_metadata.setSubServiceCode(ServiceProcessor.getSubServiceName(subServiceCode));
			}

			if (subServiceCode.equals(ServiceCode.ACC)) {
				PreparedStatement _psr = _conn.prepareStatement(_sql_acct_info_req);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
				TAccQry _itemAccQ = new TAccQry();

				while (_rsr.next()) {
					_itemAccQ.setAccNum(_rsr.getString("ACC_NO"));
					_itemAccQ.setIBAN(_rsr.getString("IBAN"));
				}
			
				_request_metadata.setAccQry(_itemAccQ);
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.BAL)) {
				PreparedStatement _psr = _conn.prepareStatement(_sql_bala_info_req);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
				TAccQry _itemAccQ = new TAccQry();

					while (_rsr.next()) {

						_itemAccQ.setAccNum(_rsr.getString("ACC_NO"));
					_itemAccQ.setIBAN(_rsr.getString("IBAN"));
				}
					_request_metadata.setAccQry(_itemAccQ);

			
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.DEP)) {
				PreparedStatement _psr = _conn.prepareStatement(_sql_depo_info_req);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
				while (_rsr.next()) {
					_request_metadata.setDepotQry(_rsr.getString("DEPOSIIT_NO"));
				}
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.LIAB)) {
				PreparedStatement _psr = _conn.prepareStatement(_sql_liab_info_req);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
			
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.SAF)) {
				PreparedStatement _psr = _conn.prepareStatement(_sql_safe_info_req);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();

				while (_rsr.next()) {
					_request_metadata.setSafQry(_rsr.getString("BOX_NO"));
				}
				
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.DENY)) {
				PreparedStatement _psr = _conn.prepareStatement(sqlDenyInfoReq);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
				TDlngDcsnInfo _item = new TDlngDcsnInfo();
				TDenyDlngOutline denyDlngOutline = new TDenyDlngOutline();
				while (_rsr.next()) {
					_item.setNum(_rsr.getString("DECISION_NUMBER"));
					_item.setDt(_rsr.getDate("DECISION_ISSUE_DATE").toString());

				}
				denyDlngOutline.setDcsnInfo(_item);
				_request_metadata.setDenyOutline(denyDlngOutline);
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.BAN)) {
				PreparedStatement _psr = _conn.prepareStatement(sqlBanInfoReq);
				_psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = _psr.executeQuery();
				TBanDlngOutline banDlngOutline = new TBanDlngOutline();
				TDlngDcsnInfo _item = new TDlngDcsnInfo();
				while (_rsr.next()) {
					_item.setNum(_rsr.getString("DECISION_NUMBER"));
					_item.setDt(_rsr.getDate("DECISION_ISSUE_DATE").toString());
				}
				 banDlngOutline.setDcsnInfo(_item);
				_request_metadata.setBanOutline(banDlngOutline);
				_rsr.close();
				_psr.close();
			} else if (subServiceCode.equals(ServiceCode.L_GAR)
					|| subServiceCode.equals(ServiceCode.L_DENY) || subServiceCode.equals(ServiceCode.L_BAN)
					||subServiceCode.equals(ServiceCode.L_BLOCK)) {// LiftBanExe
				PreparedStatement psr = _conn.prepareStatement(sqlLiftReq);
				psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet _rsr = psr.executeQuery();
				
				LiftRestrictionInfoType _item = new LiftRestrictionInfoType();
				TLiftDcsnInfo tLiftDcsnInfo = new TLiftDcsnInfo();
				
				
				TFILiftExePlan liftExePlan = new TFILiftExePlan();
				
				TSrvcRefInfo tSrvcRefInfo = new TSrvcRefInfo();
				TBlockLiftCndtn tBlockLiftCndtn = new TBlockLiftCndtn();
				
				
				TBlockFundXfer fundXfer = new TBlockFundXfer();
				TBenf tBenf = new TBenf();
				
				TFILiftOutline liftOutline = new TFILiftOutline();

				while (_rsr.next()) {
					tLiftDcsnInfo.setDt(_rsr.getDate("DCSN_DATE").toString());
					tLiftDcsnInfo.setNum(_rsr.getString("DCSN_NUM"));
					if(_rsr.getString("PREV_SRN") != null){
						TTanfeeth tTanfeeth = new TTanfeeth(); 
						tTanfeeth.setSRN(_rsr.getString("PREV_SRN"));
						tSrvcRefInfo.setTanfeeth(tTanfeeth);
					}else{
						TPreTanfeeth tPreTanfeeth = new TPreTanfeeth();
						tPreTanfeeth.setLtrRN(_rsr.getString("LETTER_RN"));
						tPreTanfeeth.setSnetRN(_rsr.getString("SAMANET_RN"));
						tSrvcRefInfo.setPreTanfeeth(tPreTanfeeth);
					}
//					tTanfeeth.setRRN(_rsr.getString("RRN"));
					tBenf.setBIC(_rsr.getString("BENF_BIC"));
					tBenf.setIBAN(_rsr.getString("BENF_IBAN"));
					tBenf.setName(_rsr.getString("BENF_NAME"));
//					fundXfer.setAmt(_rsr.getBigDecimal("AMT"));
					ServiceOutline serviceOutline=getOutlineExtra(_conn,msgUId);
					fundXfer.setAmt(serviceOutline.getAmtVal());
					fundXfer.setBenf(tBenf);
					if(fundXfer.getAmt() != null || fundXfer.getBenf().getBIC() != null || 
							fundXfer.getBenf().getIBAN() != null|| fundXfer.getBenf().getName() != null){
						tBlockLiftCndtn.setFundXfer(fundXfer);
						liftOutline.setBlockLiftCndtn(tBlockLiftCndtn);
					}
					if(_rsr.getString("LIFT_TYPE")!= null &&_rsr.getString("LIFT_TYPE").equalsIgnoreCase("PLFT")){
						TLiftPart liftPart = new TLiftPart();
						if(_rsr.getString("BAI_NUM") != null){
							TAccId accId = new TAccId();
							accId.setNum(_rsr.getString("BAI_NUM"));
							accId.setIBAN(_rsr.getString("BAI_IBAN"));
							accId.setBIC(_rsr.getString("BAI_BIC"));
							liftPart.setAccId(accId);
						}else{
							TDepot tDepot = new TDepot();
							tDepot.setBIC(_rsr.getString("DEPOT_BIC"));
							tDepot.setNum(_rsr.getString("DEPOT_NUM"));
							liftPart.setDepot(tDepot);
						}
						liftExePlan.setPart(liftPart);
					}else{
						TFILiftFull liftFull = new TFILiftFull();
						if(_rsr.getString("BAI_NUM") != null && subServiceCode.equals(ServiceCode.L_GAR)){
							TAccId accId = new TAccId();
							accId.setNum(_rsr.getString("BAI_NUM"));
							accId.setIBAN(_rsr.getString("BAI_IBAN"));
							accId.setBIC(_rsr.getString("BAI_BIC"));
							liftFull.setAccId(accId);
						}else{
							TInvPrty invPrty = new TInvPrty();
							switch(involvedEntityTypeItem.getEntityType()){
							case "GOV" :
								TGovernment government = new TGovernment();
								government.setId(involvedEntityTypeItem.getIdNo());
								government.setIdType(involvedEntityTypeItem.getIdType());
								government.setName(involvedEntityTypeItem.getName());
								invPrty.setGov(government);
							break;
							
							case "IND":
								TIndividual individual = new TIndividual();
								individual.setId(involvedEntityTypeItem.getIdNo());
								individual.setIdType(involvedEntityTypeItem.getIdType());
								
								String firstName = "";
						        String scndName = "";
						        String thrdName = "";
						        String lastName = "";

						        String partyName [] = involvedEntityTypeItem.getName().split(" ");
						        
								for (int i=0; i < partyName.length; i++) { 
						            if(i == 0) {
						                firstName = partyName[i];
						            }else if(i == 1) {
						                scndName = partyName[i];
						            }else if(i == 2) {
						            	thrdName = partyName[i];
						            }else if(i == 3){
						            	lastName = partyName[i];
						                break;
						            }
								}
								individual.setFrstName(firstName);
								individual.setScndName(scndName);
								individual.setThrdName(thrdName);
								individual.setLstName(lastName);
								
								individual.setNtnlty(involvedEntityTypeItem.getNationality());
								invPrty.setIndv(individual);
							break;
							
							case "CAP":
								TCharity charity = new TCharity();
								charity.setId(involvedEntityTypeItem.getIdNo());
								charity.setIdType(involvedEntityTypeItem.getIdType());
								charity.setName(involvedEntityTypeItem.getName());
								invPrty.setChrty(charity);
							break;
							 case "COC":
								 TChamber chamber = new TChamber();
								 chamber.setId(involvedEntityTypeItem.getIdNo());
								 chamber.setIdType(involvedEntityTypeItem.getIdType());
								 chamber.setName(involvedEntityTypeItem.getName());
								 invPrty.setChmbr(chamber);
							 break;
							 case "CES":
								 TCorporate crporate = new TCorporate();
								 crporate.setId(involvedEntityTypeItem.getIdNo());
								 crporate.setIdType(involvedEntityTypeItem.getIdType());
								 crporate.setName(involvedEntityTypeItem.getName());
								 invPrty.setCorp(crporate);
							 break;
							default :
								System.out.println("Wrong code");
							}
							liftFull.setInvPrty(invPrty);
						}
						liftExePlan.setFull(liftFull);
					}
					
				}

				_item.setDcsnInfo(tLiftDcsnInfo);
				liftOutline.setSrvcRefInfo(tSrvcRefInfo);
				liftOutline.setDcsnInfo(tLiftDcsnInfo);
				liftOutline.setExePlan(liftExePlan);
				if(tSrvcRefInfo.getTanfeeth()!=null){
					RelatedTaskListType relatedTasks= getRealtedTask(_conn,tSrvcRefInfo.getTanfeeth().getSRN(),_task.getTaskId(),_task.getFiId());
					_task.setRelatedTaskList(relatedTasks);
				}
				_request_metadata.setLiftOutline(liftOutline);
				_rsr.close();
				psr.close();
			} else if (subServiceCode.equals(ServiceCode.BLOCK)) {

				PreparedStatement psr = _conn.prepareStatement(sqlBlockReq);
				psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet rsr = psr.executeQuery();
				TFIBlockOutline blockOutline = new TFIBlockOutline();
				
				TAccId tAccId = new TAccId();
				TAmt tAmt = new TAmt();
				TBlockDcsnInfo blockDcsnInfo = new TBlockDcsnInfo();
				TExePlan    exePlan = new TExePlan();
				TExeTrgtPrds exeTrgtPrds= new TExeTrgtPrds();
				
				while (rsr.next()) {
					tAccId.setNum( rsr.getString("BAI_NUM"));
					tAccId.setIBAN(rsr.getString("BAI_IBAN"));					
					tAccId.setBIC(rsr.getString("BAI_BIC"));
					
					exeTrgtPrds.setAccts(rsr.getString("ACC_FLAG"));
					exeTrgtPrds.setDepots(rsr.getString("DEPOST_FLAG"));
					exeTrgtPrds.setSafs(rsr.getString("SAFS_FLAG"));

					blockDcsnInfo.setDbtType(rsr.getString("DBT_TYPE"));
					blockDcsnInfo.setDt(rsr.getDate("DCSN_DATE").toString());
					blockDcsnInfo.setNum(rsr.getString("DCSN_NUM"));
					
					tAmt.setCur(rsr.getString("AMT_CUR"));					
				}

				if(tAccId.getNum()!= null){
					exePlan.setAccId(tAccId);
				}else{
					exePlan.setTrgtPrds(exeTrgtPrds);
				}	
				blockOutline.setExePlan(exePlan);

				ServiceOutline serviceOutline=getOutlineExtra(_conn,msgUId);
				tAmt.setVal(serviceOutline.getAmtVal());
				blockDcsnInfo.setAmt(tAmt);
				blockOutline.setDcsnInfo(blockDcsnInfo);
				blockOutline.setPndngAmt(serviceOutline.getPndngAmt());
				blockOutline.setReqExeInfo(serviceOutline.getReqExeInfo());
				blockOutline.setReqInqInfo(serviceOutline.getReqInqInfo());
				_request_metadata.setBlockOutline(blockOutline);
				
				RelatedTaskListType relatedTasks= getRealtedTask(_conn,_request_metadata.getSRN(),_task.getTaskId(),_task.getFiId());
				_task.setRelatedTaskList(relatedTasks);				
				rsr.close();
				psr.close();
			} else if (subServiceCode.equals(ServiceCode.GAR)) {
				PreparedStatement psr = _conn.prepareStatement(sqlGarnishReq);
				psr.setInt(1, Integer.valueOf(request_metadataID));
				ResultSet rsr = psr.executeQuery();
				TFIGarnishOutline garnishOutline = new TFIGarnishOutline();
				
				TAccId tAccId = new TAccId();
				TAmt tAmt = new TAmt();
				TGarnishDcsnInfo garnishDcsnInfo = new TGarnishDcsnInfo();
				TExePlan    exePlan = new TExePlan();
				TExeTrgtPrds exeTrgtPrds= new TExeTrgtPrds();
				
				TDrtn drtn= new TDrtn();
				
				while (rsr.next()) {
					tAccId.setNum( rsr.getString("BAI_NUM"));
					tAccId.setIBAN(rsr.getString("BAI_IBAN"));					
					tAccId.setBIC(rsr.getString("BAI_BIC"));
					
					exeTrgtPrds.setAccts(rsr.getString("ACC_FLAG"));
					exeTrgtPrds.setDepots(rsr.getString("DEPOST_FLAG"));
					exeTrgtPrds.setSafs(rsr.getString("SAFS_FLAG"));

					garnishDcsnInfo.setCsType(rsr.getString("CASE_TYPE"));
					garnishDcsnInfo.setDrtnType(rsr.getString("DURATION_TYPE"));
					garnishDcsnInfo.setStrtDt(rsr.getDate("DCSN_DATE").toString());
					garnishDcsnInfo.setDt(rsr.getDate("DCSN_DATE").toString());
					garnishDcsnInfo.setNum(rsr.getString("DCSN_NUM"));
					if (rsr.getString("PERIOD") != null){
						drtn.setPrd(rsr.getBigDecimal("PERIOD"));
						garnishDcsnInfo.setDrtn(drtn);
					}
					if (rsr.getString("END_DATE") != null){
						drtn.setEndDt(rsr.getDate("END_DATE").toString());
						garnishDcsnInfo.setDrtn(drtn);
					}
					
					tAmt.setCur(rsr.getString("AMT_CUR"));					
				}

				if(tAccId.getNum()!= null){
					exePlan.setAccId(tAccId);
				}else{
					exePlan.setTrgtPrds(exeTrgtPrds);
				}	
				garnishOutline.setExePlan(exePlan);

				ServiceOutline serviceOutline = getOutlineExtra(_conn,msgUId);
				tAmt.setVal(serviceOutline.getAmtVal());
				if(tAmt.getCur()!=null){
					garnishDcsnInfo.setAmt(tAmt);
				}				
				garnishOutline.setDcsnInfo(garnishDcsnInfo);
				garnishOutline.setPndngAmt(serviceOutline.getPndngAmt());
				garnishOutline.setReqExeInfo(serviceOutline.getReqExeInfo());
				garnishOutline.setReqInqInfo(serviceOutline.getReqInqInfo());
				_request_metadata.setGarnishOutline(garnishOutline);
				
				RelatedTaskListType relatedTasks= getRealtedTask(_conn,_request_metadata.getSRN(),_task.getTaskId(),_task.getFiId());
				_task.setRelatedTaskList(relatedTasks);				
				rsr.close();
				psr.close();
			}
			
			
			
			_task.setRequestMetadata(_request_metadata);
			_output.setTask(_task);

		}
		_rs.close();
		_ps.close();
		return _output;
	}

	private RelatedTaskListType getRealtedTask(Connection conn,String srn, int taskId, String fiId) throws SQLException, DatatypeConfigurationException {
		RelatedTaskListType relTaksType= new RelatedTaskListType();
		String sqlRelatedtsk = "SELECT * FROM FIPORTAL.WORKFLOW_TASK WHERE SRN=? and FI_ID = ? and ID <> ?";
		PreparedStatement psRel = conn.prepareStatement(sqlRelatedtsk);
		psRel.setString(1, srn);
		psRel.setString(2, fiId);
		psRel.setInt(3, taskId);
		ResultSet relRs = psRel.executeQuery();
		RelatedTaskInfoType relatedTask ;
		List<RelatedTaskInfoType>  taskList= new ArrayList<RelatedTaskInfoType>();
		while (relRs.next()) {
			relatedTask= new RelatedTaskInfoType();
			relatedTask.setSRN(srn);
			relatedTask.setTaskId(relRs.getInt("ID"));
			relatedTask.setCreatedDateTime((FieldsProcessing.getXMLGregCal(relRs.getTimestamp("CREATED_DATE_TIME"))));
			taskList.add(relatedTask);
		}
		JAXBProtectedHandler.setRelatedTaskListType(relTaksType, taskList);
		if(relRs != null)relRs.close();
		if(psRel != null)psRel.close();
		if(taskList.size()>0)
			return relTaksType;
		return null;
	}
	
	
	private ServiceOutline  getOutlineExtra(Connection conn,String msgUId) throws SQLException {
		String sqlExtraInfo = "SELECT EXE_ACC_FLAG, EXE_DEPOST_FLAG,EXE_SAFS_FLAG,INFO_JNT_ACC_FLAG,INFO_JNT_DEPOST_FLAG,INFO_SHRS_FLAG,PENDING_AMT,TRGT_AMT  FROM tanfeeth.EXETR_SRVC_TASK_EXTRA_INFO where MSGUID = ?";
		TReqExeInfo reqExeInfo = new TReqExeInfo();
		TReqInqInfo reqInqInfo = new TReqInqInfo();
		ServiceOutline serviceOutline = new ServiceOutline();
		
		PreparedStatement psExtra = conn.prepareStatement(sqlExtraInfo);
		psExtra.setString(1, msgUId);
		ResultSet extraRs = psExtra.executeQuery();
		while (extraRs.next()) {
			reqExeInfo.setAccts(extraRs.getString("EXE_ACC_FLAG")== null ? "n": extraRs.getString("EXE_ACC_FLAG"));
			reqExeInfo.setDepots(extraRs.getString("EXE_DEPOST_FLAG")== null ? "n": extraRs.getString("EXE_DEPOST_FLAG"));
			reqExeInfo.setSafs(extraRs.getString("EXE_SAFS_FLAG")== null ? "n": extraRs.getString("EXE_SAFS_FLAG"));
			reqInqInfo.setJntAccts(extraRs.getString("INFO_JNT_ACC_FLAG")== null ? "n": extraRs.getString("INFO_JNT_ACC_FLAG"));
			reqInqInfo.setJntDepots(extraRs.getString("INFO_JNT_DEPOST_FLAG")== null ? "n": extraRs.getString("INFO_JNT_DEPOST_FLAG"));
			reqInqInfo.setShrs(extraRs.getString("INFO_SHRS_FLAG")== null ? "n": extraRs.getString("INFO_SHRS_FLAG"));
			serviceOutline.setAmtVal(extraRs.getBigDecimal("TRGT_AMT")== null ? new BigDecimal(0): extraRs.getBigDecimal("TRGT_AMT"));
			
//			serviceOutline.setPndngAmt(extraRs.getBigDecimal("PENDING_AMT")== null ? new BigDecimal(0): extraRs.getBigDecimal("PENDING_AMT"));

			if (extraRs.getString("PENDING_AMT") != null){
				serviceOutline.setPndngAmt(extraRs.getBigDecimal("PENDING_AMT"));
			}
		}
		if(reqExeInfo.getAccts()!= null){
			serviceOutline.setReqExeInfo(reqExeInfo);
		}else{
			serviceOutline.setReqExeInfo(null);
		}
		if(reqInqInfo.getJntAccts()!= null){
			serviceOutline.setReqInqInfo(reqInqInfo);
		}else{
			serviceOutline.setReqInqInfo(null);
		}
		if(extraRs != null)extraRs.close();
		if(psExtra != null)psExtra.close();
	    return serviceOutline;
	}

}


