package com.sbm.sama.portal.getTask.dao.impl;

import java.math.BigDecimal;

import com.sbm.sama.portal.tanfeeth.jaxb.common.TBlockDcsnInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TExePlan;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TReqExeInfo;
import com.sbm.sama.portal.tanfeeth.jaxb.common.TReqInqInfo;

public class ServiceOutline {

	private TBlockDcsnInfo dcsnInfo;
	private TExePlan exePlan;
	private BigDecimal pndngAmt;
	private TReqExeInfo reqExeInfo;
	private TReqInqInfo reqInqInfo;
	private BigDecimal amtVal;

	public TBlockDcsnInfo getDcsnInfo() {
		return dcsnInfo;
	}

	public void setDcsnInfo(TBlockDcsnInfo dcsnInfo) {
		this.dcsnInfo = dcsnInfo;
	}

	public TExePlan getExePlan() {
		return exePlan;
	}

	public void setExePlan(TExePlan exePlan) {
		this.exePlan = exePlan;
	}

	public BigDecimal getPndngAmt() {
		return pndngAmt;
	}

	public void setPndngAmt(BigDecimal pndngAmt) {
		this.pndngAmt = pndngAmt;
	}

	public TReqExeInfo getReqExeInfo() {
		return reqExeInfo;
	}

	public void setReqExeInfo(TReqExeInfo reqExeInfo) {
		this.reqExeInfo = reqExeInfo;
	}

	public TReqInqInfo getReqInqInfo() {
		return reqInqInfo;
	}

	public void setReqInqInfo(TReqInqInfo reqInqInfo) {
		this.reqInqInfo = reqInqInfo;
	}

	public BigDecimal getAmtVal() {
		return amtVal;
	}

	public void setAmtVal(BigDecimal amtVal) {
		this.amtVal = amtVal;
	}

	
}
