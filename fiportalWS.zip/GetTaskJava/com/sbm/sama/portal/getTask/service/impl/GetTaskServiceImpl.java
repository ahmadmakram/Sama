package com.sbm.sama.portal.getTask.service.impl;

import java.sql.Connection;
import java.sql.SQLException;

import javax.xml.datatype.DatatypeConfigurationException;

import com.sbm.sama.portal.getTask.dao.TaskDao;
import com.sbm.sama.portal.getTask.dao.impl.TaskDaoImpl;
import com.sbm.sama.portal.getTask.service.GetTaskService;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetTaskInputType;
import com.sbm.sama.portal.tanfeeth.jaxb.common.GetTaskOutputType;


public class GetTaskServiceImpl implements GetTaskService {

	private TaskDao taskDao = new TaskDaoImpl();

	@Override
	public GetTaskOutputType getTask(GetTaskInputType _input, Connection _conn)
			throws SQLException, DatatypeConfigurationException {
		return taskDao.GetTask(_input, _conn);
	}
}
