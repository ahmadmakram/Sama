package com.sbm.sama.portal.tanfeeth.common.service.impl;

import java.sql.Connection;
import java.sql.SQLException;

import com.sbm.sama.portal.tanfeeth.common.dao.CommonTaskDao;
import com.sbm.sama.portal.tanfeeth.common.dao.impl.CommonTaskDaoImpl;
import com.sbm.sama.portal.tanfeeth.common.service.CommonTaskService;
import com.sbm.sama.portal.tanfeeth.common.util.WorkflowTaskBean;

public class CommonTaskServiceImpl implements CommonTaskService{

	private CommonTaskDao commonTaskDao = new CommonTaskDaoImpl();
	
	@Override
	public void updateTaskService(Connection conn,WorkflowTaskBean workflowTaskBean)
			throws SQLException {
		commonTaskDao.updateTask(conn, workflowTaskBean);
	}

	@Override
	public String getTaskCallBackStatusService(Connection conn, int taskId)
			throws SQLException {
		return commonTaskDao.GetTaskCallBackStatus(conn, taskId);
	}

	@Override
	public WorkflowTaskBean selectTaskService(Connection _conn, int TaskId)
			throws SQLException {

		return commonTaskDao.selectTask(_conn, TaskId);
	}

	

}
