package com.sbm.sama.portal.tanfeeth.jaxb.common;

import java.util.List;


/**
 * 
 * @author Mahmoud Fahmy
 * 
 */
public class JAXBProtectedHandler {
	public static void setRMInvolvedEntityType(RequestMetadataType reqMetaData,
			List<InvolvedEntityType> involvedEntityTypeList) {
		reqMetaData.involvedEntityList = involvedEntityTypeList;
	}

//	public static void setRMAccountInfoRequestList(RequestMetadataType reqMetaData,
//			AccountInfoType accountInfoRequestList) {
//		reqMetaData.accountInfoRequestList = accountInfoRequestList;
//	}

//	public static void setDepositeInfoTypeRequestList(RequestMetadataType reqMetaData,
//			DepositeInfoType depositeInfoRequestList) {
//		reqMetaData.depositeInfoRequestList = depositeInfoRequestList;
//	}

//	public static void setSafeInfoTypeRequestList(RequestMetadataType reqMetaData,
//			SafeInfoType safeInfoRequestList) {
//		reqMetaData.safeInfoRequestList = safeInfoRequestList;
//	}

	public static void setTaskOutputType(GetTaskRsType response, GetTaskOutputType output) {
		response.getTaskOutput = output;
	}

	public static GetTaskInputType getTaskInputType(GetTaskRqType request) {
		return request.getTaskInput;
	}

//	public static void setDenyDlngDcsnInfoType(RequestMetadataType reqMetaData, DlngDcsnInfoType denyInfoReq) {
//		reqMetaData.denyDealingRequest = denyInfoReq;
//	}

//	public static void setBanDlngDcsnInfoType(RequestMetadataType reqMetaData, DlngDcsnInfoType denyInfoReq) {
//		reqMetaData.banDealingRequest = denyInfoReq;
//	}

//	public static void setLiftRestrictionInfoType(RequestMetadataType reqMetaData,
//			LiftRestrictionInfoType liftRestrictionInfoType) {
//		reqMetaData.liftRestrictionRequest = liftRestrictionInfoType;
//	}

//	public static void setBlockType(RequestMetadataType reqMetaData, BlockType blockType) {
//		reqMetaData.blockRequest = blockType;
//	}
//	
//	public static void setBanType(RequestMetadataType reqMetaData, TDlngDcsnInfo banType) {
//		reqMetaData.setDcsnInfo(banType);
//	}

	public static void setBulkTasksOutput(GetBulkTasksRsType GetBulkTasksRs,
			List<GetBulkTasksOutputType> getBulkTasksOutput) {
		GetBulkTasksRs.getBulkTasksOutput = getBulkTasksOutput;
	}

	public static void setRsrvInfo(TRsrvList trSrvList, List<TRsrvInfo> rsrvInfo) {
		trSrvList.rsrvInfo = rsrvInfo;
	}

	public static void setUsrInfo(TPrdUsrsLis tPrdUsrsLis, List<TUsrInfo> usrInfo) {
		tPrdUsrsLis.usrInfo = usrInfo;
	}

	public static void setTShrInfo(TShrsList tShrsList, List<TShrInfo> shrInfo) {
		tShrsList.shrInfo = shrInfo;
	}
	
	public static void setAccInfo(TAcctsList acctsList, List<TAccountInfo> accInfo) {
		acctsList.accInfo = accInfo;
	}
	
	public static void setWorkFlowStatusHistory(TaskType task, List<WorkflowStatusHistoryType> workFlowStatusHistory) {
		 task.workflowStatusHistory = workFlowStatusHistory;
	}
	
	public static void setDepotInfo(TDepotsList _depotsList,List<TDepotInfo> depotInfo ) {
		_depotsList.depotInfo = depotInfo;
	}
	
	public static void setLiabInfo(TLiabsList liabsList,List<TLiabInfo> liabInfo) {
		liabsList.liabInfo = liabInfo;
	}
	
	public static void setSafInfo(TSafsList safesList,List<TSafInfo> safInfo) {
		safesList.safInfo = safInfo;
	}

	public static void setWorkFlowStatusHistory(TaskType task, RelatedTaskListType relatedTaskListType) {
		 task.relatedTaskList = relatedTaskListType;
	}
	
	public static void setRelatedTaskListType(RelatedTaskListType type, List<RelatedTaskInfoType> taskList) {
		type.relatedTaskInfo = taskList;
	}
	
	public static void setAttributeType(TAttributes moreInfo, List<TAttribute> attribute) {
		moreInfo.attribute = attribute;
	}
}
